'    Graphical LCD routines for the GCBASIC compiler
'    Copyright (C) 2019 Evan Venn

'    This library is free software; you can redistribute it and/or
'    modify it under the terms of the GNU Lesser General Public
'    License as published by the Free Software Foundation; either
'    version 2.1 of the License, or (at your option) any later version.

'    This library is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
'    Lesser General Public License for more details.

'    You should have received a copy of the GNU Lesser General Public
'    License along with this library; if not, write to the Free Software
'    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

'Notes:
' Supports ST7735R controller only.

'Changes
' 10/09/2019  Initial release

'Hardware settings
'Type
'''@hardware All; Controller Type; GLCD_TYPE; "GLCD_TYPE_ST7735"

'Serial lines (ST7735R only)
'''@hardware GLCD_TYPE GLCD_TYPE_ST7735R; Data/Command; GLCD_DC; IO_Pin
'''@hardware GLCD_TYPE GLCD_TYPE_ST7735R; Chip Select; GLCD_CS; IO_Pin
'''@hardware GLCD_TYPE GLCD_TYPE_ST7735R; Data In (LCD Out); GLCD_DI; IO_Pin
'''@hardware GLCD_TYPE GLCD_TYPE_ST7735R; Data Out (LCD In); GLCD_DO; IO_Pin
'''@hardware GLCD_TYPE GLCD_TYPE_ST7735R; Clock; GLCD_SCK; IO_Pin


'Pin mappings for ST7735R
#define ST7735_DC GLCD_DC
#define ST7735_CS GLCD_CS
#define ST7735_RST GLCD_RESET
#define ST7735_DI GLCD_DI
#define ST7735_DO GLCD_DO
#define ST7735_SCK GLCD_SCK

#startup InitGLCD_ST7735R

'''Initialise the GLCD device
Sub InitGLCD_ST7735R

  #if GLCD_TYPE = GLCD_TYPE_ST7735R
    'Setup code for ST7735R controllers

    'mapped to global variable
    dim GLCDForeground, GLCDBackground as word

    'Pin directions
    #IFNDEF GLCD_LAT
        Dir ST7735_CS Out
        Dir ST7735_DC Out
        Dir ST7735_RST Out

        #if bit(ST7735_DI)
          Dir ST7735_DI In
        #endif
        Dir ST7735_DO Out
        Dir ST7735_SCK Out
    #endif


    #IFDEF GLCD_LAT
        Dir _ST7735_CS Out
        Dir _ST7735_DC Out
        Dir _ST7735_RST Out
        #if bit(_ST7735_DI)
          Dir _ST7735_DI In
        #endif
        Dir _ST7735_DO Out
        Dir _ST7735_SCK Out
    #endif

    #ifdef ST7735_HardwareSPI
          ' harware SPI mode
          asm showdebug SPI constant used equates to HWSPIMODESCRIPT
          SPIMode HWSPIMODESCRIPT, 0
    #endif

    'Reset display
    Set ST7735_RST On
    Wait 150 ms
    'Reset sequence (lower line for at least 10 us)
    Set ST7735_RST Off
    Wait 150 us
    Set ST7735_RST On
    Wait 150 ms
    'Software reset
    SendCommand_ST7735 ST7735_SWRESET
    Wait 150 ms

    'Software reset
    SendCommand_ST7735 ST7735_SWRESET
    Wait 150 ms

    'Out of sleep mode
    SendCommand_ST7735 ST7735_SLPOUT
    Wait 255 ms

    SendCommand_ST7735(ST7735_FRMCTR1)
    SendData_ST7735(0x01)
    SendData_ST7735(0x2C)
    SendData_ST7735(0x2D)
    Wait 10 ms

    SendCommand_ST7735(ST7735_FRMCTR2)
    SendData_ST7735(0x01)
    SendData_ST7735(0x2C)
    SendData_ST7735(0x2D)
    Wait 10 ms

    SendCommand_ST7735(ST7735_FRMCTR3)
    SendData_ST7735(0x01)
    SendData_ST7735(0x2C)
    SendData_ST7735(0x2D)
    SendData_ST7735(0x01)
    SendData_ST7735(0x2C)
    SendData_ST7735(0x2D)
    Wait 10 ms

    SendCommand_ST7735(ST7735_INVCTR)
    SendData_ST7735(0x07)
    wait 10 ms;

    SendCommand_ST7735(ST7735_PWCTR1)
    SendData_ST7735(0xA2)
    SendData_ST7735(0x02)
    SendData_ST7735(0x84)
    wait 10 ms;

    SendCommand_ST7735(ST7735_PWCTR2)
    SendData_ST7735(0xC5)
    wait 10 ms;

    SendCommand_ST7735(ST7735_PWCTR3)
    SendData_ST7735(0x0A)
    SendData_ST7735(0x00)
    wait 10 ms;

    SendCommand_ST7735(ST7735_PWCTR4)
    SendData_ST7735(0x8A)
    SendData_ST7735(0x2A)
    wait 10 ms;

    SendCommand_ST7735(ST7735_PWCTR5)
    SendData_ST7735(0x8A)
    SendData_ST7735(0xEE)
    wait 10 ms;

    SendCommand_ST7735(ST7735_VMCTR1)
    SendData_ST7735(0x0E)
    wait 10 ms;

    SendCommand_ST7735(ST7735_INVOFF)
    wait 10 ms;


    SendCommand_ST7735(ST7735_MADCTL)
    SendData_ST7735(0x18)     'MADCTL bottom to top refresh
    wait 20 ms

    '1 clk cycle nonoverlap, 2 cycle gate rise, 3 sycle osc equalie,
    'fix on VTL
    SendCommand_ST7735(ST7735_COLMOD)
    SendData_ST7735(0x05)

    SendCommand_ST7735(ST7735_GMCTRP1)
    SendData_ST7735(0x02)
    SendData_ST7735(0x1c)
    SendData_ST7735(0x07)
    SendData_ST7735(0x12)
    SendData_ST7735(0x37)
    SendData_ST7735(0x32)
    SendData_ST7735(0x29)
    SendData_ST7735(0x2d)
    SendData_ST7735(0x29)
    SendData_ST7735(0x25)
    SendData_ST7735(0x2b)
    SendData_ST7735(0x39)
    SendData_ST7735(0x00)
    SendData_ST7735(0x01)
    SendData_ST7735(0x03)
    SendData_ST7735(0x10)
    wait 10 ms

    SendCommand_ST7735(ST7735_GMCTRN1)
    SendData_ST7735(0x03)
    SendData_ST7735(0x1d)
    SendData_ST7735(0x07)
    SendData_ST7735(0x06)
    SendData_ST7735(0x2e)
    SendData_ST7735(0x2c)
    SendData_ST7735(0x29)
    SendData_ST7735(0x2d)
    SendData_ST7735(0x2e)
    SendData_ST7735(0x2e)
    SendData_ST7735(0x37)
    SendData_ST7735(0x3F)
    SendData_ST7735(0x00)
    SendData_ST7735(0x00)
    SendData_ST7735(0x02)
    SendData_ST7735(0x10)
    wait 10 ms

    'Display on
    SendCommand_ST7735 ST7735_NORON
    Wait 10 ms

    'Display on
    SendCommand_ST7735 ST7735_DISPON
    Wait 100 ms


    'Colours
    GLCDForeground = TFT_WHITE
    'Default Colours
    #ifdef DEFAULT_GLCDBACKGROUND
      GLCDBackground = DEFAULT_GLCDBACKGROUND
    #endif

    #ifndef DEFAULT_GLCDBACKGROUND
      GLCDBackground = TFT_BLACK
    #endif

    'Variables required for device
    GLCDDeviceWidth = GLCD_WIDTH - 1
    GLCDDeviceHeight = GLCD_HEIGHT - 1

    #ifndef GLCD_OLED_FONT
      GLCDFontWidth = 6
    #endif

    #ifdef GLCD_OLED_FONT
      GLCDFontWidth = 5
    #endif

    GLCDfntDefault = 0
    GLCDfntDefaultsize = 1

    GLCDRotate ( PORTRAIT )
    'Clear screen
    GLCDCLS

  #endif

End Sub


'Subs
'''Clears the GLCD screen
Sub GLCDCLS_ST7735R ( Optional In  GLCDBackground as word = GLCDBackground)

  ' initialise global variable. Required variable for Circle in all DEVICE DRIVERS- DO NOT DELETE
  GLCD_yordinate = 0
  Dim PrintLocX, PrintLocY as word
  PrintLocX = 0
  PrintLocY = 0


  #if GLCD_TYPE = GLCD_TYPE_ST7735R
    SetAddress_ST7735 ST7735_COLUMN, 0, GLCDDeviceWidth
    wait 2 ms
    SetAddress_ST7735 ST7735_ROW, 0, GLCDDeviceHeight
    wait 2 ms
    SendCommand_ST7735 ST7735_RAMWR
    wait 2 ms
    Repeat [word] GLCD_WIDTH * GLCD_HEIGHT
      SendWord_ST7735 GLCDBackground
    End Repeat
  #endif

End Sub


'''@hide
sub   GLCDRotate_ST7735R ( in GLCDRotateState )

  SendCommand_ST7735 ( ST7735_MADCTL )
  select case GLCDRotateState
        case LANDSCAPE
            IF ST7735TABCOLOR = ST7735_BLACKTAB or ST7735TABCOLOR = ST7735_MINI160x80 then
             SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MV |  ST7735_MADCTL_RGB )
            else
             SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MV |  ST7735_MADCTL_BGR )
            end if
            GLCDDeviceWidth = GLCD_HEIGHT - 1
            GLCDDeviceHeight = GLCD_WIDTH - 1

        case PORTRAIT_REV
            GLCDDeviceWidth = GLCD_WIDTH - 1
            GLCDDeviceHeight = GLCD_HEIGHT - 1
            IF ST7735TABCOLOR = ST7735_BLACKTAB or ST7735TABCOLOR = ST7735_MINI160x80 then
              SendData_ST7735( ST7735_MADCTL_RGB )
            else
              SendData_ST7735( ST7735_MADCTL_BGR )
            end if
        case LANDSCAPE_REV
            IF ST7735TABCOLOR = ST7735_BLACKTAB or ST7735TABCOLOR = ST7735_MINI160x80 then
              SendData_ST7735( ST7735_MADCTL_MV | ST7735_MADCTL_MY | ST7735_MADCTL_RGB )
            else
              SendData_ST7735( ST7735_MADCTL_MV | ST7735_MADCTL_MY | ST7735_MADCTL_BGR )
            end if
            GLCDDeviceWidth = GLCD_HEIGHT - 1
            GLCDDeviceHeight = GLCD_WIDTH - 1
        case PORTRAIT
            GLCDDeviceWidth = GLCD_WIDTH - 1
            GLCDDeviceHeight = GLCD_HEIGHT - 1
            IF ST7735TABCOLOR = ST7735_BLACKTAB or ST7735TABCOLOR = ST7735_MINI160x80 then
              SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MY | ST7735_MADCTL_RGB )
            else
              SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MY | ST7735_MADCTL_BGR )
            end if
        case else
            GLCDDeviceWidth = GLCD_WIDTH - 1
            GLCDDeviceHeight = GLCD_HEIGHT - 1
            IF ST7735TABCOLOR = ST7735_BLACKTAB or ST7735TABCOLOR = ST7735_MINI160x80 then
              SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MY | ST7735_MADCTL_RGB )
            else
              SendData_ST7735( ST7735_MADCTL_MX | ST7735_MADCTL_MY | ST7735_MADCTL_BGR )
            end if

  end select

end sub
