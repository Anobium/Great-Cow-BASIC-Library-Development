Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/st7735r_simpletest.py
    :caption: examples/st7735r_simpletest.py
    :linenos:
