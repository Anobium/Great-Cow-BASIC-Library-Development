/***********************************************************************************************************/
!!!NOTE:

DO NOT! DO NOT! DO NOT update directly from the Arduino IDE.

You should know that the library you update directly from the Arduino IDE is not provided by us.
Maybe it is written by somebody else.
Please follow me: and do not update from Arduino IDE
Please download the new library from the google driver. https://drive.google.com/open?id=0B6uNNXJ2z4CxYktCQlViUkI1Sms
All the four libraries in the folder of "Arduino library" must be put in the derectory of ../Arduino-1.xx/libraries, and then restart the IDE. 
We have test the four examples in the derectory of D:\arduino-1.6.5-r2\libraries\MCUFRIEND_kbv\examples.
/*************************************************************************************************************/

If you have any questions, please contact us: catalex_inc@163.com