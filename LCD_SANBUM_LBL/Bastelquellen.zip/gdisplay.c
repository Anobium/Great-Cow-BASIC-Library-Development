/* LCD-Ansteuerung: Test f�r das "Sanbum"-Pollin-Display */

#include "StdTypes.h"
#include "startup.h"
#include "LPC11E12.h"
#include "config.h"
#include "i2c.h"
#include "gdisplay.h"
#include "gdi.h"

/* Display: Pollin "SANBUM"
Interface: I2C und /Reset
Adressen: 38h = Control und 39h = Daten

Folienkabel 11 polig: ben�tigt: FFC 11 x 1 mm, bottom
Belegung von links nach rechts bei Blick auf Displaybereich:
 1 - Vlcd-in, C nach GND, ggf. 10 MOhm Ableitwiderstand nach GND
 2 - Vlcd-out
 3 - Kondensator nach 4
 4 - siehe 3
 5 - Kondensator nach 6
 6 - siehe 5
 7 - GND
 8 - VCC 2.4 bis 3.3 V
 9 - SDA
10 - SCL
11 - /Reset

Der Controller ist ein UC1601S, nur serieller Anschlu�
   /RES auf P0.14
   SCL  auf P0.16
   DATA auf P0.17
*/

// die Adressen f�r das LCD
#define cmd   0x38
#define data  0x39

void RESET_low    (void) { P1_13 = 0; }
void RESET_high   (void) { P1_13 = 1; }

byte  BWSP[BWSP_Len];     // der Display-RAM
bool  LcdInvalid;
byte  LcdKontrast;



/* Display-Kommandos A0=low*/
#define col_low        0
#define col_hi      0x10
#define temp_comp   0x24
#define pwr_ctrl    0x28
#define adv_pctl    0x30   // danach Wert ?
#define scrolline   0x40
#define set_page    0xB0
#define poti        0x81   // danach Wert, default 0xC0
#define partial     0x84
#define ramadctl    0x88
#define framerate   0xA0
#define allpixel    0xA4
#define invers      0xA6
#define disp_ena    0xAE
#define map_ctrl    0xC0
#define reset       0xE2
#define nop         0xE3
#define bias        0xE8
#define com_end     0xF1    // danach Wert 0..127, default 63
#define part_start  0xF2    // danach Wert 0..127, default 0
#define part_end    0xF3    // danach Wert 0..127, default 63


void Warte ( int ms)
{ dword D;
  int i;

  i = 0;
  D = Ticks;
  while ( i < ms)
  { if (D != Ticks) { ++i; D = Ticks; }
  }
}

void LCD_enable (bool ena)
{ byte b;
  bool erg;

  b  = disp_ena;
  if (ena) ++b;

  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) Do_I2C_Write(b);
  Do_I2C_Stop();
  Warte (2);
}

void LCD_SetKontrast (byte kontrast)
{ bool erg;

  LcdKontrast = kontrast;
  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) erg = Do_I2C_Write(poti);
  if (erg) Do_I2C_Write(kontrast);
  Do_I2C_Stop();
  Warte (2);
}


void LCD_invers (bool inv)
{ byte b;
  bool erg;

  b  = invers;
  if (inv) ++b;

  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) Do_I2C_Write(b);
  Do_I2C_Stop();
  Warte (2);
}

void LCD_Allpixel (bool on)
{ byte b;
  bool erg;

  b  = allpixel;
  if (on) ++b;

  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) Do_I2C_Write(b);
  Do_I2C_Stop();
  Warte (2);
}

void LCD_SetComEnd (byte cen)
{ bool erg;

  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) Do_I2C_Write(com_end);
  if (erg) Do_I2C_Write(cen);
  Do_I2C_Stop();
  Warte (2);
}


void LCD_Softreset (void)
{ bool erg;

  erg = Do_I2C_Start(cmd, I2CWRITE);
  if (erg) Do_I2C_Write(reset);
  Do_I2C_Stop();
  Warte (2);
}

void LCD_Hardreset (void)
{ RESET_low();
  Warte(2);
  RESET_high();
  Warte(10);
}


void LCD_Init (void)
{ LCD_Hardreset();
  LCD_SetKontrast(63);
  LCD_SetComEnd(21);
  LCD_enable(true);
  gedreht = false;
}

void LCD_Blocktransfer (void)
{ int y, pg, idx;
  bool erg;

  pg = 0;
  idx = 0;
  while (pg<3)
  { erg = Do_I2C_Start(cmd, I2CWRITE);
    if (erg) Do_I2C_Write(set_page+pg);
    if (erg) Do_I2C_Write(col_low);
    if (erg) Do_I2C_Write(col_hi);
    Do_I2C_Stop();

    erg = Do_I2C_Start(data, I2CWRITE);
    if (erg)
    { y = 0;
      while ((y<128) && erg)
      { erg = Do_I2C_Write(BWSP[idx++]);
        ++y;
      }
      Do_I2C_Stop();
    }
    ++pg;
  }
  LcdInvalid = false;
}

// Display abl�schen
void LCD_Clear (byte b)
{ int i;
  i = 0;
  while (i<BWSP_Len)
  { BWSP[i] = b; ++i; }
}


    /* ende */
