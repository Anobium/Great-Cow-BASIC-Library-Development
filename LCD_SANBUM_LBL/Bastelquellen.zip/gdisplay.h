/* LCD-Ansteuerung f�r das Rx-Backend-Board (Freescale Kinetis MK22FN128VLH10) */

#ifndef GDISPLAY_INCLUDED
#define GDISPLAY_INCLUDED

#define PixelPerLine  128
#define LinesPerBuffer 22

#define lcdbreite     128
#define lcdhoehe       22

// L�nge des Display-RAM's
#define  BWSP_Len  ((PixelPerLine>>3) * LinesPerBuffer)

extern byte  LcdKontrast;

extern byte  BWSP[BWSP_Len];     // der Display-RAM
extern bool  LcdInvalid;         // ob Refresh erforderlich ist
extern byte  LcdKontrast;        // Wert f�r Kontrastspannung 0..63

extern void LCD_SetKontrast   (byte kontrast);
extern void LCD_Clear         (byte b);
extern void LCD_Init          (void);
extern void LCD_Blocktransfer (void);
extern void LCD_DoSleep       (void);
extern void LCD_ExitSleep     (void);

extern void RESET_low  (void);
extern void RESET_high (void);

extern void LCD_invers    (bool inv);
extern void LCD_Softreset (void);
extern void LCD_Hardreset (void);
extern void LCD_Allpixel  (bool on);


#endif


