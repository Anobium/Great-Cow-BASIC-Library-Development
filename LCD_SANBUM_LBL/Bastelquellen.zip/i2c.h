/*  Definitionen f�r den I2C-Bus-Anschluss als Master im Philips LPC2214 */

#ifndef _I2C_INCLUDED
#define _I2C_INCLUDED

#define I2CREAD   1
#define I2CWRITE  0

extern void SCL_low       (void);
extern void SCL_high      (void);

extern void SDA_low       (void);
extern void SDA_high      (void);


   /* Init Logik und Interrupt. Die Pin-Freischaltung mu� bereits erledigt sein (PINSEL und Portbeine) */
extern void I2C_Init (void);
extern void I2C_DeInit (void);

   /* �bertragung starten und adressieren */
extern bool Do_I2C_Start (byte Adresse, bool R_W); /* Result = Acknowledge-Bit */

   /* ein Byte schreiben */
extern bool Do_I2C_Write (byte aByte);             /* Result = Acknowledge-Bit */

   /* ein Byte lesen */
extern byte Do_I2C_Read   (bool Acknowledge);      /* Result = gelesenes Byte */

   /* �bertragung stoppen */
extern void Do_I2C_Stop (void);

extern void sdelay (long L);

#endif
