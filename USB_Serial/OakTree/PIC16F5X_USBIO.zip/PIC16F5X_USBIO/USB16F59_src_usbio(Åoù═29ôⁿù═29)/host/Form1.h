#pragma once

#include "stdio.h"
#include <wtypes.h>

#include "Usb.h"


namespace My16FUSB_HID_DioSampleAPP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
		delegate void SetCheckDelegate(CheckBox^ chk, bool check);
	public:
		Form1(void)
		{
			InitializeComponent();
			
			 usb = gcnew Usb();
			 usb->VendorID = 0x04D8;
			 usb->ProductID = 0x0628;

			 if(usb->findDevice()) {
				this->toolStripStatusLabel1->Text = "Device Connected";

				usb->openReadHandle();
				bgWorker = gcnew System::ComponentModel::BackgroundWorker();
				bgWorker->DoWork += gcnew DoWorkEventHandler( this, &Form1::inputThread );
				bgWorker->RunWorkerAsync();

				usb->openWriteHandle();
			 } else {
				System::Windows::Forms::MessageBox::Show( L"Device not found!", L"16FUSB", 
					System::Windows::Forms::MessageBoxButtons::OK);				
			 }
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^  checkBox88;
	private: System::Windows::Forms::CheckBox^  checkBox87;
	private: System::Windows::Forms::CheckBox^  checkBox86;
	private: System::Windows::Forms::CheckBox^  checkBox85;
	private: System::Windows::Forms::CheckBox^  checkBox84;
	private: System::Windows::Forms::CheckBox^  checkBox83;
	private: System::Windows::Forms::CheckBox^  checkBox82;
	private: System::Windows::Forms::CheckBox^  checkBox81;
	private: System::Windows::Forms::CheckBox^  checkBox80;
	private: System::Windows::Forms::CheckBox^  checkBox79;
	private: System::Windows::Forms::CheckBox^  checkBox78;
	private: System::Windows::Forms::CheckBox^  checkBox77;
	private: System::Windows::Forms::CheckBox^  checkBox76;
	private: System::Windows::Forms::CheckBox^  checkBox75;
	private: System::Windows::Forms::CheckBox^  checkBox74;
	private: System::Windows::Forms::CheckBox^  checkBox73;
	private: System::Windows::Forms::CheckBox^  checkBox72;
	private: System::Windows::Forms::CheckBox^  checkBox71;
	private: System::Windows::Forms::CheckBox^  checkBox70;
	private: System::Windows::Forms::CheckBox^  checkBox69;
	private: System::Windows::Forms::CheckBox^  checkBox68;
	private: System::Windows::Forms::CheckBox^  checkBox67;
	private: System::Windows::Forms::CheckBox^  checkBox66;
	private: System::Windows::Forms::CheckBox^  checkBox65;
	private: System::Windows::Forms::CheckBox^  checkBox64;
	private: System::Windows::Forms::CheckBox^  checkBox63;
	private: System::Windows::Forms::CheckBox^  checkBox62;
	private: System::Windows::Forms::CheckBox^  checkBox61;
	private: System::Windows::Forms::CheckBox^  checkBox60;
	private: System::Windows::Forms::Label^  label88;
	private: System::Windows::Forms::Label^  label87;
	private: System::Windows::Forms::Label^  label86;
	private: System::Windows::Forms::Label^  label85;
	private: System::Windows::Forms::Label^  label84;
	private: System::Windows::Forms::Label^  label83;
	private: System::Windows::Forms::Label^  label82;
	private: System::Windows::Forms::Label^  label81;
	private: System::Windows::Forms::Label^  label80;
	private: System::Windows::Forms::Label^  label79;
	private: System::Windows::Forms::Label^  label78;
	private: System::Windows::Forms::Label^  label77;
	private: System::Windows::Forms::Label^  label76;
	private: System::Windows::Forms::Label^  label75;
	private: System::Windows::Forms::Label^  label74;
	private: System::Windows::Forms::Label^  label73;
	private: System::Windows::Forms::Label^  label72;
	private: System::Windows::Forms::Label^  label71;
	private: System::Windows::Forms::Label^  label70;
	private: System::Windows::Forms::Label^  label69;
	private: System::Windows::Forms::Label^  label68;
	private: System::Windows::Forms::Label^  label67;
	private: System::Windows::Forms::Label^  label66;
	private: System::Windows::Forms::Label^  label65;
	private: System::Windows::Forms::Label^  label64;
	private: System::Windows::Forms::Label^  label63;
	private: System::Windows::Forms::Label^  label62;
	private: System::Windows::Forms::Label^  label61;
	private: System::Windows::Forms::Label^  label60;
	private: System::Windows::Forms::CheckBox^  checkBox58;
	private: System::Windows::Forms::CheckBox^  checkBox57;
	private: System::Windows::Forms::CheckBox^  checkBox56;
	private: System::Windows::Forms::CheckBox^  checkBox55;
	private: System::Windows::Forms::CheckBox^  checkBox54;
	private: System::Windows::Forms::CheckBox^  checkBox53;
	private: System::Windows::Forms::CheckBox^  checkBox52;
	private: System::Windows::Forms::CheckBox^  checkBox51;
	private: System::Windows::Forms::CheckBox^  checkBox50;
	private: System::Windows::Forms::CheckBox^  checkBox49;
	private: System::Windows::Forms::CheckBox^  checkBox48;
	private: System::Windows::Forms::CheckBox^  checkBox47;
	private: System::Windows::Forms::CheckBox^  checkBox46;
	private: System::Windows::Forms::CheckBox^  checkBox45;
	private: System::Windows::Forms::CheckBox^  checkBox44;
	private: System::Windows::Forms::CheckBox^  checkBox43;
	private: System::Windows::Forms::CheckBox^  checkBox42;
	private: System::Windows::Forms::CheckBox^  checkBox41;
	private: System::Windows::Forms::CheckBox^  checkBox40;
	private: System::Windows::Forms::CheckBox^  checkBox39;
	private: System::Windows::Forms::CheckBox^  checkBox38;
	private: System::Windows::Forms::CheckBox^  checkBox37;
	private: System::Windows::Forms::CheckBox^  checkBox36;
	private: System::Windows::Forms::CheckBox^  checkBox35;
	private: System::Windows::Forms::CheckBox^  checkBox34;
	private: System::Windows::Forms::CheckBox^  checkBox33;
	private: System::Windows::Forms::CheckBox^  checkBox32;
	private: System::Windows::Forms::CheckBox^  checkBox31;
	private: System::Windows::Forms::CheckBox^  checkBox30;
	private: System::Windows::Forms::Label^  label58;
	private: System::Windows::Forms::Label^  label57;
	private: System::Windows::Forms::Label^  label56;
	private: System::Windows::Forms::Label^  label55;
	private: System::Windows::Forms::Label^  label54;
	private: System::Windows::Forms::Label^  label53;
	private: System::Windows::Forms::Label^  label52;
	private: System::Windows::Forms::Label^  label51;
	private: System::Windows::Forms::Label^  label50;
	private: System::Windows::Forms::Label^  label49;
	private: System::Windows::Forms::Label^  label48;
	private: System::Windows::Forms::Label^  label47;
	private: System::Windows::Forms::Label^  label46;
	private: System::Windows::Forms::Label^  label45;
	private: System::Windows::Forms::Label^  label44;
	private: System::Windows::Forms::Label^  label43;
	private: System::Windows::Forms::Label^  label42;
	private: System::Windows::Forms::Label^  label41;
	private: System::Windows::Forms::Label^  label40;
	private: System::Windows::Forms::Label^  label39;
	private: System::Windows::Forms::Label^  label38;
	private: System::Windows::Forms::Label^  label37;
	private: System::Windows::Forms::Label^  label36;
	private: System::Windows::Forms::Label^  label35;
	private: System::Windows::Forms::Label^  label34;
	private: System::Windows::Forms::Label^  label33;
	private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::Label^  label31;
	private: System::Windows::Forms::Label^  label30;
	private: System::Windows::Forms::GroupBox^  groupBox0;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::CheckBox^  checkBox28;
	private: System::Windows::Forms::CheckBox^  checkBox27;
	private: System::Windows::Forms::CheckBox^  checkBox26;
	private: System::Windows::Forms::CheckBox^  checkBox25;
	private: System::Windows::Forms::CheckBox^  checkBox24;
	private: System::Windows::Forms::CheckBox^  checkBox23;
	private: System::Windows::Forms::CheckBox^  checkBox22;
	private: System::Windows::Forms::CheckBox^  checkBox21;
	private: System::Windows::Forms::CheckBox^  checkBox20;
	private: System::Windows::Forms::CheckBox^  checkBox19;
	private: System::Windows::Forms::CheckBox^  checkBox18;
	private: System::Windows::Forms::CheckBox^  checkBox17;
	private: System::Windows::Forms::CheckBox^  checkBox16;
	private: System::Windows::Forms::CheckBox^  checkBox15;
	private: System::Windows::Forms::CheckBox^  checkBox14;
	private: System::Windows::Forms::CheckBox^  checkBox13;
	private: System::Windows::Forms::CheckBox^  checkBox12;
	private: System::Windows::Forms::CheckBox^  checkBox11;
	private: System::Windows::Forms::CheckBox^  checkBox10;
	private: System::Windows::Forms::CheckBox^  checkBox09;
	private: System::Windows::Forms::CheckBox^  checkBox08;
	private: System::Windows::Forms::CheckBox^  checkBox07;
	private: System::Windows::Forms::CheckBox^  checkBox06;
	private: System::Windows::Forms::CheckBox^  checkBox05;
	private: System::Windows::Forms::CheckBox^  checkBox04;
	private: System::Windows::Forms::CheckBox^  checkBox03;
	private: System::Windows::Forms::CheckBox^  checkBox02;
	private: System::Windows::Forms::CheckBox^  checkBox01;
	private: System::Windows::Forms::CheckBox^  checkBox00;
	private: System::Windows::Forms::Label^  label28;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::Label^  label19;
	private: System::Windows::Forms::Label^  label18;
	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label09;
	private: System::Windows::Forms::Label^  label08;
	private: System::Windows::Forms::Label^  label07;
	private: System::Windows::Forms::Label^  label06;
	private: System::Windows::Forms::Label^  label05;
	private: System::Windows::Forms::Label^  label04;
	private: System::Windows::Forms::Label^  label03;
	private: System::Windows::Forms::Label^  label02;
	private: System::Windows::Forms::Label^  label01;
	private: System::Windows::Forms::Label^  label00;

	private: System::ComponentModel::IContainer^  components;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


			 
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;

			 System::ComponentModel::BackgroundWorker^ bgWorker;

			 Usb^ usb;
			 			 

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label88 = (gcnew System::Windows::Forms::Label());
			this->label87 = (gcnew System::Windows::Forms::Label());
			this->label86 = (gcnew System::Windows::Forms::Label());
			this->label85 = (gcnew System::Windows::Forms::Label());
			this->label84 = (gcnew System::Windows::Forms::Label());
			this->label83 = (gcnew System::Windows::Forms::Label());
			this->label82 = (gcnew System::Windows::Forms::Label());
			this->label81 = (gcnew System::Windows::Forms::Label());
			this->label80 = (gcnew System::Windows::Forms::Label());
			this->label79 = (gcnew System::Windows::Forms::Label());
			this->label78 = (gcnew System::Windows::Forms::Label());
			this->label77 = (gcnew System::Windows::Forms::Label());
			this->label76 = (gcnew System::Windows::Forms::Label());
			this->label75 = (gcnew System::Windows::Forms::Label());
			this->label74 = (gcnew System::Windows::Forms::Label());
			this->label73 = (gcnew System::Windows::Forms::Label());
			this->label72 = (gcnew System::Windows::Forms::Label());
			this->label71 = (gcnew System::Windows::Forms::Label());
			this->label70 = (gcnew System::Windows::Forms::Label());
			this->label69 = (gcnew System::Windows::Forms::Label());
			this->label68 = (gcnew System::Windows::Forms::Label());
			this->label67 = (gcnew System::Windows::Forms::Label());
			this->label66 = (gcnew System::Windows::Forms::Label());
			this->label65 = (gcnew System::Windows::Forms::Label());
			this->label64 = (gcnew System::Windows::Forms::Label());
			this->label63 = (gcnew System::Windows::Forms::Label());
			this->label62 = (gcnew System::Windows::Forms::Label());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->checkBox88 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox87 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox86 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox85 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox84 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox83 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox82 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox81 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox80 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox79 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox78 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox77 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox76 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox75 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox74 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox73 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox72 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox71 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox70 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox69 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox68 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox67 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox66 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox65 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox64 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox63 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox62 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox61 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox60 = (gcnew System::Windows::Forms::CheckBox());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->checkBox58 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox57 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox56 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox55 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox54 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox53 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox52 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox51 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox50 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox49 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox48 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox47 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox46 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox45 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox44 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox43 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox42 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox41 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox40 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox39 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox38 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox37 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox36 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox35 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox34 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox33 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox32 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox31 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox30 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox0 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label09 = (gcnew System::Windows::Forms::Label());
			this->label08 = (gcnew System::Windows::Forms::Label());
			this->label07 = (gcnew System::Windows::Forms::Label());
			this->label06 = (gcnew System::Windows::Forms::Label());
			this->label05 = (gcnew System::Windows::Forms::Label());
			this->label04 = (gcnew System::Windows::Forms::Label());
			this->label03 = (gcnew System::Windows::Forms::Label());
			this->label02 = (gcnew System::Windows::Forms::Label());
			this->label01 = (gcnew System::Windows::Forms::Label());
			this->label00 = (gcnew System::Windows::Forms::Label());
			this->checkBox28 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox27 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox26 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox25 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox24 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox23 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox22 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox21 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox20 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox19 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox18 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox17 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox16 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox15 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox14 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox13 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox12 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox11 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox10 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox09 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox08 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox07 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox06 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox05 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox04 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox03 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox02 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox01 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox00 = (gcnew System::Windows::Forms::CheckBox());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->groupBox0->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label88
			// 
			this->label88->AutoSize = true;
			this->label88->Location = System::Drawing::Point(16-3, 43);
			this->label88->Name = L"label88";
			this->label88->Size = System::Drawing::Size(21, 13);
			this->label88->TabIndex = 188;
			this->label88->Text = L"D7";
			// 
			// label87
			// 
			this->label87->AutoSize = true;
			this->label87->Location = System::Drawing::Point(30, 43);
			this->label87->Name = L"label87";
			this->label87->Size = System::Drawing::Size(13, 13);
			this->label87->TabIndex = 187;
			this->label87->Text = L"6";
			// 
			// label86
			// 
			this->label86->AutoSize = true;
			this->label86->Location = System::Drawing::Point(44, 43);
			this->label86->Name = L"label86";
			this->label86->Size = System::Drawing::Size(13, 13);
			this->label86->TabIndex = 186;
			this->label86->Text = L"5";
			// 
			// label85
			// 
			this->label85->AutoSize = true;
			this->label85->Location = System::Drawing::Point(58, 43);
			this->label85->Name = L"label85";
			this->label85->Size = System::Drawing::Size(13, 13);
			this->label85->TabIndex = 185;
			this->label85->Text = L"4";
			// 
			// label84
			// 
			this->label84->AutoSize = true;
			this->label84->Location = System::Drawing::Point(72, 43);
			this->label84->Name = L"label84";
			this->label84->Size = System::Drawing::Size(13, 13);
			this->label84->TabIndex = 184;
			this->label84->Text = L"3";
			// 
			// label83
			// 
			this->label83->AutoSize = true;
			this->label83->Location = System::Drawing::Point(86, 43);
			this->label83->Name = L"label83";
			this->label83->Size = System::Drawing::Size(13, 13);
			this->label83->TabIndex = 183;
			this->label83->Text = L"2";
			// 
			// label82
			// 
			this->label82->AutoSize = true;
			this->label82->Location = System::Drawing::Point(100, 43);
			this->label82->Name = L"label82";
			this->label82->Size = System::Drawing::Size(13, 13);
			this->label82->TabIndex = 182;
			this->label82->Text = L"1";
			// 
			// label81
			// 
			this->label81->AutoSize = true;
			this->label81->Location = System::Drawing::Point(114, 43);
			this->label81->Name = L"label81";
			this->label81->Size = System::Drawing::Size(13, 13);
			this->label81->TabIndex = 181;
			this->label81->Text = L"0";
			// 
			// label80
			// 
			this->label80->AutoSize = true;
			this->label80->Location = System::Drawing::Point(128-3+14, 43);
			this->label80->Name = L"label80";
			this->label80->Size = System::Drawing::Size(20, 13);
			this->label80->TabIndex = 180;
			this->label80->Text = L"C7";
			// 
			// label79
			// 
			this->label79->AutoSize = true;
			this->label79->Location = System::Drawing::Point(142+14, 43);
			this->label79->Name = L"label79";
			this->label79->Size = System::Drawing::Size(13, 13);
			this->label79->TabIndex = 179;
			this->label79->Text = L"6";
			// 
			// label78
			// 
			this->label78->AutoSize = true;
			this->label78->Location = System::Drawing::Point(156+14, 43);
			this->label78->Name = L"label78";
			this->label78->Size = System::Drawing::Size(13, 13);
			this->label78->TabIndex = 178;
			this->label78->Text = L"5";
			// 
			// label77
			// 
			this->label77->AutoSize = true;
			this->label77->Location = System::Drawing::Point(170+14, 43);
			this->label77->Name = L"label77";
			this->label77->Size = System::Drawing::Size(13, 13);
			this->label77->TabIndex = 177;
			this->label77->Text = L"4";
			// 
			// label76
			// 
			this->label76->AutoSize = true;
			this->label76->Location = System::Drawing::Point(184+14, 43);
			this->label76->Name = L"label76";
			this->label76->Size = System::Drawing::Size(13, 13);
			this->label76->TabIndex = 176;
			this->label76->Text = L"3";
			// 
			// label75
			// 
			this->label75->AutoSize = true;
			this->label75->Location = System::Drawing::Point(198+14, 43);
			this->label75->Name = L"label75";
			this->label75->Size = System::Drawing::Size(13, 13);
			this->label75->TabIndex = 175;
			this->label75->Text = L"2";
			// 
			// label74
			// 
			this->label74->AutoSize = true;
			this->label74->Location = System::Drawing::Point(212+14, 43);
			this->label74->Name = L"label74";
			this->label74->Size = System::Drawing::Size(13, 13);
			this->label74->TabIndex = 174;
			this->label74->Text = L"1";
			// 
			// label73
			// 
			this->label73->AutoSize = true;
			this->label73->Location = System::Drawing::Point(226+14, 43);
			this->label73->Name = L"label73";
			this->label73->Size = System::Drawing::Size(13, 13);
			this->label73->TabIndex = 173;
			this->label73->Text = L"0";
			// 
			// label72
			// 
			this->label72->AutoSize = true;
			this->label72->Location = System::Drawing::Point(240-3+28, 43);
			this->label72->Name = L"label72";
			this->label72->Size = System::Drawing::Size(20, 13);
			this->label72->TabIndex = 172;
			this->label72->Text = L"B7";
			// 
			// label71
			// 
			this->label71->AutoSize = true;
			this->label71->Location = System::Drawing::Point(254+28, 43);
			this->label71->Name = L"label71";
			this->label71->Size = System::Drawing::Size(13, 13);
			this->label71->TabIndex = 171;
			this->label71->Text = L"6";
			// 
			// label70
			// 
			this->label70->AutoSize = true;
			this->label70->Location = System::Drawing::Point(268+28, 43);
			this->label70->Name = L"label70";
			this->label70->Size = System::Drawing::Size(13, 13);
			this->label70->TabIndex = 170;
			this->label70->Text = L"5";
			// 
			// label69
			// 
			this->label69->AutoSize = true;
			this->label69->Location = System::Drawing::Point(282+28, 43);
			this->label69->Name = L"label69";
			this->label69->Size = System::Drawing::Size(13, 13);
			this->label69->TabIndex = 169;
			this->label69->Text = L"4";
			// 
			// label68
			// 
			this->label68->AutoSize = true;
			this->label68->Location = System::Drawing::Point(296+28, 43);
			this->label68->Name = L"label68";
			this->label68->Size = System::Drawing::Size(13, 13);
			this->label68->TabIndex = 168;
			this->label68->Text = L"3";
			// 
			// label67
			// 
			this->label67->AutoSize = true;
			this->label67->Location = System::Drawing::Point(310+28, 43);
			this->label67->Name = L"label67";
			this->label67->Size = System::Drawing::Size(13, 13);
			this->label67->TabIndex = 167;
			this->label67->Text = L"2";
			// 
			// label66
			// 
			this->label66->AutoSize = true;
			this->label66->Location = System::Drawing::Point(324+28, 43);
			this->label66->Name = L"label66";
			this->label66->Size = System::Drawing::Size(13, 13);
			this->label66->TabIndex = 166;
			this->label66->Text = L"1";
			// 
			// label65
			// 
			this->label65->AutoSize = true;
			this->label65->Location = System::Drawing::Point(338+28, 43);
			this->label65->Name = L"label65";
			this->label65->Size = System::Drawing::Size(13, 13);
			this->label65->TabIndex = 165;
			this->label65->Text = L"0";
			// 
			// label64
			// 
			this->label64->AutoSize = true;
			this->label64->Location = System::Drawing::Point(352-3+42, 43);
			this->label64->Name = L"label64";
			this->label64->Size = System::Drawing::Size(20, 13);
			this->label64->TabIndex = 164;
			this->label64->Text = L"E4";
			// 
			// label63
			// 
			this->label63->AutoSize = true;
			this->label63->Location = System::Drawing::Point(366-3+56, 43);
			this->label63->Name = L"label63";
			this->label63->Size = System::Drawing::Size(20, 13);
			this->label63->TabIndex = 163;
			this->label63->Text = L"A3";
			// 
			// label62
			// 
			this->label62->AutoSize = true;
			this->label62->Location = System::Drawing::Point(380+56, 43);
			this->label62->Name = L"label62";
			this->label62->Size = System::Drawing::Size(13, 13);
			this->label62->TabIndex = 162;
			this->label62->Text = L"2";
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Location = System::Drawing::Point(394+56, 43);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(13, 13);
			this->label61->TabIndex = 161;
			this->label61->Text = L"1";
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Location = System::Drawing::Point(408+56, 43);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(13, 13);
			this->label60->TabIndex = 160;
			this->label60->Text = L"0";
			// 
			// checkBox88
			// 
			this->checkBox88->AutoSize = true;
			this->checkBox88->Location = System::Drawing::Point(15, 27);
			this->checkBox88->Name = L"checkBox88";
			this->checkBox88->Size = System::Drawing::Size(15, 14);
			this->checkBox88->TabIndex = 88;
			this->checkBox88->UseVisualStyleBackColor = true;
			this->checkBox88->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox87
			// 
			this->checkBox87->AutoSize = true;
			this->checkBox87->Location = System::Drawing::Point(29, 27);
			this->checkBox87->Name = L"checkBox87";
			this->checkBox87->Size = System::Drawing::Size(15, 14);
			this->checkBox87->TabIndex = 87;
			this->checkBox87->UseVisualStyleBackColor = true;
			this->checkBox87->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox86
			// 
			this->checkBox86->AutoSize = true;
			this->checkBox86->Location = System::Drawing::Point(43, 27);
			this->checkBox86->Name = L"checkBox86";
			this->checkBox86->Size = System::Drawing::Size(15, 14);
			this->checkBox86->TabIndex = 86;
			this->checkBox86->UseVisualStyleBackColor = true;
			this->checkBox86->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox85
			// 
			this->checkBox85->AutoSize = true;
			this->checkBox85->Location = System::Drawing::Point(57, 27);
			this->checkBox85->Name = L"checkBox85";
			this->checkBox85->Size = System::Drawing::Size(15, 14);
			this->checkBox85->TabIndex = 85;
			this->checkBox85->UseVisualStyleBackColor = true;
			this->checkBox85->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox84
			// 
			this->checkBox84->AutoSize = true;
			this->checkBox84->Location = System::Drawing::Point(71, 27);
			this->checkBox84->Name = L"checkBox84";
			this->checkBox84->Size = System::Drawing::Size(15, 14);
			this->checkBox84->TabIndex = 84;
			this->checkBox84->UseVisualStyleBackColor = true;
			this->checkBox84->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox83
			// 
			this->checkBox83->AutoSize = true;
			this->checkBox83->Location = System::Drawing::Point(85, 27);
			this->checkBox83->Name = L"checkBox83";
			this->checkBox83->Size = System::Drawing::Size(15, 14);
			this->checkBox83->TabIndex = 83;
			this->checkBox83->UseVisualStyleBackColor = true;
			this->checkBox83->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox82
			// 
			this->checkBox82->AutoSize = true;
			this->checkBox82->Location = System::Drawing::Point(99, 27);
			this->checkBox82->Name = L"checkBox82";
			this->checkBox82->Size = System::Drawing::Size(15, 14);
			this->checkBox82->TabIndex = 82;
			this->checkBox82->UseVisualStyleBackColor = true;
			this->checkBox82->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox81
			// 
			this->checkBox81->AutoSize = true;
			this->checkBox81->Location = System::Drawing::Point(113, 27);
			this->checkBox81->Name = L"checkBox81";
			this->checkBox81->Size = System::Drawing::Size(15, 14);
			this->checkBox81->TabIndex = 81;
			this->checkBox81->UseVisualStyleBackColor = true;
			this->checkBox81->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox80
			// 
			this->checkBox80->AutoSize = true;
			this->checkBox80->Location = System::Drawing::Point(127+14, 27);
			this->checkBox80->Name = L"checkBox80";
			this->checkBox80->Size = System::Drawing::Size(15, 14);
			this->checkBox80->TabIndex = 80;
			this->checkBox80->UseVisualStyleBackColor = true;
			this->checkBox80->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox79
			// 
			this->checkBox79->AutoSize = true;
			this->checkBox79->Location = System::Drawing::Point(141+14, 27);
			this->checkBox79->Name = L"checkBox79";
			this->checkBox79->Size = System::Drawing::Size(15, 14);
			this->checkBox79->TabIndex = 79;
			this->checkBox79->UseVisualStyleBackColor = true;
			this->checkBox79->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox78
			// 
			this->checkBox78->AutoSize = true;
			this->checkBox78->Location = System::Drawing::Point(155+14, 27);
			this->checkBox78->Name = L"checkBox78";
			this->checkBox78->Size = System::Drawing::Size(15, 14);
			this->checkBox78->TabIndex = 78;
			this->checkBox78->UseVisualStyleBackColor = true;
			this->checkBox78->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox77
			// 
			this->checkBox77->AutoSize = true;
			this->checkBox77->Location = System::Drawing::Point(169+14, 27);
			this->checkBox77->Name = L"checkBox77";
			this->checkBox77->Size = System::Drawing::Size(15, 14);
			this->checkBox77->TabIndex = 77;
			this->checkBox77->UseVisualStyleBackColor = true;
			this->checkBox77->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox76
			// 
			this->checkBox76->AutoSize = true;
			this->checkBox76->Location = System::Drawing::Point(183+14, 27);
			this->checkBox76->Name = L"checkBox76";
			this->checkBox76->Size = System::Drawing::Size(15, 14);
			this->checkBox76->TabIndex = 76;
			this->checkBox76->UseVisualStyleBackColor = true;
			this->checkBox76->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox75
			// 
			this->checkBox75->AutoSize = true;
			this->checkBox75->Location = System::Drawing::Point(197+14, 27);
			this->checkBox75->Name = L"checkBox75";
			this->checkBox75->Size = System::Drawing::Size(15, 14);
			this->checkBox75->TabIndex = 75;
			this->checkBox75->UseVisualStyleBackColor = true;
			this->checkBox75->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox74
			// 
			this->checkBox74->AutoSize = true;
			this->checkBox74->Location = System::Drawing::Point(211+14, 27);
			this->checkBox74->Name = L"checkBox74";
			this->checkBox74->Size = System::Drawing::Size(15, 14);
			this->checkBox74->TabIndex = 74;
			this->checkBox74->UseVisualStyleBackColor = true;
			this->checkBox74->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox73
			// 
			this->checkBox73->AutoSize = true;
			this->checkBox73->Location = System::Drawing::Point(225+14, 27);
			this->checkBox73->Name = L"checkBox73";
			this->checkBox73->Size = System::Drawing::Size(15, 14);
			this->checkBox73->TabIndex = 73;
			this->checkBox73->UseVisualStyleBackColor = true;
			this->checkBox73->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox72
			// 
			this->checkBox72->AutoSize = true;
			this->checkBox72->Location = System::Drawing::Point(239+28, 27);
			this->checkBox72->Name = L"checkBox72";
			this->checkBox72->Size = System::Drawing::Size(15, 14);
			this->checkBox72->TabIndex = 72;
			this->checkBox72->UseVisualStyleBackColor = true;
			this->checkBox72->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox71
			// 
			this->checkBox71->AutoSize = true;
			this->checkBox71->Location = System::Drawing::Point(253+28, 27);
			this->checkBox71->Name = L"checkBox71";
			this->checkBox71->Size = System::Drawing::Size(15, 14);
			this->checkBox71->TabIndex = 71;
			this->checkBox71->UseVisualStyleBackColor = true;
			this->checkBox71->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox70
			// 
			this->checkBox70->AutoSize = true;
			this->checkBox70->Location = System::Drawing::Point(267+28, 27);
			this->checkBox70->Name = L"checkBox70";
			this->checkBox70->Size = System::Drawing::Size(15, 14);
			this->checkBox70->TabIndex = 70;
			this->checkBox70->UseVisualStyleBackColor = true;
			this->checkBox70->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox69
			// 
			this->checkBox69->AutoSize = true;
			this->checkBox69->Location = System::Drawing::Point(281+28, 27);
			this->checkBox69->Name = L"checkBox69";
			this->checkBox69->Size = System::Drawing::Size(15, 14);
			this->checkBox69->TabIndex = 69;
			this->checkBox69->UseVisualStyleBackColor = true;
			this->checkBox69->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox68
			// 
			this->checkBox68->AutoSize = true;
			this->checkBox68->Location = System::Drawing::Point(295+28, 27);
			this->checkBox68->Name = L"checkBox68";
			this->checkBox68->Size = System::Drawing::Size(15, 14);
			this->checkBox68->TabIndex = 68;
			this->checkBox68->UseVisualStyleBackColor = true;
			this->checkBox68->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox67
			// 
			this->checkBox67->AutoSize = true;
			this->checkBox67->Location = System::Drawing::Point(309+28, 27);
			this->checkBox67->Name = L"checkBox67";
			this->checkBox67->Size = System::Drawing::Size(15, 14);
			this->checkBox67->TabIndex = 67;
			this->checkBox67->UseVisualStyleBackColor = true;
			this->checkBox67->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox66
			// 
			this->checkBox66->AutoSize = true;
			this->checkBox66->Location = System::Drawing::Point(323+28, 27);
			this->checkBox66->Name = L"checkBox66";
			this->checkBox66->Size = System::Drawing::Size(15, 14);
			this->checkBox66->TabIndex = 66;
			this->checkBox66->UseVisualStyleBackColor = true;
			this->checkBox66->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox65
			// 
			this->checkBox65->AutoSize = true;
			this->checkBox65->Location = System::Drawing::Point(337+28, 27);
			this->checkBox65->Name = L"checkBox65";
			this->checkBox65->Size = System::Drawing::Size(15, 14);
			this->checkBox65->TabIndex = 65;
			this->checkBox65->UseVisualStyleBackColor = true;
			this->checkBox65->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox64
			// 
			this->checkBox64->AutoSize = true;
			this->checkBox64->Location = System::Drawing::Point(351+42, 27);
			this->checkBox64->Name = L"checkBox64";
			this->checkBox64->Size = System::Drawing::Size(15, 14);
			this->checkBox64->TabIndex = 64;
			this->checkBox64->UseVisualStyleBackColor = true;
			this->checkBox64->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox63
			// 
			this->checkBox63->AutoSize = true;
			this->checkBox63->Location = System::Drawing::Point(365+56, 27);
			this->checkBox63->Name = L"checkBox63";
			this->checkBox63->Size = System::Drawing::Size(15, 14);
			this->checkBox63->TabIndex = 63;
			this->checkBox63->UseVisualStyleBackColor = true;
			this->checkBox63->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox62
			// 
			this->checkBox62->AutoSize = true;
			this->checkBox62->Location = System::Drawing::Point(379+56, 27);
			this->checkBox62->Name = L"checkBox62";
			this->checkBox62->Size = System::Drawing::Size(15, 14);
			this->checkBox62->TabIndex = 62;
			this->checkBox62->UseVisualStyleBackColor = true;
			this->checkBox62->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox61
			// 
			this->checkBox61->AutoSize = true;
			this->checkBox61->Location = System::Drawing::Point(393+56, 27);
			this->checkBox61->Name = L"checkBox61";
			this->checkBox61->Size = System::Drawing::Size(15, 14);
			this->checkBox61->TabIndex = 61;
			this->checkBox61->UseVisualStyleBackColor = true;
			this->checkBox61->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox60
			// 
			this->checkBox60->AutoSize = true;
			this->checkBox60->Location = System::Drawing::Point(407+56, 27);
			this->checkBox60->Name = L"checkBox60";
			this->checkBox60->Size = System::Drawing::Size(15, 14);
			this->checkBox60->TabIndex = 60;
			this->checkBox60->UseVisualStyleBackColor = true;
			this->checkBox60->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Location = System::Drawing::Point(16-3, 43);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(21, 13);
			this->label58->TabIndex = 158;
			this->label58->Text = L"D7";
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Location = System::Drawing::Point(30, 43);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(13, 13);
			this->label57->TabIndex = 157;
			this->label57->Text = L"6";
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Location = System::Drawing::Point(44, 43);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(13, 13);
			this->label56->TabIndex = 156;
			this->label56->Text = L"5";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Location = System::Drawing::Point(58, 43);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(13, 13);
			this->label55->TabIndex = 155;
			this->label55->Text = L"4";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Location = System::Drawing::Point(72, 43);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(13, 13);
			this->label54->TabIndex = 154;
			this->label54->Text = L"3";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Location = System::Drawing::Point(86, 43);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(13, 13);
			this->label53->TabIndex = 153;
			this->label53->Text = L"2";
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Location = System::Drawing::Point(100, 43);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(13, 13);
			this->label52->TabIndex = 152;
			this->label52->Text = L"1";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Location = System::Drawing::Point(114, 43);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(13, 13);
			this->label51->TabIndex = 151;
			this->label51->Text = L"0";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Location = System::Drawing::Point(128-3+14, 43);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(20, 13);
			this->label50->TabIndex = 150;
			this->label50->Text = L"C7";
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Location = System::Drawing::Point(142+14, 43);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(13, 13);
			this->label49->TabIndex = 149;
			this->label49->Text = L"6";
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Location = System::Drawing::Point(156+14, 43);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(13, 13);
			this->label48->TabIndex = 148;
			this->label48->Text = L"5";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(170+14, 43);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(13, 13);
			this->label47->TabIndex = 147;
			this->label47->Text = L"4";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(184+14, 43);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(13, 13);
			this->label46->TabIndex = 146;
			this->label46->Text = L"3";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(198+14, 43);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(13, 13);
			this->label45->TabIndex = 145;
			this->label45->Text = L"2";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(212+14, 43);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(13, 13);
			this->label44->TabIndex = 144;
			this->label44->Text = L"1";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Location = System::Drawing::Point(226+14, 43);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(13, 13);
			this->label43->TabIndex = 143;
			this->label43->Text = L"0";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(240-3+28, 43);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(20, 13);
			this->label42->TabIndex = 142;
			this->label42->Text = L"B7";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(254+28, 43);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(13, 13);
			this->label41->TabIndex = 141;
			this->label41->Text = L"6";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(268+28, 43);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(13, 13);
			this->label40->TabIndex = 140;
			this->label40->Text = L"5";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(282+28, 43);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(13, 13);
			this->label39->TabIndex = 139;
			this->label39->Text = L"4";
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(296+28, 43);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(13, 13);
			this->label38->TabIndex = 138;
			this->label38->Text = L"3";
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(310+28, 43);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(13, 13);
			this->label37->TabIndex = 137;
			this->label37->Text = L"2";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(324+28, 43);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(13, 13);
			this->label36->TabIndex = 136;
			this->label36->Text = L"1";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(338+28, 43);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(13, 13);
			this->label35->TabIndex = 135;
			this->label35->Text = L"0";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(352-3+42, 43);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(20, 13);
			this->label34->TabIndex = 134;
			this->label34->Text = L"E4";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(366-3+56, 43);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(20, 13);
			this->label33->TabIndex = 133;
			this->label33->Text = L"A3";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(380+56, 43);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(13, 13);
			this->label32->TabIndex = 132;
			this->label32->Text = L"2";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(394+56, 43);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(13, 13);
			this->label31->TabIndex = 131;
			this->label31->Text = L"1";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(408+56, 43);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(13, 13);
			this->label30->TabIndex = 130;
			this->label30->Text = L"0";
			// 
			// checkBox58
			// 
			this->checkBox58->AutoSize = true;
			this->checkBox58->Enabled = false;
			this->checkBox58->Location = System::Drawing::Point(15, 27);
			this->checkBox58->Name = L"checkBox58";
			this->checkBox58->Size = System::Drawing::Size(15, 14);
			this->checkBox58->TabIndex = 58;
			this->checkBox58->UseVisualStyleBackColor = true;
			// 
			// checkBox57
			// 
			this->checkBox57->AutoSize = true;
			this->checkBox57->Enabled = false;
			this->checkBox57->Location = System::Drawing::Point(29, 27);
			this->checkBox57->Name = L"checkBox57";
			this->checkBox57->Size = System::Drawing::Size(15, 14);
			this->checkBox57->TabIndex = 57;
			this->checkBox57->UseVisualStyleBackColor = true;
			// 
			// checkBox56
			// 
			this->checkBox56->AutoSize = true;
			this->checkBox56->Enabled = false;
			this->checkBox56->Location = System::Drawing::Point(43, 27);
			this->checkBox56->Name = L"checkBox56";
			this->checkBox56->Size = System::Drawing::Size(15, 14);
			this->checkBox56->TabIndex = 56;
			this->checkBox56->UseVisualStyleBackColor = true;
			// 
			// checkBox55
			// 
			this->checkBox55->AutoSize = true;
			this->checkBox55->Enabled = false;
			this->checkBox55->Location = System::Drawing::Point(57, 27);
			this->checkBox55->Name = L"checkBox55";
			this->checkBox55->Size = System::Drawing::Size(15, 14);
			this->checkBox55->TabIndex = 55;
			this->checkBox55->UseVisualStyleBackColor = true;
			// 
			// checkBox54
			// 
			this->checkBox54->AutoSize = true;
			this->checkBox54->Enabled = false;
			this->checkBox54->Location = System::Drawing::Point(71, 27);
			this->checkBox54->Name = L"checkBox54";
			this->checkBox54->Size = System::Drawing::Size(15, 14);
			this->checkBox54->TabIndex = 54;
			this->checkBox54->UseVisualStyleBackColor = true;
			// 
			// checkBox53
			// 
			this->checkBox53->AutoSize = true;
			this->checkBox53->Enabled = false;
			this->checkBox53->Location = System::Drawing::Point(85, 27);
			this->checkBox53->Name = L"checkBox53";
			this->checkBox53->Size = System::Drawing::Size(15, 14);
			this->checkBox53->TabIndex = 53;
			this->checkBox53->UseVisualStyleBackColor = true;
			// 
			// checkBox52
			// 
			this->checkBox52->AutoSize = true;
			this->checkBox52->Enabled = false;
			this->checkBox52->Location = System::Drawing::Point(99, 27);
			this->checkBox52->Name = L"checkBox52";
			this->checkBox52->Size = System::Drawing::Size(15, 14);
			this->checkBox52->TabIndex = 52;
			this->checkBox52->UseVisualStyleBackColor = true;
			// 
			// checkBox51
			// 
			this->checkBox51->AutoSize = true;
			this->checkBox51->Enabled = false;
			this->checkBox51->Location = System::Drawing::Point(113, 27);
			this->checkBox51->Name = L"checkBox51";
			this->checkBox51->Size = System::Drawing::Size(15, 14);
			this->checkBox51->TabIndex = 51;
			this->checkBox51->UseVisualStyleBackColor = true;
			// 
			// checkBox50
			// 
			this->checkBox50->AutoSize = true;
			this->checkBox50->Enabled = false;
			this->checkBox50->Location = System::Drawing::Point(127+14, 27);
			this->checkBox50->Name = L"checkBox50";
			this->checkBox50->Size = System::Drawing::Size(15, 14);
			this->checkBox50->TabIndex = 50;
			this->checkBox50->UseVisualStyleBackColor = true;
			// 
			// checkBox49
			// 
			this->checkBox49->AutoSize = true;
			this->checkBox49->Enabled = false;
			this->checkBox49->Location = System::Drawing::Point(141+14, 27);
			this->checkBox49->Name = L"checkBox49";
			this->checkBox49->Size = System::Drawing::Size(15, 14);
			this->checkBox49->TabIndex = 49;
			this->checkBox49->UseVisualStyleBackColor = true;
			// 
			// checkBox48
			// 
			this->checkBox48->AutoSize = true;
			this->checkBox48->Enabled = false;
			this->checkBox48->Location = System::Drawing::Point(155+14, 27);
			this->checkBox48->Name = L"checkBox48";
			this->checkBox48->Size = System::Drawing::Size(15, 14);
			this->checkBox48->TabIndex = 48;
			this->checkBox48->UseVisualStyleBackColor = true;
			// 
			// checkBox47
			// 
			this->checkBox47->AutoSize = true;
			this->checkBox47->Enabled = false;
			this->checkBox47->Location = System::Drawing::Point(169+14, 27);
			this->checkBox47->Name = L"checkBox47";
			this->checkBox47->Size = System::Drawing::Size(15, 14);
			this->checkBox47->TabIndex = 47;
			this->checkBox47->UseVisualStyleBackColor = true;
			// 
			// checkBox46
			// 
			this->checkBox46->AutoSize = true;
			this->checkBox46->Enabled = false;
			this->checkBox46->Location = System::Drawing::Point(183+14, 27);
			this->checkBox46->Name = L"checkBox46";
			this->checkBox46->Size = System::Drawing::Size(15, 14);
			this->checkBox46->TabIndex = 46;
			this->checkBox46->UseVisualStyleBackColor = true;
			// 
			// checkBox45
			// 
			this->checkBox45->AutoSize = true;
			this->checkBox45->Enabled = false;
			this->checkBox45->Location = System::Drawing::Point(197+14, 27);
			this->checkBox45->Name = L"checkBox45";
			this->checkBox45->Size = System::Drawing::Size(15, 14);
			this->checkBox45->TabIndex = 45;
			this->checkBox45->UseVisualStyleBackColor = true;
			// 
			// checkBox44
			// 
			this->checkBox44->AutoSize = true;
			this->checkBox44->Enabled = false;
			this->checkBox44->Location = System::Drawing::Point(211+14, 27);
			this->checkBox44->Name = L"checkBox44";
			this->checkBox44->Size = System::Drawing::Size(15, 14);
			this->checkBox44->TabIndex = 44;
			this->checkBox44->UseVisualStyleBackColor = true;
			// 
			// checkBox43
			// 
			this->checkBox43->AutoSize = true;
			this->checkBox43->Enabled = false;
			this->checkBox43->Location = System::Drawing::Point(225+14, 27);
			this->checkBox43->Name = L"checkBox43";
			this->checkBox43->Size = System::Drawing::Size(15, 14);
			this->checkBox43->TabIndex = 43;
			this->checkBox43->UseVisualStyleBackColor = true;
			// 
			// checkBox42
			// 
			this->checkBox42->AutoSize = true;
			this->checkBox42->Enabled = false;
			this->checkBox42->Location = System::Drawing::Point(239+28, 27);
			this->checkBox42->Name = L"checkBox42";
			this->checkBox42->Size = System::Drawing::Size(15, 14);
			this->checkBox42->TabIndex = 42;
			this->checkBox42->UseVisualStyleBackColor = true;
			// 
			// checkBox41
			// 
			this->checkBox41->AutoSize = true;
			this->checkBox41->Enabled = false;
			this->checkBox41->Location = System::Drawing::Point(253+28, 27);
			this->checkBox41->Name = L"checkBox41";
			this->checkBox41->Size = System::Drawing::Size(15, 14);
			this->checkBox41->TabIndex = 41;
			this->checkBox41->UseVisualStyleBackColor = true;
			// 
			// checkBox40
			// 
			this->checkBox40->AutoSize = true;
			this->checkBox40->Enabled = false;
			this->checkBox40->Location = System::Drawing::Point(267+28, 27);
			this->checkBox40->Name = L"checkBox40";
			this->checkBox40->Size = System::Drawing::Size(15, 14);
			this->checkBox40->TabIndex = 40;
			this->checkBox40->UseVisualStyleBackColor = true;
			// 
			// checkBox39
			// 
			this->checkBox39->AutoSize = true;
			this->checkBox39->Enabled = false;
			this->checkBox39->Location = System::Drawing::Point(281+28, 27);
			this->checkBox39->Name = L"checkBox39";
			this->checkBox39->Size = System::Drawing::Size(15, 14);
			this->checkBox39->TabIndex = 39;
			this->checkBox39->UseVisualStyleBackColor = true;
			// 
			// checkBox38
			// 
			this->checkBox38->AutoSize = true;
			this->checkBox38->Enabled = false;
			this->checkBox38->Location = System::Drawing::Point(295+28, 27);
			this->checkBox38->Name = L"checkBox38";
			this->checkBox38->Size = System::Drawing::Size(15, 14);
			this->checkBox38->TabIndex = 38;
			this->checkBox38->UseVisualStyleBackColor = true;
			// 
			// checkBox37
			// 
			this->checkBox37->AutoSize = true;
			this->checkBox37->Enabled = false;
			this->checkBox37->Location = System::Drawing::Point(309+28, 27);
			this->checkBox37->Name = L"checkBox37";
			this->checkBox37->Size = System::Drawing::Size(15, 14);
			this->checkBox37->TabIndex = 37;
			this->checkBox37->UseVisualStyleBackColor = true;
			// 
			// checkBox36
			// 
			this->checkBox36->AutoSize = true;
			this->checkBox36->Enabled = false;
			this->checkBox36->Location = System::Drawing::Point(323+28, 27);
			this->checkBox36->Name = L"checkBox36";
			this->checkBox36->Size = System::Drawing::Size(15, 14);
			this->checkBox36->TabIndex = 36;
			this->checkBox36->UseVisualStyleBackColor = true;
			// 
			// checkBox35
			// 
			this->checkBox35->AutoSize = true;
			this->checkBox35->Enabled = false;
			this->checkBox35->Location = System::Drawing::Point(337+28, 27);
			this->checkBox35->Name = L"checkBox35";
			this->checkBox35->Size = System::Drawing::Size(15, 14);
			this->checkBox35->TabIndex = 35;
			this->checkBox35->UseVisualStyleBackColor = true;
			// 
			// checkBox34
			// 
			this->checkBox34->AutoSize = true;
			this->checkBox34->Enabled = false;
			this->checkBox34->Location = System::Drawing::Point(351+42, 27);
			this->checkBox34->Name = L"checkBox34";
			this->checkBox34->Size = System::Drawing::Size(15, 14);
			this->checkBox34->TabIndex = 34;
			this->checkBox34->UseVisualStyleBackColor = true;
			// 
			// checkBox33
			// 
			this->checkBox33->AutoSize = true;
			this->checkBox33->Enabled = false;
			this->checkBox33->Location = System::Drawing::Point(365+56, 27);
			this->checkBox33->Name = L"checkBox33";
			this->checkBox33->Size = System::Drawing::Size(15, 14);
			this->checkBox33->TabIndex = 33;
			this->checkBox33->UseVisualStyleBackColor = true;
			// 
			// checkBox32
			// 
			this->checkBox32->AutoSize = true;
			this->checkBox32->Enabled = false;
			this->checkBox32->Location = System::Drawing::Point(379+56, 27);
			this->checkBox32->Name = L"checkBox32";
			this->checkBox32->Size = System::Drawing::Size(15, 14);
			this->checkBox32->TabIndex = 32;
			this->checkBox32->UseVisualStyleBackColor = true;
			// 
			// checkBox31
			// 
			this->checkBox31->AutoSize = true;
			this->checkBox31->Enabled = false;
			this->checkBox31->Location = System::Drawing::Point(393+56, 27);
			this->checkBox31->Name = L"checkBox31";
			this->checkBox31->Size = System::Drawing::Size(15, 14);
			this->checkBox31->TabIndex = 31;
			this->checkBox31->UseVisualStyleBackColor = true;
			// 
			// checkBox30
			// 
			this->checkBox30->AutoSize = true;
			this->checkBox30->Enabled = false;
			this->checkBox30->Location = System::Drawing::Point(407+56, 27);
			this->checkBox30->Name = L"checkBox30";
			this->checkBox30->Size = System::Drawing::Size(15, 14);
			this->checkBox30->TabIndex = 30;
			this->checkBox30->UseVisualStyleBackColor = true;
			// 
			// groupBox0
			// 
			this->groupBox0->Controls->Add(this->label88);
			this->groupBox0->Controls->Add(this->label87);
			this->groupBox0->Controls->Add(this->label86);
			this->groupBox0->Controls->Add(this->label85);
			this->groupBox0->Controls->Add(this->label84);
			this->groupBox0->Controls->Add(this->label83);
			this->groupBox0->Controls->Add(this->label82);
			this->groupBox0->Controls->Add(this->label81);
			this->groupBox0->Controls->Add(this->label80);
			this->groupBox0->Controls->Add(this->label79);
			this->groupBox0->Controls->Add(this->label78);
			this->groupBox0->Controls->Add(this->label77);
			this->groupBox0->Controls->Add(this->label76);
			this->groupBox0->Controls->Add(this->label75);
			this->groupBox0->Controls->Add(this->label74);
			this->groupBox0->Controls->Add(this->label73);
			this->groupBox0->Controls->Add(this->label72);
			this->groupBox0->Controls->Add(this->label71);
			this->groupBox0->Controls->Add(this->label70);
			this->groupBox0->Controls->Add(this->label69);
			this->groupBox0->Controls->Add(this->label68);
			this->groupBox0->Controls->Add(this->label67);
			this->groupBox0->Controls->Add(this->label66);
			this->groupBox0->Controls->Add(this->label65);
			this->groupBox0->Controls->Add(this->label64);
			this->groupBox0->Controls->Add(this->label63);
			this->groupBox0->Controls->Add(this->label62);
			this->groupBox0->Controls->Add(this->label61);
			this->groupBox0->Controls->Add(this->label60);
			this->groupBox0->Controls->Add(this->checkBox88);
			this->groupBox0->Controls->Add(this->checkBox87);
			this->groupBox0->Controls->Add(this->checkBox86);
			this->groupBox0->Controls->Add(this->checkBox85);
			this->groupBox0->Controls->Add(this->checkBox84);
			this->groupBox0->Controls->Add(this->checkBox83);
			this->groupBox0->Controls->Add(this->checkBox82);
			this->groupBox0->Controls->Add(this->checkBox81);
			this->groupBox0->Controls->Add(this->checkBox80);
			this->groupBox0->Controls->Add(this->checkBox79);
			this->groupBox0->Controls->Add(this->checkBox78);
			this->groupBox0->Controls->Add(this->checkBox77);
			this->groupBox0->Controls->Add(this->checkBox76);
			this->groupBox0->Controls->Add(this->checkBox75);
			this->groupBox0->Controls->Add(this->checkBox74);
			this->groupBox0->Controls->Add(this->checkBox73);
			this->groupBox0->Controls->Add(this->checkBox72);
			this->groupBox0->Controls->Add(this->checkBox71);
			this->groupBox0->Controls->Add(this->checkBox70);
			this->groupBox0->Controls->Add(this->checkBox69);
			this->groupBox0->Controls->Add(this->checkBox68);
			this->groupBox0->Controls->Add(this->checkBox67);
			this->groupBox0->Controls->Add(this->checkBox66);
			this->groupBox0->Controls->Add(this->checkBox65);
			this->groupBox0->Controls->Add(this->checkBox64);
			this->groupBox0->Controls->Add(this->checkBox63);
			this->groupBox0->Controls->Add(this->checkBox62);
			this->groupBox0->Controls->Add(this->checkBox61);
			this->groupBox0->Controls->Add(this->checkBox60);
			this->groupBox0->Location = System::Drawing::Point(30, 3);
			this->groupBox0->Name = L"groupBox0";
			this->groupBox0->Size = System::Drawing::Size(435+56, 60);
			this->groupBox0->TabIndex = 1;
			this->groupBox0->TabStop = false;
			this->groupBox0->Text = L"TRIS";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label58);
			this->groupBox1->Controls->Add(this->label57);
			this->groupBox1->Controls->Add(this->label56);
			this->groupBox1->Controls->Add(this->label55);
			this->groupBox1->Controls->Add(this->label54);
			this->groupBox1->Controls->Add(this->label53);
			this->groupBox1->Controls->Add(this->label52);
			this->groupBox1->Controls->Add(this->label51);
			this->groupBox1->Controls->Add(this->label50);
			this->groupBox1->Controls->Add(this->label49);
			this->groupBox1->Controls->Add(this->label48);
			this->groupBox1->Controls->Add(this->label47);
			this->groupBox1->Controls->Add(this->label46);
			this->groupBox1->Controls->Add(this->label45);
			this->groupBox1->Controls->Add(this->label44);
			this->groupBox1->Controls->Add(this->label43);
			this->groupBox1->Controls->Add(this->label42);
			this->groupBox1->Controls->Add(this->label41);
			this->groupBox1->Controls->Add(this->label40);
			this->groupBox1->Controls->Add(this->label39);
			this->groupBox1->Controls->Add(this->label38);
			this->groupBox1->Controls->Add(this->label37);
			this->groupBox1->Controls->Add(this->label36);
			this->groupBox1->Controls->Add(this->label35);
			this->groupBox1->Controls->Add(this->label34);
			this->groupBox1->Controls->Add(this->label33);
			this->groupBox1->Controls->Add(this->label32);
			this->groupBox1->Controls->Add(this->label31);
			this->groupBox1->Controls->Add(this->label30);
			this->groupBox1->Controls->Add(this->checkBox58);
			this->groupBox1->Controls->Add(this->checkBox57);
			this->groupBox1->Controls->Add(this->checkBox56);
			this->groupBox1->Controls->Add(this->checkBox55);
			this->groupBox1->Controls->Add(this->checkBox54);
			this->groupBox1->Controls->Add(this->checkBox53);
			this->groupBox1->Controls->Add(this->checkBox52);
			this->groupBox1->Controls->Add(this->checkBox51);
			this->groupBox1->Controls->Add(this->checkBox50);
			this->groupBox1->Controls->Add(this->checkBox49);
			this->groupBox1->Controls->Add(this->checkBox48);
			this->groupBox1->Controls->Add(this->checkBox47);
			this->groupBox1->Controls->Add(this->checkBox46);
			this->groupBox1->Controls->Add(this->checkBox45);
			this->groupBox1->Controls->Add(this->checkBox44);
			this->groupBox1->Controls->Add(this->checkBox43);
			this->groupBox1->Controls->Add(this->checkBox42);
			this->groupBox1->Controls->Add(this->checkBox41);
			this->groupBox1->Controls->Add(this->checkBox40);
			this->groupBox1->Controls->Add(this->checkBox39);
			this->groupBox1->Controls->Add(this->checkBox38);
			this->groupBox1->Controls->Add(this->checkBox37);
			this->groupBox1->Controls->Add(this->checkBox36);
			this->groupBox1->Controls->Add(this->checkBox35);
			this->groupBox1->Controls->Add(this->checkBox34);
			this->groupBox1->Controls->Add(this->checkBox33);
			this->groupBox1->Controls->Add(this->checkBox32);
			this->groupBox1->Controls->Add(this->checkBox31);
			this->groupBox1->Controls->Add(this->checkBox30);
			this->groupBox1->Location = System::Drawing::Point(30, 68);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(435+56, 60);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"INPUT";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label28);
			this->groupBox2->Controls->Add(this->label27);
			this->groupBox2->Controls->Add(this->label26);
			this->groupBox2->Controls->Add(this->label25);
			this->groupBox2->Controls->Add(this->label24);
			this->groupBox2->Controls->Add(this->label23);
			this->groupBox2->Controls->Add(this->label22);
			this->groupBox2->Controls->Add(this->label21);
			this->groupBox2->Controls->Add(this->label20);
			this->groupBox2->Controls->Add(this->label19);
			this->groupBox2->Controls->Add(this->label18);
			this->groupBox2->Controls->Add(this->label17);
			this->groupBox2->Controls->Add(this->label16);
			this->groupBox2->Controls->Add(this->label15);
			this->groupBox2->Controls->Add(this->label14);
			this->groupBox2->Controls->Add(this->label13);
			this->groupBox2->Controls->Add(this->label12);
			this->groupBox2->Controls->Add(this->label11);
			this->groupBox2->Controls->Add(this->label10);
			this->groupBox2->Controls->Add(this->label09);
			this->groupBox2->Controls->Add(this->label08);
			this->groupBox2->Controls->Add(this->label07);
			this->groupBox2->Controls->Add(this->label06);
			this->groupBox2->Controls->Add(this->label05);
			this->groupBox2->Controls->Add(this->label04);
			this->groupBox2->Controls->Add(this->label03);
			this->groupBox2->Controls->Add(this->label02);
			this->groupBox2->Controls->Add(this->label01);
			this->groupBox2->Controls->Add(this->label00);
			this->groupBox2->Controls->Add(this->checkBox28);
			this->groupBox2->Controls->Add(this->checkBox27);
			this->groupBox2->Controls->Add(this->checkBox26);
			this->groupBox2->Controls->Add(this->checkBox25);
			this->groupBox2->Controls->Add(this->checkBox24);
			this->groupBox2->Controls->Add(this->checkBox23);
			this->groupBox2->Controls->Add(this->checkBox22);
			this->groupBox2->Controls->Add(this->checkBox21);
			this->groupBox2->Controls->Add(this->checkBox20);
			this->groupBox2->Controls->Add(this->checkBox19);
			this->groupBox2->Controls->Add(this->checkBox18);
			this->groupBox2->Controls->Add(this->checkBox17);
			this->groupBox2->Controls->Add(this->checkBox16);
			this->groupBox2->Controls->Add(this->checkBox15);
			this->groupBox2->Controls->Add(this->checkBox14);
			this->groupBox2->Controls->Add(this->checkBox13);
			this->groupBox2->Controls->Add(this->checkBox12);
			this->groupBox2->Controls->Add(this->checkBox11);
			this->groupBox2->Controls->Add(this->checkBox10);
			this->groupBox2->Controls->Add(this->checkBox09);
			this->groupBox2->Controls->Add(this->checkBox08);
			this->groupBox2->Controls->Add(this->checkBox07);
			this->groupBox2->Controls->Add(this->checkBox06);
			this->groupBox2->Controls->Add(this->checkBox05);
			this->groupBox2->Controls->Add(this->checkBox04);
			this->groupBox2->Controls->Add(this->checkBox03);
			this->groupBox2->Controls->Add(this->checkBox02);
			this->groupBox2->Controls->Add(this->checkBox01);
			this->groupBox2->Controls->Add(this->checkBox00);
			this->groupBox2->Location = System::Drawing::Point(30, 133);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(435+56, 60);
			this->groupBox2->TabIndex = 3;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"OUTPUT";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(16-3, 43);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(21, 13);
			this->label28->TabIndex = 28;
			this->label28->Text = L"D7";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(30, 43);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(13, 13);
			this->label27->TabIndex = 27;
			this->label27->Text = L"6";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(44, 43);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 13);
			this->label26->TabIndex = 26;
			this->label26->Text = L"5";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(58, 43);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(13, 13);
			this->label25->TabIndex = 25;
			this->label25->Text = L"4";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(72, 43);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(13, 13);
			this->label24->TabIndex = 24;
			this->label24->Text = L"3";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(86, 43);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(13, 13);
			this->label23->TabIndex = 23;
			this->label23->Text = L"2";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(100, 43);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(13, 13);
			this->label22->TabIndex = 22;
			this->label22->Text = L"1";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(114, 43);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(13, 13);
			this->label21->TabIndex = 21;
			this->label21->Text = L"0";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(128-3+14, 43);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(20, 13);
			this->label20->TabIndex = 20;
			this->label20->Text = L"C7";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(142+14, 43);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(13, 13);
			this->label19->TabIndex = 19;
			this->label19->Text = L"6";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(156+14, 43);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(13, 13);
			this->label18->TabIndex = 18;
			this->label18->Text = L"5";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(170+14, 43);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(13, 13);
			this->label17->TabIndex = 17;
			this->label17->Text = L"4";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(184+14, 43);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(13, 13);
			this->label16->TabIndex = 16;
			this->label16->Text = L"3";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(198+14, 43);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(13, 13);
			this->label15->TabIndex = 15;
			this->label15->Text = L"2";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(212+14, 43);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(13, 13);
			this->label14->TabIndex = 14;
			this->label14->Text = L"1";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(226+14, 43);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(13, 13);
			this->label13->TabIndex = 13;
			this->label13->Text = L"0";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(240-3+28, 43);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(20, 13);
			this->label12->TabIndex = 12;
			this->label12->Text = L"B7";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(254+28, 43);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(13, 13);
			this->label11->TabIndex = 11;
			this->label11->Text = L"6";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(268+28, 43);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(13, 13);
			this->label10->TabIndex = 10;
			this->label10->Text = L"5";
			// 
			// label09
			// 
			this->label09->AutoSize = true;
			this->label09->Location = System::Drawing::Point(282+28, 43);
			this->label09->Name = L"label09";
			this->label09->Size = System::Drawing::Size(13, 13);
			this->label09->TabIndex = 9;
			this->label09->Text = L"4";
			// 
			// label08
			// 
			this->label08->AutoSize = true;
			this->label08->Location = System::Drawing::Point(296+28, 43);
			this->label08->Name = L"label08";
			this->label08->Size = System::Drawing::Size(13, 13);
			this->label08->TabIndex = 8;
			this->label08->Text = L"3";
			// 
			// label07
			// 
			this->label07->AutoSize = true;
			this->label07->Location = System::Drawing::Point(310+28, 43);
			this->label07->Name = L"label07";
			this->label07->Size = System::Drawing::Size(13, 13);
			this->label07->TabIndex = 7;
			this->label07->Text = L"2";
			// 
			// label06
			// 
			this->label06->AutoSize = true;
			this->label06->Location = System::Drawing::Point(324+28, 43);
			this->label06->Name = L"label06";
			this->label06->Size = System::Drawing::Size(13, 13);
			this->label06->TabIndex = 6;
			this->label06->Text = L"1";
			// 
			// label05
			// 
			this->label05->AutoSize = true;
			this->label05->Location = System::Drawing::Point(338+28, 43);
			this->label05->Name = L"label05";
			this->label05->Size = System::Drawing::Size(13, 13);
			this->label05->TabIndex = 5;
			this->label05->Text = L"0";
			// 
			// label04
			// 
			this->label04->AutoSize = true;
			this->label04->Location = System::Drawing::Point(352-3+42, 43);
			this->label04->Name = L"label04";
			this->label04->Size = System::Drawing::Size(20, 13);
			this->label04->TabIndex = 4;
			this->label04->Text = L"E4";
			// 
			// label03
			// 
			this->label03->AutoSize = true;
			this->label03->Location = System::Drawing::Point(366-3+56, 43);
			this->label03->Name = L"label03";
			this->label03->Size = System::Drawing::Size(20, 13);
			this->label03->TabIndex = 3;
			this->label03->Text = L"A3";
			// 
			// label02
			// 
			this->label02->AutoSize = true;
			this->label02->Location = System::Drawing::Point(380+56, 43);
			this->label02->Name = L"label02";
			this->label02->Size = System::Drawing::Size(13, 13);
			this->label02->TabIndex = 2;
			this->label02->Text = L"2";
			// 
			// label01
			// 
			this->label01->AutoSize = true;
			this->label01->Location = System::Drawing::Point(394+56, 43);
			this->label01->Name = L"label01";
			this->label01->Size = System::Drawing::Size(13, 13);
			this->label01->TabIndex = 1;
			this->label01->Text = L"1";
			// 
			// label00
			// 
			this->label00->AutoSize = true;
			this->label00->Location = System::Drawing::Point(408+56, 43);
			this->label00->Name = L"label00";
			this->label00->Size = System::Drawing::Size(13, 13);
			this->label00->TabIndex = 0;
			this->label00->Text = L"0";
			// 
			// checkBox28
			// 
			this->checkBox28->AutoSize = true;
			this->checkBox28->Location = System::Drawing::Point(15, 27);
			this->checkBox28->Name = L"checkBox28";
			this->checkBox28->Size = System::Drawing::Size(15, 14);
			this->checkBox28->TabIndex = 128;
			this->checkBox28->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox28->UseVisualStyleBackColor = true;
			this->checkBox28->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox27
			// 
			this->checkBox27->AutoSize = true;
			this->checkBox27->Location = System::Drawing::Point(29, 27);
			this->checkBox27->Name = L"checkBox27";
			this->checkBox27->Size = System::Drawing::Size(15, 14);
			this->checkBox27->TabIndex = 127;
			this->checkBox27->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox27->UseVisualStyleBackColor = true;
			this->checkBox27->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox26
			// 
			this->checkBox26->AutoSize = true;
			this->checkBox26->Location = System::Drawing::Point(43, 27);
			this->checkBox26->Name = L"checkBox26";
			this->checkBox26->Size = System::Drawing::Size(15, 14);
			this->checkBox26->TabIndex = 126;
			this->checkBox26->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox26->UseVisualStyleBackColor = true;
			this->checkBox26->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox25
			// 
			this->checkBox25->AutoSize = true;
			this->checkBox25->Location = System::Drawing::Point(57, 27);
			this->checkBox25->Name = L"checkBox25";
			this->checkBox25->Size = System::Drawing::Size(15, 14);
			this->checkBox25->TabIndex = 125;
			this->checkBox25->UseVisualStyleBackColor = true;
			this->checkBox25->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox24
			// 
			this->checkBox24->AutoSize = true;
			this->checkBox24->Location = System::Drawing::Point(71, 27);
			this->checkBox24->Name = L"checkBox24";
			this->checkBox24->Size = System::Drawing::Size(15, 14);
			this->checkBox24->TabIndex = 124;
			this->checkBox24->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox24->UseVisualStyleBackColor = true;
			this->checkBox24->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox23
			// 
			this->checkBox23->AutoSize = true;
			this->checkBox23->Location = System::Drawing::Point(85, 27);
			this->checkBox23->Name = L"checkBox23";
			this->checkBox23->Size = System::Drawing::Size(15, 14);
			this->checkBox23->TabIndex = 123;
			this->checkBox23->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox23->UseVisualStyleBackColor = true;
			this->checkBox23->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox22
			// 
			this->checkBox22->AutoSize = true;
			this->checkBox22->Location = System::Drawing::Point(99, 27);
			this->checkBox22->Name = L"checkBox22";
			this->checkBox22->Size = System::Drawing::Size(15, 14);
			this->checkBox22->TabIndex = 122;
			this->checkBox22->UseVisualStyleBackColor = true;
			this->checkBox22->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox21
			// 
			this->checkBox21->AutoSize = true;
			this->checkBox21->Location = System::Drawing::Point(113, 27);
			this->checkBox21->Name = L"checkBox21";
			this->checkBox21->Size = System::Drawing::Size(15, 14);
			this->checkBox21->TabIndex = 121;
			this->checkBox21->UseVisualStyleBackColor = true;
			this->checkBox21->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox20
			// 
			this->checkBox20->AutoSize = true;
			this->checkBox20->Location = System::Drawing::Point(127+14, 27);
			this->checkBox20->Name = L"checkBox20";
			this->checkBox20->Size = System::Drawing::Size(15, 14);
			this->checkBox20->TabIndex = 120;
			this->checkBox20->UseVisualStyleBackColor = true;
			this->checkBox20->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox19
			// 
			this->checkBox19->AutoSize = true;
			this->checkBox19->Location = System::Drawing::Point(141+14, 27);
			this->checkBox19->Name = L"checkBox19";
			this->checkBox19->Size = System::Drawing::Size(15, 14);
			this->checkBox19->TabIndex = 119;
			this->checkBox19->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox19->UseVisualStyleBackColor = true;
			this->checkBox19->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox18
			// 
			this->checkBox18->AutoSize = true;
			this->checkBox18->Location = System::Drawing::Point(155+14, 27);
			this->checkBox18->Name = L"checkBox18";
			this->checkBox18->Size = System::Drawing::Size(15, 14);
			this->checkBox18->TabIndex = 118;
			this->checkBox18->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox18->UseVisualStyleBackColor = true;
			this->checkBox18->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox17
			// 
			this->checkBox17->AutoSize = true;
			this->checkBox17->Location = System::Drawing::Point(169+14, 27);
			this->checkBox17->Name = L"checkBox17";
			this->checkBox17->Size = System::Drawing::Size(15, 14);
			this->checkBox17->TabIndex = 117;
			this->checkBox17->UseVisualStyleBackColor = true;
			this->checkBox17->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox16
			// 
			this->checkBox16->AutoSize = true;
			this->checkBox16->Location = System::Drawing::Point(183+14, 27);
			this->checkBox16->Name = L"checkBox16";
			this->checkBox16->Size = System::Drawing::Size(15, 14);
			this->checkBox16->TabIndex = 116;
			this->checkBox16->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox16->UseVisualStyleBackColor = true;
			this->checkBox16->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox15
			// 
			this->checkBox15->AutoSize = true;
			this->checkBox15->Location = System::Drawing::Point(197+14, 27);
			this->checkBox15->Name = L"checkBox15";
			this->checkBox15->Size = System::Drawing::Size(15, 14);
			this->checkBox15->TabIndex = 115;
			this->checkBox15->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox15->UseVisualStyleBackColor = true;
			this->checkBox15->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox14
			// 
			this->checkBox14->AutoSize = true;
			this->checkBox14->Location = System::Drawing::Point(211+14, 27);
			this->checkBox14->Name = L"checkBox14";
			this->checkBox14->Size = System::Drawing::Size(15, 14);
			this->checkBox14->TabIndex = 114;
			this->checkBox14->UseVisualStyleBackColor = true;
			this->checkBox14->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox13
			// 
			this->checkBox13->AutoSize = true;
			this->checkBox13->Location = System::Drawing::Point(225+14, 27);
			this->checkBox13->Name = L"checkBox13";
			this->checkBox13->Size = System::Drawing::Size(15, 14);
			this->checkBox13->TabIndex = 113;
			this->checkBox13->UseVisualStyleBackColor = true;
			this->checkBox13->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox12
			// 
			this->checkBox12->AutoSize = true;
			this->checkBox12->Location = System::Drawing::Point(239+28, 27);
			this->checkBox12->Name = L"checkBox12";
			this->checkBox12->Size = System::Drawing::Size(15, 14);
			this->checkBox12->TabIndex = 112;
			this->checkBox12->UseVisualStyleBackColor = true;
			this->checkBox12->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox11
			// 
			this->checkBox11->AutoSize = true;
			this->checkBox11->Location = System::Drawing::Point(253+28, 27);
			this->checkBox11->Name = L"checkBox11";
			this->checkBox11->Size = System::Drawing::Size(15, 14);
			this->checkBox11->TabIndex = 111;
			this->checkBox11->UseVisualStyleBackColor = true;
			this->checkBox11->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox10
			// 
			this->checkBox10->AutoSize = true;
			this->checkBox10->Location = System::Drawing::Point(267+28, 27);
			this->checkBox10->Name = L"checkBox10";
			this->checkBox10->Size = System::Drawing::Size(15, 14);
			this->checkBox10->TabIndex = 110;
			this->checkBox10->UseVisualStyleBackColor = true;
			this->checkBox10->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox09
			// 
			this->checkBox09->AutoSize = true;
			this->checkBox09->Location = System::Drawing::Point(281+28, 27);
			this->checkBox09->Name = L"checkBox09";
			this->checkBox09->Size = System::Drawing::Size(15, 14);
			this->checkBox09->TabIndex = 109;
			this->checkBox09->UseVisualStyleBackColor = true;
			this->checkBox09->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox08
			// 
			this->checkBox08->AutoSize = true;
			this->checkBox08->Location = System::Drawing::Point(295+28, 27);
			this->checkBox08->Name = L"checkBox08";
			this->checkBox08->Size = System::Drawing::Size(15, 14);
			this->checkBox08->TabIndex = 108;
			this->checkBox08->UseVisualStyleBackColor = true;
			this->checkBox08->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox07
			// 
			this->checkBox07->AutoSize = true;
			this->checkBox07->Location = System::Drawing::Point(309+28, 27);
			this->checkBox07->Name = L"checkBox07";
			this->checkBox07->Size = System::Drawing::Size(15, 14);
			this->checkBox07->TabIndex = 107;
			this->checkBox07->UseVisualStyleBackColor = true;
			this->checkBox07->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox06
			// 
			this->checkBox06->AutoSize = true;
			this->checkBox06->Location = System::Drawing::Point(323+28, 27);
			this->checkBox06->Name = L"checkBox06";
			this->checkBox06->Size = System::Drawing::Size(15, 14);
			this->checkBox06->TabIndex = 106;
			this->checkBox06->UseVisualStyleBackColor = true;
			this->checkBox06->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox05
			// 
			this->checkBox05->AutoSize = true;
			this->checkBox05->Location = System::Drawing::Point(337+28, 27);
			this->checkBox05->Name = L"checkBox05";
			this->checkBox05->Size = System::Drawing::Size(15, 14);
			this->checkBox05->TabIndex = 105;
			this->checkBox05->UseVisualStyleBackColor = true;
			this->checkBox05->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox04
			// 
			this->checkBox04->AutoSize = true;
			this->checkBox04->Location = System::Drawing::Point(351+42, 27);
			this->checkBox04->Name = L"checkBox04";
			this->checkBox04->Size = System::Drawing::Size(15, 14);
			this->checkBox04->TabIndex = 104;
			this->checkBox04->UseVisualStyleBackColor = true;
			this->checkBox04->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox03
			// 
			this->checkBox03->AutoSize = true;
			this->checkBox03->Location = System::Drawing::Point(365+56, 27);
			this->checkBox03->Name = L"checkBox03";
			this->checkBox03->Size = System::Drawing::Size(15, 14);
			this->checkBox03->TabIndex = 103;
			this->checkBox03->UseVisualStyleBackColor = true;
			this->checkBox03->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox02
			// 
			this->checkBox02->AutoSize = true;
			this->checkBox02->Location = System::Drawing::Point(379+56, 27);
			this->checkBox02->Name = L"checkBox02";
			this->checkBox02->Size = System::Drawing::Size(15, 14);
			this->checkBox02->TabIndex = 102;
			this->checkBox02->UseVisualStyleBackColor = true;
			this->checkBox02->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox01
			// 
			this->checkBox01->AutoSize = true;
			this->checkBox01->Location = System::Drawing::Point(393+56, 27);
			this->checkBox01->Name = L"checkBox01";
			this->checkBox01->Size = System::Drawing::Size(15, 14);
			this->checkBox01->TabIndex = 101;
			this->checkBox01->UseVisualStyleBackColor = true;
			this->checkBox01->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox00
			// 
			this->checkBox00->AutoSize = true;
			this->checkBox00->Location = System::Drawing::Point(407+56, 27);
			this->checkBox00->Name = L"checkBox00";
			this->checkBox00->Size = System::Drawing::Size(15, 14);
			this->checkBox00->TabIndex = 100;
			this->checkBox00->UseVisualStyleBackColor = true;
			this->checkBox00->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->toolStripStatusLabel1});
			this->statusStrip1->Location = System::Drawing::Point(0, 197);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(495+56, 22);
			this->statusStrip1->TabIndex = 4;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
			this->toolStripStatusLabel1->Size = System::Drawing::Size(0, 17);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(495+56, 219);
			this->Controls->Add(this->statusStrip1);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox0);
			this->Name = L"Form1";
			this->Text = L"16FUSB Direct I/O HID Sample App";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox0->ResumeLayout(false);
			this->groupBox0->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 if(this->toolStripStatusLabel1->Text == "") {
				Application::Exit();
			 }			 
		 }
private: System::Void inputThread( Object^ sender, DoWorkEventArgs^ e ) {
			 
			 unsigned char *inputReport;

			 while(true) {

				 inputReport = usb->readReport4();

				 if((inputReport[4] & 0x80) == 0) {
					 this->setChecked(this->checkBox58, false);
				 } else {
					 this->setChecked(this->checkBox58, true);
				 }
				 if((inputReport[4] & 0x40) == 0) {
					 this->setChecked(this->checkBox57, false);
				 } else {
					 this->setChecked(this->checkBox57, true);
				 }
				 if((inputReport[4] & 0x20) == 0) {
					 this->setChecked(this->checkBox56, false);
				 } else {
					 this->setChecked(this->checkBox56, true);
				 }
				 if((inputReport[4] & 0x10) == 0) {
					 this->setChecked(this->checkBox55, false);
				 } else {
					 this->setChecked(this->checkBox55, true);
				 }
				 if((inputReport[4] & 0x08) == 0) {
					 this->setChecked(this->checkBox54, false);
				 } else {
					 this->setChecked(this->checkBox54, true);
				 }
				 if((inputReport[4] & 0x04) == 0) {
					 this->setChecked(this->checkBox53, false);
				 } else {
					 this->setChecked(this->checkBox53, true);
				 }
				 if((inputReport[4] & 0x02) == 0) {
					 this->setChecked(this->checkBox52, false);
				 } else {
					 this->setChecked(this->checkBox52, true);
				 }
				 if((inputReport[4] & 0x01) == 0) {
					 this->setChecked(this->checkBox51, false);
				 } else {
					 this->setChecked(this->checkBox51, true);
				 }

				 if((inputReport[3] & 0x80) == 0) {
					 this->setChecked(this->checkBox50, false);
				 } else {
					 this->setChecked(this->checkBox50, true);
				 }
				 if((inputReport[3] & 0x40) == 0) {
					 this->setChecked(this->checkBox49, false);
				 } else {
					 this->setChecked(this->checkBox49, true);
				 }
				 if((inputReport[3] & 0x20) == 0) {
					 this->setChecked(this->checkBox48, false);
				 } else {
					 this->setChecked(this->checkBox48, true);
				 }
				 if((inputReport[3] & 0x10) == 0) {
					 this->setChecked(this->checkBox47, false);
				 } else {
					 this->setChecked(this->checkBox47, true);
				 }
				 if((inputReport[3] & 0x08) == 0) {
					 this->setChecked(this->checkBox46, false);
				 } else {
					 this->setChecked(this->checkBox46, true);
				 }
				 if((inputReport[3] & 0x04) == 0) {
					 this->setChecked(this->checkBox45, false);
				 } else {
					 this->setChecked(this->checkBox45, true);
				 }
				 if((inputReport[3] & 0x02) == 0) {
					 this->setChecked(this->checkBox44, false);
				 } else {
					 this->setChecked(this->checkBox44, true);
				 }
				 if((inputReport[3] & 0x01) == 0) {
					 this->setChecked(this->checkBox43, false);
				 } else {
					 this->setChecked(this->checkBox43, true);
				 }

				 if((inputReport[2] & 0x80) == 0) {
					 this->setChecked(this->checkBox42, false);
				 } else {
					 this->setChecked(this->checkBox42, true);
				 }
				 if((inputReport[2] & 0x40) == 0) {
					 this->setChecked(this->checkBox41, false);
				 } else {
					 this->setChecked(this->checkBox41, true);
				 }
				 if((inputReport[2] & 0x20) == 0) {
					 this->setChecked(this->checkBox40, false);
				 } else {
					 this->setChecked(this->checkBox40, true);
				 }
				 if((inputReport[2] & 0x10) == 0) {
					 this->setChecked(this->checkBox39, false);
				 } else {
					 this->setChecked(this->checkBox39, true);
				 }
				 if((inputReport[2] & 0x08) == 0) {
					 this->setChecked(this->checkBox38, false);
				 } else {
					 this->setChecked(this->checkBox38, true);
				 }
				 if((inputReport[2] & 0x04) == 0) {
					 this->setChecked(this->checkBox37, false);
				 } else {
					 this->setChecked(this->checkBox37, true);
				 }
				 if((inputReport[2] & 0x02) == 0) {
					 this->setChecked(this->checkBox36, false);
				 } else {
					 this->setChecked(this->checkBox36, true);
				 }
				 if((inputReport[2] & 0x01) == 0) {
					 this->setChecked(this->checkBox35, false);
				 } else {
					 this->setChecked(this->checkBox35, true);
				 }

				 if((inputReport[1] & 0x10) == 0) {
					 this->setChecked(this->checkBox34, false);
				 } else {
					 this->setChecked(this->checkBox34, true);
				 }
				 if((inputReport[1] & 0x08) == 0) {
					 this->setChecked(this->checkBox33, false);
				 } else {
					 this->setChecked(this->checkBox33, true);
				 }
				 if((inputReport[1] & 0x04) == 0) {
					 this->setChecked(this->checkBox32, false);
				 } else {
					 this->setChecked(this->checkBox32, true);
				 }
				 if((inputReport[1] & 0x02) == 0) {
					 this->setChecked(this->checkBox31, false);
				 } else {
					 this->setChecked(this->checkBox31, true);
				 }
				 if((inputReport[1] & 0x01) == 0) {
					 this->setChecked(this->checkBox30, false);
				 } else {
					 this->setChecked(this->checkBox30, true);
				 }
			 }
		 }
private: System::Void setChecked(CheckBox^ chk, bool check) {
			if(chk->InvokeRequired) {
				SetCheckDelegate^ c = gcnew SetCheckDelegate(this, &Form1::setChecked);
				this->Invoke(c, chk, check);
			} else {
				chk->Checked = check;
			}
		 }

private: System::Void outCheck_CheckedChanged1(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[5];
			outputReport[0] = 0;

			int bitsToSend_EA = 128;
			int bitsToSend_B = 0x0;
			int bitsToSend_C = 0x0;
			int bitsToSend_D = 0x0;

			bitsToSend_EA |= (this->checkBox60->Checked == true) ? 1 : 0;
			bitsToSend_EA |= (this->checkBox61->Checked == true) ? 2 : 0;
			bitsToSend_EA |= (this->checkBox62->Checked == true) ? 4 : 0;
			bitsToSend_EA |= (this->checkBox63->Checked == true) ? 8 : 0;
			bitsToSend_EA |= (this->checkBox64->Checked == true) ? 16 : 0;

			bitsToSend_B |= (this->checkBox65->Checked == true) ? 1 : 0;
			bitsToSend_B |= (this->checkBox66->Checked == true) ? 2 : 0;
			bitsToSend_B |= (this->checkBox67->Checked == true) ? 4 : 0;
			bitsToSend_B |= (this->checkBox68->Checked == true) ? 8 : 0;
			bitsToSend_B |= (this->checkBox69->Checked == true) ? 16 : 0;
			bitsToSend_B |= (this->checkBox70->Checked == true) ? 32 : 0;
			bitsToSend_B |= (this->checkBox71->Checked == true) ? 64 : 0;
			bitsToSend_B |= (this->checkBox72->Checked == true) ? 128 : 0;

			bitsToSend_C |= (this->checkBox73->Checked == true) ? 1 : 0;
			bitsToSend_C |= (this->checkBox74->Checked == true) ? 2 : 0;
			bitsToSend_C |= (this->checkBox75->Checked == true) ? 4 : 0;
			bitsToSend_C |= (this->checkBox76->Checked == true) ? 8 : 0;
			bitsToSend_C |= (this->checkBox77->Checked == true) ? 16 : 0;
			bitsToSend_C |= (this->checkBox78->Checked == true) ? 32 : 0;
			bitsToSend_C |= (this->checkBox79->Checked == true) ? 64 : 0;
			bitsToSend_C |= (this->checkBox80->Checked == true) ? 128 : 0;

			bitsToSend_D |= (this->checkBox81->Checked == true) ? 1 : 0;
			bitsToSend_D |= (this->checkBox82->Checked == true) ? 2 : 0;
			bitsToSend_D |= (this->checkBox83->Checked == true) ? 4 : 0;
			bitsToSend_D |= (this->checkBox84->Checked == true) ? 8 : 0;
			bitsToSend_D |= (this->checkBox85->Checked == true) ? 16 : 0;
			bitsToSend_D |= (this->checkBox86->Checked == true) ? 32 : 0;
			bitsToSend_D |= (this->checkBox87->Checked == true) ? 64 : 0;
			bitsToSend_D |= (this->checkBox88->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend_EA;
			outputReport[2] = bitsToSend_B;
			outputReport[3] = bitsToSend_C;
			outputReport[4] = bitsToSend_D;
			usb->writeReport4(outputReport);
		 }

private: System::Void outCheck_CheckedChanged2(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[5];
			outputReport[0] = 0;

			int bitsToSend_EA = 0x0;
			int bitsToSend_B = 0x0;
			int bitsToSend_C = 0x0;
			int bitsToSend_D = 0x0;

			bitsToSend_EA |= (this->checkBox00->Checked == true) ? 1 : 0;
			bitsToSend_EA |= (this->checkBox01->Checked == true) ? 2 : 0;
			bitsToSend_EA |= (this->checkBox02->Checked == true) ? 4 : 0;
			bitsToSend_EA |= (this->checkBox03->Checked == true) ? 8 : 0;
			bitsToSend_EA |= (this->checkBox04->Checked == true) ? 16 : 0;

			bitsToSend_B |= (this->checkBox05->Checked == true) ? 1 : 0;
			bitsToSend_B |= (this->checkBox06->Checked == true) ? 2 : 0;
			bitsToSend_B |= (this->checkBox07->Checked == true) ? 4 : 0;
			bitsToSend_B |= (this->checkBox08->Checked == true) ? 8 : 0;
			bitsToSend_B |= (this->checkBox09->Checked == true) ? 16 : 0;
			bitsToSend_B |= (this->checkBox10->Checked == true) ? 32 : 0;
			bitsToSend_B |= (this->checkBox11->Checked == true) ? 64 : 0;
			bitsToSend_B |= (this->checkBox12->Checked == true) ? 128 : 0;

			bitsToSend_C |= (this->checkBox13->Checked == true) ? 1 : 0;
			bitsToSend_C |= (this->checkBox14->Checked == true) ? 2 : 0;
			bitsToSend_C |= (this->checkBox15->Checked == true) ? 4 : 0;
			bitsToSend_C |= (this->checkBox16->Checked == true) ? 8 : 0;
			bitsToSend_C |= (this->checkBox17->Checked == true) ? 16 : 0;
			bitsToSend_C |= (this->checkBox18->Checked == true) ? 32 : 0;
			bitsToSend_C |= (this->checkBox19->Checked == true) ? 64 : 0;
			bitsToSend_C |= (this->checkBox20->Checked == true) ? 128 : 0;

			bitsToSend_D |= (this->checkBox21->Checked == true) ? 1 : 0;
			bitsToSend_D |= (this->checkBox22->Checked == true) ? 2 : 0;
			bitsToSend_D |= (this->checkBox23->Checked == true) ? 4 : 0;
			bitsToSend_D |= (this->checkBox24->Checked == true) ? 8 : 0;
			bitsToSend_D |= (this->checkBox25->Checked == true) ? 16 : 0;
			bitsToSend_D |= (this->checkBox26->Checked == true) ? 32 : 0;
			bitsToSend_D |= (this->checkBox27->Checked == true) ? 64 : 0;
			bitsToSend_D |= (this->checkBox28->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend_EA;
			outputReport[2] = bitsToSend_B;
			outputReport[3] = bitsToSend_C;
			outputReport[4] = bitsToSend_D;
			usb->writeReport4(outputReport);
		 }

};

}

