#pragma once

#include "stdio.h"
#include <wtypes.h>

#include "Usb.h"


namespace My16FUSB_HID_DioSampleAPP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
		delegate void SetCheckDelegate(CheckBox^ chk, bool check);
	public:
		Form1(void)
		{
			InitializeComponent();
			
			 usb = gcnew Usb();
			 usb->VendorID = 0x04D8;
			 usb->ProductID = 0x0628;

			 if(usb->findDevice()) {
				this->toolStripStatusLabel1->Text = "Device Connected";

				usb->openReadHandle();
				bgWorker = gcnew System::ComponentModel::BackgroundWorker();
				bgWorker->DoWork += gcnew DoWorkEventHandler( this, &Form1::inputThread );
				bgWorker->RunWorkerAsync();

				usb->openWriteHandle();
			 } else {
				System::Windows::Forms::MessageBox::Show( L"Device not found!", L"16FUSB", 
					System::Windows::Forms::MessageBoxButtons::OK);				
			 }
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^  checkBox47;
	private: System::Windows::Forms::CheckBox^  checkBox46;
	private: System::Windows::Forms::CheckBox^  checkBox45;
	private: System::Windows::Forms::CheckBox^  checkBox44;
	private: System::Windows::Forms::CheckBox^  checkBox42;
	private: System::Windows::Forms::CheckBox^  checkBox41;
	private: System::Windows::Forms::CheckBox^  checkBox40;
	private: System::Windows::Forms::Label^  label47;
	private: System::Windows::Forms::Label^  label46;
	private: System::Windows::Forms::Label^  label45;
	private: System::Windows::Forms::Label^  label44;
	private: System::Windows::Forms::Label^  label42;
	private: System::Windows::Forms::Label^  label41;
	private: System::Windows::Forms::Label^  label40;
	private: System::Windows::Forms::CheckBox^  checkBox27;
	private: System::Windows::Forms::CheckBox^  checkBox26;
	private: System::Windows::Forms::CheckBox^  checkBox25;
	private: System::Windows::Forms::CheckBox^  checkBox24;
	private: System::Windows::Forms::CheckBox^  checkBox22;
	private: System::Windows::Forms::CheckBox^  checkBox21;
	private: System::Windows::Forms::CheckBox^  checkBox20;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::GroupBox^  groupBox0;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::CheckBox^  checkBox07;
	private: System::Windows::Forms::CheckBox^  checkBox06;
	private: System::Windows::Forms::CheckBox^  checkBox05;
	private: System::Windows::Forms::CheckBox^  checkBox04;
	private: System::Windows::Forms::CheckBox^  checkBox02;
	private: System::Windows::Forms::CheckBox^  checkBox01;
	private: System::Windows::Forms::CheckBox^  checkBox00;
	private: System::Windows::Forms::Label^  label07;
	private: System::Windows::Forms::Label^  label06;
	private: System::Windows::Forms::Label^  label05;
	private: System::Windows::Forms::Label^  label04;
	private: System::Windows::Forms::Label^  label02;
	private: System::Windows::Forms::Label^  label01;
	private: System::Windows::Forms::Label^  label00;

	private: System::ComponentModel::IContainer^  components;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


			 
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;

			 System::ComponentModel::BackgroundWorker^ bgWorker;

			 Usb^ usb;
			 			 

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->checkBox47 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox46 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox45 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox44 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox42 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox41 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox40 = (gcnew System::Windows::Forms::CheckBox());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->checkBox27 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox26 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox25 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox24 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox22 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox21 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox20 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox0 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label07 = (gcnew System::Windows::Forms::Label());
			this->label06 = (gcnew System::Windows::Forms::Label());
			this->label05 = (gcnew System::Windows::Forms::Label());
			this->label04 = (gcnew System::Windows::Forms::Label());
			this->label02 = (gcnew System::Windows::Forms::Label());
			this->label01 = (gcnew System::Windows::Forms::Label());
			this->label00 = (gcnew System::Windows::Forms::Label());
			this->checkBox07 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox06 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox05 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox04 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox02 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox01 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox00 = (gcnew System::Windows::Forms::CheckBox());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->groupBox0->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(16-3, 43);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(13, 13);
			this->label47->TabIndex = 107;
			this->label47->Text = L"C3";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(30, 43);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(13, 13);
			this->label46->TabIndex = 106;
			this->label46->Text = L"2";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(44, 43);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(13, 13);
			this->label45->TabIndex = 105;
			this->label45->Text = L"1";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(58, 43);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(13, 13);
			this->label44->TabIndex = 104;
			this->label44->Text = L"0";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(86-3, 43);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(13, 13);
			this->label42->TabIndex = 102;
			this->label42->Text = L"B2";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(100, 43);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(13, 13);
			this->label41->TabIndex = 101;
			this->label41->Text = L"1";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(114, 43);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(13, 13);
			this->label40->TabIndex = 100;
			this->label40->Text = L"0";
			// 
			// checkBox47
			// 
			this->checkBox47->AutoSize = true;
			this->checkBox47->Location = System::Drawing::Point(15, 27);
			this->checkBox47->Name = L"checkBox47";
			this->checkBox47->Size = System::Drawing::Size(15, 14);
			this->checkBox47->TabIndex = 87;
			this->checkBox47->UseVisualStyleBackColor = true;
			this->checkBox47->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox46
			// 
			this->checkBox46->AutoSize = true;
			this->checkBox46->Location = System::Drawing::Point(29, 27);
			this->checkBox46->Name = L"checkBox46";
			this->checkBox46->Size = System::Drawing::Size(15, 14);
			this->checkBox46->TabIndex = 86;
			this->checkBox46->UseVisualStyleBackColor = true;
			this->checkBox46->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox45
			// 
			this->checkBox45->AutoSize = true;
			this->checkBox45->Location = System::Drawing::Point(43, 27);
			this->checkBox45->Name = L"checkBox45";
			this->checkBox45->Size = System::Drawing::Size(15, 14);
			this->checkBox45->TabIndex = 85;
			this->checkBox45->UseVisualStyleBackColor = true;
			this->checkBox45->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox44
			// 
			this->checkBox44->AutoSize = true;
			this->checkBox44->Location = System::Drawing::Point(57, 27);
			this->checkBox44->Name = L"checkBox44";
			this->checkBox44->Size = System::Drawing::Size(15, 14);
			this->checkBox44->TabIndex = 84;
			this->checkBox44->UseVisualStyleBackColor = true;
			this->checkBox44->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox42
			// 
			this->checkBox42->AutoSize = true;
			this->checkBox42->Location = System::Drawing::Point(85, 27);
			this->checkBox42->Name = L"checkBox42";
			this->checkBox42->Size = System::Drawing::Size(15, 14);
			this->checkBox42->TabIndex = 82;
			this->checkBox42->UseVisualStyleBackColor = true;
			this->checkBox42->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox41
			// 
			this->checkBox41->AutoSize = true;
			this->checkBox41->Location = System::Drawing::Point(99, 27);
			this->checkBox41->Name = L"checkBox41";
			this->checkBox41->Size = System::Drawing::Size(15, 14);
			this->checkBox41->TabIndex = 81;
			this->checkBox41->UseVisualStyleBackColor = true;
			this->checkBox41->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox40
			// 
			this->checkBox40->AutoSize = true;
			this->checkBox40->Location = System::Drawing::Point(113, 27);
			this->checkBox40->Name = L"checkBox40";
			this->checkBox40->Size = System::Drawing::Size(15, 14);
			this->checkBox40->TabIndex = 80;
			this->checkBox40->UseVisualStyleBackColor = true;
			this->checkBox40->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(16-3, 43);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(13, 13);
			this->label27->TabIndex = 67;
			this->label27->Text = L"C3";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(30, 43);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 13);
			this->label26->TabIndex = 66;
			this->label26->Text = L"2";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(44, 43);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(13, 13);
			this->label25->TabIndex = 65;
			this->label25->Text = L"1";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(58, 43);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(13, 13);
			this->label24->TabIndex = 64;
			this->label24->Text = L"0";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(86-3, 43);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(13, 13);
			this->label22->TabIndex = 62;
			this->label22->Text = L"B2";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(100, 43);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(13, 13);
			this->label21->TabIndex = 61;
			this->label21->Text = L"1";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(114, 43);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(13, 13);
			this->label20->TabIndex = 60;
			this->label20->Text = L"0";
			// 
			// checkBox27
			// 
			this->checkBox27->AutoSize = true;
			this->checkBox27->Enabled = false;
			this->checkBox27->Location = System::Drawing::Point(15, 27);
			this->checkBox27->Name = L"checkBox27";
			this->checkBox27->Size = System::Drawing::Size(15, 14);
			this->checkBox27->TabIndex = 47;
			this->checkBox27->UseVisualStyleBackColor = true;
			// 
			// checkBox26
			// 
			this->checkBox26->AutoSize = true;
			this->checkBox26->Enabled = false;
			this->checkBox26->Location = System::Drawing::Point(29, 27);
			this->checkBox26->Name = L"checkBox26";
			this->checkBox26->Size = System::Drawing::Size(15, 14);
			this->checkBox26->TabIndex = 46;
			this->checkBox26->UseVisualStyleBackColor = true;
			// 
			// checkBox25
			// 
			this->checkBox25->AutoSize = true;
			this->checkBox25->Enabled = false;
			this->checkBox25->Location = System::Drawing::Point(43, 27);
			this->checkBox25->Name = L"checkBox25";
			this->checkBox25->Size = System::Drawing::Size(15, 14);
			this->checkBox25->TabIndex = 45;
			this->checkBox25->UseVisualStyleBackColor = true;
			// 
			// checkBox24
			// 
			this->checkBox24->AutoSize = true;
			this->checkBox24->Enabled = false;
			this->checkBox24->Location = System::Drawing::Point(57, 27);
			this->checkBox24->Name = L"checkBox24";
			this->checkBox24->Size = System::Drawing::Size(15, 14);
			this->checkBox24->TabIndex = 44;
			this->checkBox24->UseVisualStyleBackColor = true;
			// 
			// checkBox22
			// 
			this->checkBox22->AutoSize = true;
			this->checkBox22->Enabled = false;
			this->checkBox22->Location = System::Drawing::Point(85, 27);
			this->checkBox22->Name = L"checkBox22";
			this->checkBox22->Size = System::Drawing::Size(15, 14);
			this->checkBox22->TabIndex = 42;
			this->checkBox22->UseVisualStyleBackColor = true;
			// 
			// checkBox21
			// 
			this->checkBox21->AutoSize = true;
			this->checkBox21->Enabled = false;
			this->checkBox21->Location = System::Drawing::Point(99, 27);
			this->checkBox21->Name = L"checkBox21";
			this->checkBox21->Size = System::Drawing::Size(15, 14);
			this->checkBox21->TabIndex = 41;
			this->checkBox21->UseVisualStyleBackColor = true;
			// 
			// checkBox20
			// 
			this->checkBox20->AutoSize = true;
			this->checkBox20->Enabled = false;
			this->checkBox20->Location = System::Drawing::Point(113, 27);
			this->checkBox20->Name = L"checkBox20";
			this->checkBox20->Size = System::Drawing::Size(15, 14);
			this->checkBox20->TabIndex = 40;
			this->checkBox20->UseVisualStyleBackColor = true;
			// 
			// groupBox0
			// 
			this->groupBox0->Controls->Add(this->label47);
			this->groupBox0->Controls->Add(this->label46);
			this->groupBox0->Controls->Add(this->label45);
			this->groupBox0->Controls->Add(this->label44);
			this->groupBox0->Controls->Add(this->label42);
			this->groupBox0->Controls->Add(this->label41);
			this->groupBox0->Controls->Add(this->label40);
			this->groupBox0->Controls->Add(this->checkBox47);
			this->groupBox0->Controls->Add(this->checkBox46);
			this->groupBox0->Controls->Add(this->checkBox45);
			this->groupBox0->Controls->Add(this->checkBox44);
			this->groupBox0->Controls->Add(this->checkBox42);
			this->groupBox0->Controls->Add(this->checkBox41);
			this->groupBox0->Controls->Add(this->checkBox40);
			this->groupBox0->Location = System::Drawing::Point(30, 3);
			this->groupBox0->Name = L"groupBox0";
			this->groupBox0->Size = System::Drawing::Size(142, 60);
			this->groupBox0->TabIndex = 1;
			this->groupBox0->TabStop = false;
			this->groupBox0->Text = L"TRIS";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label27);
			this->groupBox1->Controls->Add(this->label26);
			this->groupBox1->Controls->Add(this->label25);
			this->groupBox1->Controls->Add(this->label24);
			this->groupBox1->Controls->Add(this->label22);
			this->groupBox1->Controls->Add(this->label21);
			this->groupBox1->Controls->Add(this->label20);
			this->groupBox1->Controls->Add(this->checkBox27);
			this->groupBox1->Controls->Add(this->checkBox26);
			this->groupBox1->Controls->Add(this->checkBox25);
			this->groupBox1->Controls->Add(this->checkBox24);
			this->groupBox1->Controls->Add(this->checkBox22);
			this->groupBox1->Controls->Add(this->checkBox21);
			this->groupBox1->Controls->Add(this->checkBox20);
			this->groupBox1->Location = System::Drawing::Point(30, 68);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(142, 60);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"INPUT";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label07);
			this->groupBox2->Controls->Add(this->label06);
			this->groupBox2->Controls->Add(this->label05);
			this->groupBox2->Controls->Add(this->label04);
			this->groupBox2->Controls->Add(this->label02);
			this->groupBox2->Controls->Add(this->label01);
			this->groupBox2->Controls->Add(this->label00);
			this->groupBox2->Controls->Add(this->checkBox07);
			this->groupBox2->Controls->Add(this->checkBox06);
			this->groupBox2->Controls->Add(this->checkBox05);
			this->groupBox2->Controls->Add(this->checkBox04);
			this->groupBox2->Controls->Add(this->checkBox02);
			this->groupBox2->Controls->Add(this->checkBox01);
			this->groupBox2->Controls->Add(this->checkBox00);
			this->groupBox2->Location = System::Drawing::Point(30, 133);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(142, 60);
			this->groupBox2->TabIndex = 3;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"OUTPUT";
			// 
			// label07
			// 
			this->label07->AutoSize = true;
			this->label07->Location = System::Drawing::Point(16-3, 43);
			this->label07->Name = L"label07";
			this->label07->Size = System::Drawing::Size(13, 13);
			this->label07->TabIndex = 27;
			this->label07->Text = L"C3";
			// 
			// label06
			// 
			this->label06->AutoSize = true;
			this->label06->Location = System::Drawing::Point(30, 43);
			this->label06->Name = L"label06";
			this->label06->Size = System::Drawing::Size(13, 13);
			this->label06->TabIndex = 26;
			this->label06->Text = L"2";
			// 
			// label05
			// 
			this->label05->AutoSize = true;
			this->label05->Location = System::Drawing::Point(44, 43);
			this->label05->Name = L"label05";
			this->label05->Size = System::Drawing::Size(13, 13);
			this->label05->TabIndex = 25;
			this->label05->Text = L"1";
			// 
			// label04
			// 
			this->label04->AutoSize = true;
			this->label04->Location = System::Drawing::Point(58, 43);
			this->label04->Name = L"label04";
			this->label04->Size = System::Drawing::Size(13, 13);
			this->label04->TabIndex = 24;
			this->label04->Text = L"0";
			// 
			// label02
			// 
			this->label02->AutoSize = true;
			this->label02->Location = System::Drawing::Point(86-3, 43);
			this->label02->Name = L"label02";
			this->label02->Size = System::Drawing::Size(13, 13);
			this->label02->TabIndex = 22;
			this->label02->Text = L"B2";
			// 
			// label01
			// 
			this->label01->AutoSize = true;
			this->label01->Location = System::Drawing::Point(100, 43);
			this->label01->Name = L"label01";
			this->label01->Size = System::Drawing::Size(13, 13);
			this->label01->TabIndex = 21;
			this->label01->Text = L"1";
			// 
			// label00
			// 
			this->label00->AutoSize = true;
			this->label00->Location = System::Drawing::Point(114, 43);
			this->label00->Name = L"label00";
			this->label00->Size = System::Drawing::Size(13, 13);
			this->label00->TabIndex = 20;
			this->label00->Text = L"0";
			// 
			// checkBox07
			// 
			this->checkBox07->AutoSize = true;
			this->checkBox07->Location = System::Drawing::Point(15, 27);
			this->checkBox07->Name = L"checkBox07";
			this->checkBox07->Size = System::Drawing::Size(15, 14);
			this->checkBox07->TabIndex = 7;
			this->checkBox07->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox07->UseVisualStyleBackColor = true;
			this->checkBox07->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox06
			// 
			this->checkBox06->AutoSize = true;
			this->checkBox06->Location = System::Drawing::Point(29, 27);
			this->checkBox06->Name = L"checkBox06";
			this->checkBox06->Size = System::Drawing::Size(15, 14);
			this->checkBox06->TabIndex = 6;
			this->checkBox06->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox06->UseVisualStyleBackColor = true;
			this->checkBox06->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox05
			// 
			this->checkBox05->AutoSize = true;
			this->checkBox05->Location = System::Drawing::Point(43, 27);
			this->checkBox05->Name = L"checkBox05";
			this->checkBox05->Size = System::Drawing::Size(15, 14);
			this->checkBox05->TabIndex = 5;
			this->checkBox05->UseVisualStyleBackColor = true;
			this->checkBox05->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox04
			// 
			this->checkBox04->AutoSize = true;
			this->checkBox04->Location = System::Drawing::Point(57, 27);
			this->checkBox04->Name = L"checkBox04";
			this->checkBox04->Size = System::Drawing::Size(15, 14);
			this->checkBox04->TabIndex = 4;
			this->checkBox04->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox04->UseVisualStyleBackColor = true;
			this->checkBox04->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox02
			// 
			this->checkBox02->AutoSize = true;
			this->checkBox02->Location = System::Drawing::Point(85, 27);
			this->checkBox02->Name = L"checkBox02";
			this->checkBox02->Size = System::Drawing::Size(15, 14);
			this->checkBox02->TabIndex = 2;
			this->checkBox02->UseVisualStyleBackColor = true;
			this->checkBox02->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox01
			// 
			this->checkBox01->AutoSize = true;
			this->checkBox01->Location = System::Drawing::Point(99, 27);
			this->checkBox01->Name = L"checkBox01";
			this->checkBox01->Size = System::Drawing::Size(15, 14);
			this->checkBox01->TabIndex = 1;
			this->checkBox01->UseVisualStyleBackColor = true;
			this->checkBox01->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox00
			// 
			this->checkBox00->AutoSize = true;
			this->checkBox00->Location = System::Drawing::Point(113, 27);
			this->checkBox00->Name = L"checkBox00";
			this->checkBox00->Size = System::Drawing::Size(15, 14);
			this->checkBox00->TabIndex = 0;
			this->checkBox00->UseVisualStyleBackColor = true;
			this->checkBox00->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->toolStripStatusLabel1});
			this->statusStrip1->Location = System::Drawing::Point(0, 197);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(202, 22);
			this->statusStrip1->TabIndex = 4;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
			this->toolStripStatusLabel1->Size = System::Drawing::Size(0, 17);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(202, 219);
			this->Controls->Add(this->statusStrip1);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox0);
			this->Name = L"Form1";
			this->Text = L"16FUSB Direct I/O HID";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox0->ResumeLayout(false);
			this->groupBox0->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 if(this->toolStripStatusLabel1->Text == "") {
				Application::Exit();
			 }			 
		 }
private: System::Void inputThread( Object^ sender, DoWorkEventArgs^ e ) {
			 
			 unsigned char *inputReport;

			 while(true) {

				 inputReport = usb->readReport();

				 if((inputReport[1] & 0x80) == 0) {
					 this->setChecked(this->checkBox27, false);
				 } else {
					 this->setChecked(this->checkBox27, true);
				 }
				 if((inputReport[1] & 0x40) == 0) {
					 this->setChecked(this->checkBox26, false);
				 } else {
					 this->setChecked(this->checkBox26, true);
				 }
				 if((inputReport[1] & 0x20) == 0) {
					 this->setChecked(this->checkBox25, false);
				 } else {
					 this->setChecked(this->checkBox25, true);
				 }
				 if((inputReport[1] & 0x10) == 0) {
					 this->setChecked(this->checkBox24, false);
				 } else {
					 this->setChecked(this->checkBox24, true);
				 }
				 if((inputReport[1] & 0x04) == 0) {
					 this->setChecked(this->checkBox22, false);
				 } else {
					 this->setChecked(this->checkBox22, true);
				 }
				 if((inputReport[1] & 0x02) == 0) {
					 this->setChecked(this->checkBox21, false);
				 } else {
					 this->setChecked(this->checkBox21, true);
				 }
				 if((inputReport[1] & 0x01) == 0) {
					 this->setChecked(this->checkBox20, false);
				 } else {
					 this->setChecked(this->checkBox20, true);
				 }
			 }
		 }
private: System::Void setChecked(CheckBox^ chk, bool check) {
			if(chk->InvokeRequired) {
				SetCheckDelegate^ c = gcnew SetCheckDelegate(this, &Form1::setChecked);
				this->Invoke(c, chk, check);
			} else {
				chk->Checked = check;
			}
		 }

private: System::Void outCheck_CheckedChanged1(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[2];
			outputReport[0] = 0;

			int bitsToSend = 0x8;

			bitsToSend |= (this->checkBox40->Checked == true) ? 1 : 0;
			bitsToSend |= (this->checkBox41->Checked == true) ? 2 : 0;
			bitsToSend |= (this->checkBox42->Checked == true) ? 4 : 0;
			bitsToSend |= (this->checkBox44->Checked == true) ? 16 : 0;
			bitsToSend |= (this->checkBox45->Checked == true) ? 32 : 0;
			bitsToSend |= (this->checkBox46->Checked == true) ? 64 : 0;
			bitsToSend |= (this->checkBox47->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend;
			usb->writeReport(outputReport);
		 }

private: System::Void outCheck_CheckedChanged2(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[2];
			outputReport[0] = 0;

			int bitsToSend = 0;

			bitsToSend |= (this->checkBox00->Checked == true) ? 1 : 0;
			bitsToSend |= (this->checkBox01->Checked == true) ? 2 : 0;
			bitsToSend |= (this->checkBox02->Checked == true) ? 4 : 0;
			bitsToSend |= (this->checkBox04->Checked == true) ? 16 : 0;
			bitsToSend |= (this->checkBox05->Checked == true) ? 32 : 0;
			bitsToSend |= (this->checkBox06->Checked == true) ? 64 : 0;
			bitsToSend |= (this->checkBox07->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend;
			usb->writeReport(outputReport);
		 }
		 
};

}

