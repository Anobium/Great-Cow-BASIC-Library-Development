#pragma once

#include "stdio.h"
#include <wtypes.h>

#include "Usb.h"


namespace My16FUSB_HID_DioSampleAPP {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace System::Threading;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
		delegate void SetCheckDelegate(CheckBox^ chk, bool check);
	public:
		Form1(void)
		{
			InitializeComponent();
			
			 usb = gcnew Usb();
			 usb->VendorID = 0x04D8;
			 usb->ProductID = 0x0628;

			 if(usb->findDevice()) {
				this->toolStripStatusLabel1->Text = "Device Connected";

				usb->openReadHandle();
				bgWorker = gcnew System::ComponentModel::BackgroundWorker();
				bgWorker->DoWork += gcnew DoWorkEventHandler( this, &Form1::inputThread );
				bgWorker->RunWorkerAsync();

				usb->openWriteHandle();
			 } else {
				System::Windows::Forms::MessageBox::Show( L"Device not found!", L"16FUSB", 
					System::Windows::Forms::MessageBoxButtons::OK);				
			 }
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^  checkBox56;
	private: System::Windows::Forms::CheckBox^  checkBox55;
	private: System::Windows::Forms::CheckBox^  checkBox54;
	private: System::Windows::Forms::CheckBox^  checkBox53;
	private: System::Windows::Forms::CheckBox^  checkBox52;
	private: System::Windows::Forms::CheckBox^  checkBox51;
	private: System::Windows::Forms::CheckBox^  checkBox50;
	private: System::Windows::Forms::CheckBox^  checkBox49;
	private: System::Windows::Forms::CheckBox^  checkBox48;
	private: System::Windows::Forms::CheckBox^  checkBox47;
	private: System::Windows::Forms::CheckBox^  checkBox46;
	private: System::Windows::Forms::CheckBox^  checkBox45;
	private: System::Windows::Forms::CheckBox^  checkBox44;
	private: System::Windows::Forms::CheckBox^  checkBox43;
	private: System::Windows::Forms::CheckBox^  checkBox42;
	private: System::Windows::Forms::CheckBox^  checkBox41;
	private: System::Windows::Forms::CheckBox^  checkBox40;
	private: System::Windows::Forms::Label^  label56;
	private: System::Windows::Forms::Label^  label55;
	private: System::Windows::Forms::Label^  label54;
	private: System::Windows::Forms::Label^  label53;
	private: System::Windows::Forms::Label^  label52;
	private: System::Windows::Forms::Label^  label51;
	private: System::Windows::Forms::Label^  label50;
	private: System::Windows::Forms::Label^  label49;
	private: System::Windows::Forms::Label^  label48;
	private: System::Windows::Forms::Label^  label47;
	private: System::Windows::Forms::Label^  label46;
	private: System::Windows::Forms::Label^  label45;
	private: System::Windows::Forms::Label^  label44;
	private: System::Windows::Forms::Label^  label43;
	private: System::Windows::Forms::Label^  label42;
	private: System::Windows::Forms::Label^  label41;
	private: System::Windows::Forms::Label^  label40;
	private: System::Windows::Forms::CheckBox^  checkBox36;
	private: System::Windows::Forms::CheckBox^  checkBox35;
	private: System::Windows::Forms::CheckBox^  checkBox34;
	private: System::Windows::Forms::CheckBox^  checkBox33;
	private: System::Windows::Forms::CheckBox^  checkBox32;
	private: System::Windows::Forms::CheckBox^  checkBox31;
	private: System::Windows::Forms::CheckBox^  checkBox30;
	private: System::Windows::Forms::CheckBox^  checkBox29;
	private: System::Windows::Forms::CheckBox^  checkBox28;
	private: System::Windows::Forms::CheckBox^  checkBox27;
	private: System::Windows::Forms::CheckBox^  checkBox26;
	private: System::Windows::Forms::CheckBox^  checkBox25;
	private: System::Windows::Forms::CheckBox^  checkBox24;
	private: System::Windows::Forms::CheckBox^  checkBox23;
	private: System::Windows::Forms::CheckBox^  checkBox22;
	private: System::Windows::Forms::CheckBox^  checkBox21;
	private: System::Windows::Forms::CheckBox^  checkBox20;
	private: System::Windows::Forms::Label^  label36;
	private: System::Windows::Forms::Label^  label35;
	private: System::Windows::Forms::Label^  label34;
	private: System::Windows::Forms::Label^  label33;
	private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::Label^  label31;
	private: System::Windows::Forms::Label^  label30;
	private: System::Windows::Forms::Label^  label29;
	private: System::Windows::Forms::Label^  label28;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::GroupBox^  groupBox0;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::CheckBox^  checkBox16;
	private: System::Windows::Forms::CheckBox^  checkBox15;
	private: System::Windows::Forms::CheckBox^  checkBox14;
	private: System::Windows::Forms::CheckBox^  checkBox13;
	private: System::Windows::Forms::CheckBox^  checkBox12;
	private: System::Windows::Forms::CheckBox^  checkBox11;
	private: System::Windows::Forms::CheckBox^  checkBox10;
	private: System::Windows::Forms::CheckBox^  checkBox09;
	private: System::Windows::Forms::CheckBox^  checkBox08;
	private: System::Windows::Forms::CheckBox^  checkBox07;
	private: System::Windows::Forms::CheckBox^  checkBox06;
	private: System::Windows::Forms::CheckBox^  checkBox05;
	private: System::Windows::Forms::CheckBox^  checkBox04;
	private: System::Windows::Forms::CheckBox^  checkBox03;
	private: System::Windows::Forms::CheckBox^  checkBox02;
	private: System::Windows::Forms::CheckBox^  checkBox01;
	private: System::Windows::Forms::CheckBox^  checkBox00;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label09;
	private: System::Windows::Forms::Label^  label08;
	private: System::Windows::Forms::Label^  label07;
	private: System::Windows::Forms::Label^  label06;
	private: System::Windows::Forms::Label^  label05;
	private: System::Windows::Forms::Label^  label04;
	private: System::Windows::Forms::Label^  label03;
	private: System::Windows::Forms::Label^  label02;
	private: System::Windows::Forms::Label^  label01;
	private: System::Windows::Forms::Label^  label00;

	private: System::ComponentModel::IContainer^  components;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


			 
	private: System::Windows::Forms::StatusStrip^  statusStrip1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;

			 System::ComponentModel::BackgroundWorker^ bgWorker;

			 Usb^ usb;
			 			 

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->checkBox56 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox55 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox54 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox53 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox52 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox51 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox50 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox49 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox48 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox47 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox46 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox45 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox44 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox43 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox42 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox41 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox40 = (gcnew System::Windows::Forms::CheckBox());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->checkBox36 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox35 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox34 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox33 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox32 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox31 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox30 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox29 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox28 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox27 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox26 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox25 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox24 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox23 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox22 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox21 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox20 = (gcnew System::Windows::Forms::CheckBox());
			this->groupBox0 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label09 = (gcnew System::Windows::Forms::Label());
			this->label08 = (gcnew System::Windows::Forms::Label());
			this->label07 = (gcnew System::Windows::Forms::Label());
			this->label06 = (gcnew System::Windows::Forms::Label());
			this->label05 = (gcnew System::Windows::Forms::Label());
			this->label04 = (gcnew System::Windows::Forms::Label());
			this->label03 = (gcnew System::Windows::Forms::Label());
			this->label02 = (gcnew System::Windows::Forms::Label());
			this->label01 = (gcnew System::Windows::Forms::Label());
			this->label00 = (gcnew System::Windows::Forms::Label());
			this->checkBox16 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox15 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox14 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox13 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox12 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox11 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox10 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox09 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox08 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox07 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox06 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox05 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox04 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox03 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox02 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox01 = (gcnew System::Windows::Forms::CheckBox());
			this->checkBox00 = (gcnew System::Windows::Forms::CheckBox());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->groupBox0->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->statusStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Location = System::Drawing::Point(16-3, 43);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(13, 13);
			this->label56->TabIndex = 116;
			this->label56->Text = L"C7";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Location = System::Drawing::Point(30, 43);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(13, 13);
			this->label55->TabIndex = 115;
			this->label55->Text = L"6";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Location = System::Drawing::Point(44, 43);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(13, 13);
			this->label54->TabIndex = 114;
			this->label54->Text = L"5";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Location = System::Drawing::Point(58, 43);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(13, 13);
			this->label53->TabIndex = 113;
			this->label53->Text = L"4";
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Location = System::Drawing::Point(72, 43);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(13, 13);
			this->label52->TabIndex = 112;
			this->label52->Text = L"3";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Location = System::Drawing::Point(86, 43);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(13, 13);
			this->label51->TabIndex = 111;
			this->label51->Text = L"2";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Location = System::Drawing::Point(100, 43);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(13, 13);
			this->label50->TabIndex = 110;
			this->label50->Text = L"1";
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Location = System::Drawing::Point(114, 43);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(13, 13);
			this->label49->TabIndex = 109;
			this->label49->Text = L"0";
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Location = System::Drawing::Point(128-3+14, 43);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(13, 13);
			this->label48->TabIndex = 108;
			this->label48->Text = L"B7";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(142+14, 43);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(13, 13);
			this->label47->TabIndex = 107;
			this->label47->Text = L"6";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(156+14, 43);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(13, 13);
			this->label46->TabIndex = 106;
			this->label46->Text = L"5";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(170+14, 43);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(13, 13);
			this->label45->TabIndex = 105;
			this->label45->Text = L"4";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(184+14, 43);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(13, 13);
			this->label44->TabIndex = 104;
			this->label44->Text = L"3";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Location = System::Drawing::Point(198+14, 43);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(13, 13);
			this->label43->TabIndex = 103;
			this->label43->Text = L"2";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(212+14, 43);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(13, 13);
			this->label42->TabIndex = 102;
			this->label42->Text = L"1";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(226+14, 43);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(13, 13);
			this->label41->TabIndex = 101;
			this->label41->Text = L"0";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(240-3+28, 43);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(13, 13);
			this->label40->TabIndex = 100;
			this->label40->Text = L"A0";
			// 
			// checkBox56
			// 
			this->checkBox56->AutoSize = true;
			this->checkBox56->Location = System::Drawing::Point(15, 27);
			this->checkBox56->Name = L"checkBox56";
			this->checkBox56->Size = System::Drawing::Size(15, 14);
			this->checkBox56->TabIndex = 96;
			this->checkBox56->UseVisualStyleBackColor = true;
			this->checkBox56->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox55
			// 
			this->checkBox55->AutoSize = true;
			this->checkBox55->Location = System::Drawing::Point(29, 27);
			this->checkBox55->Name = L"checkBox55";
			this->checkBox55->Size = System::Drawing::Size(15, 14);
			this->checkBox55->TabIndex = 95;
			this->checkBox55->UseVisualStyleBackColor = true;
			this->checkBox55->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox54
			// 
			this->checkBox54->AutoSize = true;
			this->checkBox54->Location = System::Drawing::Point(43, 27);
			this->checkBox54->Name = L"checkBox54";
			this->checkBox54->Size = System::Drawing::Size(15, 14);
			this->checkBox54->TabIndex = 94;
			this->checkBox54->UseVisualStyleBackColor = true;
			this->checkBox54->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox53
			// 
			this->checkBox53->AutoSize = true;
			this->checkBox53->Location = System::Drawing::Point(57, 27);
			this->checkBox53->Name = L"checkBox53";
			this->checkBox53->Size = System::Drawing::Size(15, 14);
			this->checkBox53->TabIndex = 93;
			this->checkBox53->UseVisualStyleBackColor = true;
			this->checkBox53->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox52
			// 
			this->checkBox52->AutoSize = true;
			this->checkBox52->Location = System::Drawing::Point(71, 27);
			this->checkBox52->Name = L"checkBox52";
			this->checkBox52->Size = System::Drawing::Size(15, 14);
			this->checkBox52->TabIndex = 92;
			this->checkBox52->UseVisualStyleBackColor = true;
			this->checkBox52->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox51
			// 
			this->checkBox51->AutoSize = true;
			this->checkBox51->Location = System::Drawing::Point(85, 27);
			this->checkBox51->Name = L"checkBox51";
			this->checkBox51->Size = System::Drawing::Size(15, 14);
			this->checkBox51->TabIndex = 91;
			this->checkBox51->UseVisualStyleBackColor = true;
			this->checkBox51->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox50
			// 
			this->checkBox50->AutoSize = true;
			this->checkBox50->Location = System::Drawing::Point(99, 27);
			this->checkBox50->Name = L"checkBox50";
			this->checkBox50->Size = System::Drawing::Size(15, 14);
			this->checkBox50->TabIndex = 90;
			this->checkBox50->UseVisualStyleBackColor = true;
			this->checkBox50->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox49
			// 
			this->checkBox49->AutoSize = true;
			this->checkBox49->Location = System::Drawing::Point(113, 27);
			this->checkBox49->Name = L"checkBox49";
			this->checkBox49->Size = System::Drawing::Size(15, 14);
			this->checkBox49->TabIndex = 89;
			this->checkBox49->UseVisualStyleBackColor = true;
			this->checkBox49->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox48
			// 
			this->checkBox48->AutoSize = true;
			this->checkBox48->Location = System::Drawing::Point(127+14, 27);
			this->checkBox48->Name = L"checkBox48";
			this->checkBox48->Size = System::Drawing::Size(15, 14);
			this->checkBox48->TabIndex = 88;
			this->checkBox48->UseVisualStyleBackColor = true;
			this->checkBox48->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox47
			// 
			this->checkBox47->AutoSize = true;
			this->checkBox47->Location = System::Drawing::Point(141+14, 27);
			this->checkBox47->Name = L"checkBox47";
			this->checkBox47->Size = System::Drawing::Size(15, 14);
			this->checkBox47->TabIndex = 87;
			this->checkBox47->UseVisualStyleBackColor = true;
			this->checkBox47->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox46
			// 
			this->checkBox46->AutoSize = true;
			this->checkBox46->Location = System::Drawing::Point(155+14, 27);
			this->checkBox46->Name = L"checkBox46";
			this->checkBox46->Size = System::Drawing::Size(15, 14);
			this->checkBox46->TabIndex = 86;
			this->checkBox46->UseVisualStyleBackColor = true;
			this->checkBox46->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox45
			// 
			this->checkBox45->AutoSize = true;
			this->checkBox45->Location = System::Drawing::Point(169+14, 27);
			this->checkBox45->Name = L"checkBox45";
			this->checkBox45->Size = System::Drawing::Size(15, 14);
			this->checkBox45->TabIndex = 85;
			this->checkBox45->UseVisualStyleBackColor = true;
			this->checkBox45->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox44
			// 
			this->checkBox44->AutoSize = true;
			this->checkBox44->Location = System::Drawing::Point(183+14, 27);
			this->checkBox44->Name = L"checkBox44";
			this->checkBox44->Size = System::Drawing::Size(15, 14);
			this->checkBox44->TabIndex = 84;
			this->checkBox44->UseVisualStyleBackColor = true;
			this->checkBox44->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox43
			// 
			this->checkBox43->AutoSize = true;
			this->checkBox43->Location = System::Drawing::Point(197+14, 27);
			this->checkBox43->Name = L"checkBox43";
			this->checkBox43->Size = System::Drawing::Size(15, 14);
			this->checkBox43->TabIndex = 83;
			this->checkBox43->UseVisualStyleBackColor = true;
			this->checkBox43->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox42
			// 
			this->checkBox42->AutoSize = true;
			this->checkBox42->Location = System::Drawing::Point(211+14, 27);
			this->checkBox42->Name = L"checkBox42";
			this->checkBox42->Size = System::Drawing::Size(15, 14);
			this->checkBox42->TabIndex = 82;
			this->checkBox42->UseVisualStyleBackColor = true;
			this->checkBox42->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox41
			// 
			this->checkBox41->AutoSize = true;
			this->checkBox41->Location = System::Drawing::Point(225+14, 27);
			this->checkBox41->Name = L"checkBox41";
			this->checkBox41->Size = System::Drawing::Size(15, 14);
			this->checkBox41->TabIndex = 81;
			this->checkBox41->UseVisualStyleBackColor = true;
			this->checkBox41->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// checkBox40
			// 
			this->checkBox40->AutoSize = true;
			this->checkBox40->Location = System::Drawing::Point(239+28, 27);
			this->checkBox40->Name = L"checkBox40";
			this->checkBox40->Size = System::Drawing::Size(15, 14);
			this->checkBox40->TabIndex = 80;
			this->checkBox40->UseVisualStyleBackColor = true;
			this->checkBox40->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged1);
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(16-3, 43);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(13, 13);
			this->label36->TabIndex = 76;
			this->label36->Text = L"C7";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(30, 43);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(13, 13);
			this->label35->TabIndex = 75;
			this->label35->Text = L"6";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(44, 43);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(13, 13);
			this->label34->TabIndex = 74;
			this->label34->Text = L"5";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(58, 43);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(13, 13);
			this->label33->TabIndex = 73;
			this->label33->Text = L"4";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(72, 43);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(13, 13);
			this->label32->TabIndex = 72;
			this->label32->Text = L"3";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(86, 43);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(13, 13);
			this->label31->TabIndex = 71;
			this->label31->Text = L"2";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(100, 43);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(13, 13);
			this->label30->TabIndex = 70;
			this->label30->Text = L"1";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(114, 43);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(13, 13);
			this->label29->TabIndex = 69;
			this->label29->Text = L"0";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(128-3+14, 43);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(13, 13);
			this->label28->TabIndex = 68;
			this->label28->Text = L"B7";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(142+14, 43);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(13, 13);
			this->label27->TabIndex = 67;
			this->label27->Text = L"6";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(156+14, 43);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 13);
			this->label26->TabIndex = 66;
			this->label26->Text = L"5";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(170+14, 43);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(13, 13);
			this->label25->TabIndex = 65;
			this->label25->Text = L"4";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(184+14, 43);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(13, 13);
			this->label24->TabIndex = 64;
			this->label24->Text = L"3";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(198+14, 43);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(13, 13);
			this->label23->TabIndex = 63;
			this->label23->Text = L"2";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(212+14, 43);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(13, 13);
			this->label22->TabIndex = 62;
			this->label22->Text = L"1";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(226+14, 43);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(13, 13);
			this->label21->TabIndex = 61;
			this->label21->Text = L"0";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(240-3+28, 43);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(13, 13);
			this->label20->TabIndex = 60;
			this->label20->Text = L"A0";
			// 
			// checkBox36
			// 
			this->checkBox36->AutoSize = true;
			this->checkBox36->Enabled = false;
			this->checkBox36->Location = System::Drawing::Point(15, 27);
			this->checkBox36->Name = L"checkBox36";
			this->checkBox36->Size = System::Drawing::Size(15, 14);
			this->checkBox36->TabIndex = 56;
			this->checkBox36->UseVisualStyleBackColor = true;
			// 
			// checkBox35
			// 
			this->checkBox35->AutoSize = true;
			this->checkBox35->Enabled = false;
			this->checkBox35->Location = System::Drawing::Point(29, 27);
			this->checkBox35->Name = L"checkBox35";
			this->checkBox35->Size = System::Drawing::Size(15, 14);
			this->checkBox35->TabIndex = 55;
			this->checkBox35->UseVisualStyleBackColor = true;
			// 
			// checkBox34
			// 
			this->checkBox34->AutoSize = true;
			this->checkBox34->Enabled = false;
			this->checkBox34->Location = System::Drawing::Point(43, 27);
			this->checkBox34->Name = L"checkBox34";
			this->checkBox34->Size = System::Drawing::Size(15, 14);
			this->checkBox34->TabIndex = 54;
			this->checkBox34->UseVisualStyleBackColor = true;
			// 
			// checkBox33
			// 
			this->checkBox33->AutoSize = true;
			this->checkBox33->Enabled = false;
			this->checkBox33->Location = System::Drawing::Point(57, 27);
			this->checkBox33->Name = L"checkBox33";
			this->checkBox33->Size = System::Drawing::Size(15, 14);
			this->checkBox33->TabIndex = 53;
			this->checkBox33->UseVisualStyleBackColor = true;
			// 
			// checkBox32
			// 
			this->checkBox32->AutoSize = true;
			this->checkBox32->Enabled = false;
			this->checkBox32->Location = System::Drawing::Point(71, 27);
			this->checkBox32->Name = L"checkBox32";
			this->checkBox32->Size = System::Drawing::Size(15, 14);
			this->checkBox32->TabIndex = 52;
			this->checkBox32->UseVisualStyleBackColor = true;
			// 
			// checkBox31
			// 
			this->checkBox31->AutoSize = true;
			this->checkBox31->Enabled = false;
			this->checkBox31->Location = System::Drawing::Point(85, 27);
			this->checkBox31->Name = L"checkBox31";
			this->checkBox31->Size = System::Drawing::Size(15, 14);
			this->checkBox31->TabIndex = 51;
			this->checkBox31->UseVisualStyleBackColor = true;
			// 
			// checkBox30
			// 
			this->checkBox30->AutoSize = true;
			this->checkBox30->Enabled = false;
			this->checkBox30->Location = System::Drawing::Point(99, 27);
			this->checkBox30->Name = L"checkBox30";
			this->checkBox30->Size = System::Drawing::Size(15, 14);
			this->checkBox30->TabIndex = 50;
			this->checkBox30->UseVisualStyleBackColor = true;
			// 
			// checkBox29
			// 
			this->checkBox29->AutoSize = true;
			this->checkBox29->Enabled = false;
			this->checkBox29->Location = System::Drawing::Point(113, 27);
			this->checkBox29->Name = L"checkBox29";
			this->checkBox29->Size = System::Drawing::Size(15, 14);
			this->checkBox29->TabIndex = 49;
			this->checkBox29->UseVisualStyleBackColor = true;
			// 
			// checkBox28
			// 
			this->checkBox28->AutoSize = true;
			this->checkBox28->Enabled = false;
			this->checkBox28->Location = System::Drawing::Point(127+14, 27);
			this->checkBox28->Name = L"checkBox28";
			this->checkBox28->Size = System::Drawing::Size(15, 14);
			this->checkBox28->TabIndex = 48;
			this->checkBox28->UseVisualStyleBackColor = true;
			// 
			// checkBox27
			// 
			this->checkBox27->AutoSize = true;
			this->checkBox27->Enabled = false;
			this->checkBox27->Location = System::Drawing::Point(141+14, 27);
			this->checkBox27->Name = L"checkBox27";
			this->checkBox27->Size = System::Drawing::Size(15, 14);
			this->checkBox27->TabIndex = 47;
			this->checkBox27->UseVisualStyleBackColor = true;
			// 
			// checkBox26
			// 
			this->checkBox26->AutoSize = true;
			this->checkBox26->Enabled = false;
			this->checkBox26->Location = System::Drawing::Point(155+14, 27);
			this->checkBox26->Name = L"checkBox26";
			this->checkBox26->Size = System::Drawing::Size(15, 14);
			this->checkBox26->TabIndex = 46;
			this->checkBox26->UseVisualStyleBackColor = true;
			// 
			// checkBox25
			// 
			this->checkBox25->AutoSize = true;
			this->checkBox25->Enabled = false;
			this->checkBox25->Location = System::Drawing::Point(169+14, 27);
			this->checkBox25->Name = L"checkBox25";
			this->checkBox25->Size = System::Drawing::Size(15, 14);
			this->checkBox25->TabIndex = 45;
			this->checkBox25->UseVisualStyleBackColor = true;
			// 
			// checkBox24
			// 
			this->checkBox24->AutoSize = true;
			this->checkBox24->Enabled = false;
			this->checkBox24->Location = System::Drawing::Point(183+14, 27);
			this->checkBox24->Name = L"checkBox24";
			this->checkBox24->Size = System::Drawing::Size(15, 14);
			this->checkBox24->TabIndex = 44;
			this->checkBox24->UseVisualStyleBackColor = true;
			// 
			// checkBox23
			// 
			this->checkBox23->AutoSize = true;
			this->checkBox23->Enabled = false;
			this->checkBox23->Location = System::Drawing::Point(197+14, 27);
			this->checkBox23->Name = L"checkBox23";
			this->checkBox23->Size = System::Drawing::Size(15, 14);
			this->checkBox23->TabIndex = 43;
			this->checkBox23->UseVisualStyleBackColor = true;
			// 
			// checkBox22
			// 
			this->checkBox22->AutoSize = true;
			this->checkBox22->Enabled = false;
			this->checkBox22->Location = System::Drawing::Point(211+14, 27);
			this->checkBox22->Name = L"checkBox22";
			this->checkBox22->Size = System::Drawing::Size(15, 14);
			this->checkBox22->TabIndex = 42;
			this->checkBox22->UseVisualStyleBackColor = true;
			// 
			// checkBox21
			// 
			this->checkBox21->AutoSize = true;
			this->checkBox21->Enabled = false;
			this->checkBox21->Location = System::Drawing::Point(225+14, 27);
			this->checkBox21->Name = L"checkBox21";
			this->checkBox21->Size = System::Drawing::Size(15, 14);
			this->checkBox21->TabIndex = 41;
			this->checkBox21->UseVisualStyleBackColor = true;
			// 
			// checkBox20
			// 
			this->checkBox20->AutoSize = true;
			this->checkBox20->Enabled = false;
			this->checkBox20->Location = System::Drawing::Point(239+28, 27);
			this->checkBox20->Name = L"checkBox20";
			this->checkBox20->Size = System::Drawing::Size(15, 14);
			this->checkBox20->TabIndex = 40;
			this->checkBox20->UseVisualStyleBackColor = true;
			// 
			// groupBox0
			// 
			this->groupBox0->Controls->Add(this->label56);
			this->groupBox0->Controls->Add(this->label55);
			this->groupBox0->Controls->Add(this->label54);
			this->groupBox0->Controls->Add(this->label53);
			this->groupBox0->Controls->Add(this->label52);
			this->groupBox0->Controls->Add(this->label51);
			this->groupBox0->Controls->Add(this->label50);
			this->groupBox0->Controls->Add(this->label49);
			this->groupBox0->Controls->Add(this->label48);
			this->groupBox0->Controls->Add(this->label47);
			this->groupBox0->Controls->Add(this->label46);
			this->groupBox0->Controls->Add(this->label45);
			this->groupBox0->Controls->Add(this->label44);
			this->groupBox0->Controls->Add(this->label43);
			this->groupBox0->Controls->Add(this->label42);
			this->groupBox0->Controls->Add(this->label41);
			this->groupBox0->Controls->Add(this->label40);
			this->groupBox0->Controls->Add(this->checkBox56);
			this->groupBox0->Controls->Add(this->checkBox55);
			this->groupBox0->Controls->Add(this->checkBox54);
			this->groupBox0->Controls->Add(this->checkBox53);
			this->groupBox0->Controls->Add(this->checkBox52);
			this->groupBox0->Controls->Add(this->checkBox51);
			this->groupBox0->Controls->Add(this->checkBox50);
			this->groupBox0->Controls->Add(this->checkBox49);
			this->groupBox0->Controls->Add(this->checkBox48);
			this->groupBox0->Controls->Add(this->checkBox47);
			this->groupBox0->Controls->Add(this->checkBox46);
			this->groupBox0->Controls->Add(this->checkBox45);
			this->groupBox0->Controls->Add(this->checkBox44);
			this->groupBox0->Controls->Add(this->checkBox43);
			this->groupBox0->Controls->Add(this->checkBox42);
			this->groupBox0->Controls->Add(this->checkBox41);
			this->groupBox0->Controls->Add(this->checkBox40);
			this->groupBox0->Location = System::Drawing::Point(30, 3);
			this->groupBox0->Name = L"groupBox0";
			this->groupBox0->Size = System::Drawing::Size(256+14+28, 60);
			this->groupBox0->TabIndex = 1;
			this->groupBox0->TabStop = false;
			this->groupBox0->Text = L"TRIS";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label36);
			this->groupBox1->Controls->Add(this->label35);
			this->groupBox1->Controls->Add(this->label34);
			this->groupBox1->Controls->Add(this->label33);
			this->groupBox1->Controls->Add(this->label32);
			this->groupBox1->Controls->Add(this->label31);
			this->groupBox1->Controls->Add(this->label30);
			this->groupBox1->Controls->Add(this->label29);
			this->groupBox1->Controls->Add(this->label28);
			this->groupBox1->Controls->Add(this->label27);
			this->groupBox1->Controls->Add(this->label26);
			this->groupBox1->Controls->Add(this->label25);
			this->groupBox1->Controls->Add(this->label24);
			this->groupBox1->Controls->Add(this->label23);
			this->groupBox1->Controls->Add(this->label22);
			this->groupBox1->Controls->Add(this->label21);
			this->groupBox1->Controls->Add(this->label20);
			this->groupBox1->Controls->Add(this->checkBox36);
			this->groupBox1->Controls->Add(this->checkBox35);
			this->groupBox1->Controls->Add(this->checkBox34);
			this->groupBox1->Controls->Add(this->checkBox33);
			this->groupBox1->Controls->Add(this->checkBox32);
			this->groupBox1->Controls->Add(this->checkBox31);
			this->groupBox1->Controls->Add(this->checkBox30);
			this->groupBox1->Controls->Add(this->checkBox29);
			this->groupBox1->Controls->Add(this->checkBox28);
			this->groupBox1->Controls->Add(this->checkBox27);
			this->groupBox1->Controls->Add(this->checkBox26);
			this->groupBox1->Controls->Add(this->checkBox25);
			this->groupBox1->Controls->Add(this->checkBox24);
			this->groupBox1->Controls->Add(this->checkBox23);
			this->groupBox1->Controls->Add(this->checkBox22);
			this->groupBox1->Controls->Add(this->checkBox21);
			this->groupBox1->Controls->Add(this->checkBox20);
			this->groupBox1->Location = System::Drawing::Point(30, 68);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(256+14+28, 60);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"INPUT";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label16);
			this->groupBox2->Controls->Add(this->label15);
			this->groupBox2->Controls->Add(this->label14);
			this->groupBox2->Controls->Add(this->label13);
			this->groupBox2->Controls->Add(this->label12);
			this->groupBox2->Controls->Add(this->label11);
			this->groupBox2->Controls->Add(this->label10);
			this->groupBox2->Controls->Add(this->label09);
			this->groupBox2->Controls->Add(this->label08);
			this->groupBox2->Controls->Add(this->label07);
			this->groupBox2->Controls->Add(this->label06);
			this->groupBox2->Controls->Add(this->label05);
			this->groupBox2->Controls->Add(this->label04);
			this->groupBox2->Controls->Add(this->label03);
			this->groupBox2->Controls->Add(this->label02);
			this->groupBox2->Controls->Add(this->label01);
			this->groupBox2->Controls->Add(this->label00);
			this->groupBox2->Controls->Add(this->checkBox16);
			this->groupBox2->Controls->Add(this->checkBox15);
			this->groupBox2->Controls->Add(this->checkBox14);
			this->groupBox2->Controls->Add(this->checkBox13);
			this->groupBox2->Controls->Add(this->checkBox12);
			this->groupBox2->Controls->Add(this->checkBox11);
			this->groupBox2->Controls->Add(this->checkBox10);
			this->groupBox2->Controls->Add(this->checkBox09);
			this->groupBox2->Controls->Add(this->checkBox08);
			this->groupBox2->Controls->Add(this->checkBox07);
			this->groupBox2->Controls->Add(this->checkBox06);
			this->groupBox2->Controls->Add(this->checkBox05);
			this->groupBox2->Controls->Add(this->checkBox04);
			this->groupBox2->Controls->Add(this->checkBox03);
			this->groupBox2->Controls->Add(this->checkBox02);
			this->groupBox2->Controls->Add(this->checkBox01);
			this->groupBox2->Controls->Add(this->checkBox00);
			this->groupBox2->Location = System::Drawing::Point(30, 133);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(256+14+28, 60);
			this->groupBox2->TabIndex = 3;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"OUTPUT";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(16-3, 43);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(13, 13);
			this->label16->TabIndex = 36;
			this->label16->Text = L"C7";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(30, 43);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(13, 13);
			this->label15->TabIndex = 35;
			this->label15->Text = L"6";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(44, 43);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(13, 13);
			this->label14->TabIndex = 34;
			this->label14->Text = L"5";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(58, 43);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(13, 13);
			this->label13->TabIndex = 33;
			this->label13->Text = L"4";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(72, 43);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(13, 13);
			this->label12->TabIndex = 32;
			this->label12->Text = L"3";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(86, 43);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(13, 13);
			this->label11->TabIndex = 31;
			this->label11->Text = L"2";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(100, 43);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(13, 13);
			this->label10->TabIndex = 30;
			this->label10->Text = L"1";
			// 
			// label09
			// 
			this->label09->AutoSize = true;
			this->label09->Location = System::Drawing::Point(114, 43);
			this->label09->Name = L"label09";
			this->label09->Size = System::Drawing::Size(13, 13);
			this->label09->TabIndex = 29;
			this->label09->Text = L"0";
			// 
			// label08
			// 
			this->label08->AutoSize = true;
			this->label08->Location = System::Drawing::Point(128-3+14, 43);
			this->label08->Name = L"label08";
			this->label08->Size = System::Drawing::Size(13, 13);
			this->label08->TabIndex = 28;
			this->label08->Text = L"B7";
			// 
			// label07
			// 
			this->label07->AutoSize = true;
			this->label07->Location = System::Drawing::Point(142+14, 43);
			this->label07->Name = L"label07";
			this->label07->Size = System::Drawing::Size(13, 13);
			this->label07->TabIndex = 27;
			this->label07->Text = L"6";
			// 
			// label06
			// 
			this->label06->AutoSize = true;
			this->label06->Location = System::Drawing::Point(156+14, 43);
			this->label06->Name = L"label06";
			this->label06->Size = System::Drawing::Size(13, 13);
			this->label06->TabIndex = 26;
			this->label06->Text = L"5";
			// 
			// label05
			// 
			this->label05->AutoSize = true;
			this->label05->Location = System::Drawing::Point(170+14, 43);
			this->label05->Name = L"label05";
			this->label05->Size = System::Drawing::Size(13, 13);
			this->label05->TabIndex = 25;
			this->label05->Text = L"4";
			// 
			// label04
			// 
			this->label04->AutoSize = true;
			this->label04->Location = System::Drawing::Point(184+14, 43);
			this->label04->Name = L"label04";
			this->label04->Size = System::Drawing::Size(13, 13);
			this->label04->TabIndex = 24;
			this->label04->Text = L"3";
			// 
			// label03
			// 
			this->label03->AutoSize = true;
			this->label03->Location = System::Drawing::Point(198+14, 43);
			this->label03->Name = L"label03";
			this->label03->Size = System::Drawing::Size(13, 13);
			this->label03->TabIndex = 23;
			this->label03->Text = L"2";
			// 
			// label02
			// 
			this->label02->AutoSize = true;
			this->label02->Location = System::Drawing::Point(212+14, 43);
			this->label02->Name = L"label02";
			this->label02->Size = System::Drawing::Size(13, 13);
			this->label02->TabIndex = 22;
			this->label02->Text = L"1";
			// 
			// label01
			// 
			this->label01->AutoSize = true;
			this->label01->Location = System::Drawing::Point(226+14, 43);
			this->label01->Name = L"label01";
			this->label01->Size = System::Drawing::Size(13, 13);
			this->label01->TabIndex = 21;
			this->label01->Text = L"0";
			// 
			// label00
			// 
			this->label00->AutoSize = true;
			this->label00->Location = System::Drawing::Point(240-3+28, 43);
			this->label00->Name = L"label00";
			this->label00->Size = System::Drawing::Size(13, 13);
			this->label00->TabIndex = 20;
			this->label00->Text = L"A0";
			// 
			// checkBox16
			// 
			this->checkBox16->AutoSize = true;
			this->checkBox16->Location = System::Drawing::Point(15, 27);
			this->checkBox16->Name = L"checkBox16";
			this->checkBox16->Size = System::Drawing::Size(15, 14);
			this->checkBox16->TabIndex = 16;
			this->checkBox16->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox16->UseVisualStyleBackColor = true;
			this->checkBox16->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox15
			// 
			this->checkBox15->AutoSize = true;
			this->checkBox15->Location = System::Drawing::Point(29, 27);
			this->checkBox15->Name = L"checkBox15";
			this->checkBox15->Size = System::Drawing::Size(15, 14);
			this->checkBox15->TabIndex = 15;
			this->checkBox15->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox15->UseVisualStyleBackColor = true;
			this->checkBox15->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox14
			// 
			this->checkBox14->AutoSize = true;
			this->checkBox14->Location = System::Drawing::Point(43, 27);
			this->checkBox14->Name = L"checkBox14";
			this->checkBox14->Size = System::Drawing::Size(15, 14);
			this->checkBox14->TabIndex = 14;
			this->checkBox14->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox14->UseVisualStyleBackColor = true;
			this->checkBox14->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox13
			// 
			this->checkBox13->AutoSize = true;
			this->checkBox13->Location = System::Drawing::Point(57, 27);
			this->checkBox13->Name = L"checkBox13";
			this->checkBox13->Size = System::Drawing::Size(15, 14);
			this->checkBox13->TabIndex = 13;
			this->checkBox13->UseVisualStyleBackColor = true;
			this->checkBox13->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox12
			// 
			this->checkBox12->AutoSize = true;
			this->checkBox12->Location = System::Drawing::Point(71, 27);
			this->checkBox12->Name = L"checkBox12";
			this->checkBox12->Size = System::Drawing::Size(15, 14);
			this->checkBox12->TabIndex = 12;
			this->checkBox12->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox12->UseVisualStyleBackColor = true;
			this->checkBox12->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox11
			// 
			this->checkBox11->AutoSize = true;
			this->checkBox11->Location = System::Drawing::Point(85, 27);
			this->checkBox11->Name = L"checkBox11";
			this->checkBox11->Size = System::Drawing::Size(15, 14);
			this->checkBox11->TabIndex = 11;
			this->checkBox11->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox11->UseVisualStyleBackColor = true;
			this->checkBox11->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox10
			// 
			this->checkBox10->AutoSize = true;
			this->checkBox10->Location = System::Drawing::Point(99, 27);
			this->checkBox10->Name = L"checkBox10";
			this->checkBox10->Size = System::Drawing::Size(15, 14);
			this->checkBox10->TabIndex = 10;
			this->checkBox10->UseVisualStyleBackColor = true;
			this->checkBox10->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox09
			// 
			this->checkBox09->AutoSize = true;
			this->checkBox09->Location = System::Drawing::Point(113, 27);
			this->checkBox09->Name = L"checkBox09";
			this->checkBox09->Size = System::Drawing::Size(15, 14);
			this->checkBox09->TabIndex = 9;
			this->checkBox09->UseVisualStyleBackColor = true;
			this->checkBox09->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox08
			// 
			this->checkBox08->AutoSize = true;
			this->checkBox08->Location = System::Drawing::Point(127+14, 27);
			this->checkBox08->Name = L"checkBox08";
			this->checkBox08->Size = System::Drawing::Size(15, 14);
			this->checkBox08->TabIndex = 8;
			this->checkBox08->UseVisualStyleBackColor = true;
			this->checkBox08->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox07
			// 
			this->checkBox07->AutoSize = true;
			this->checkBox07->Location = System::Drawing::Point(141+14, 27);
			this->checkBox07->Name = L"checkBox07";
			this->checkBox07->Size = System::Drawing::Size(15, 14);
			this->checkBox07->TabIndex = 7;
			this->checkBox07->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox07->UseVisualStyleBackColor = true;
			this->checkBox07->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox06
			// 
			this->checkBox06->AutoSize = true;
			this->checkBox06->Location = System::Drawing::Point(155+14, 27);
			this->checkBox06->Name = L"checkBox06";
			this->checkBox06->Size = System::Drawing::Size(15, 14);
			this->checkBox06->TabIndex = 6;
			this->checkBox06->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox06->UseVisualStyleBackColor = true;
			this->checkBox06->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox05
			// 
			this->checkBox05->AutoSize = true;
			this->checkBox05->Location = System::Drawing::Point(169+14, 27);
			this->checkBox05->Name = L"checkBox05";
			this->checkBox05->Size = System::Drawing::Size(15, 14);
			this->checkBox05->TabIndex = 5;
			this->checkBox05->UseVisualStyleBackColor = true;
			this->checkBox05->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox04
			// 
			this->checkBox04->AutoSize = true;
			this->checkBox04->Location = System::Drawing::Point(183+14, 27);
			this->checkBox04->Name = L"checkBox04";
			this->checkBox04->Size = System::Drawing::Size(15, 14);
			this->checkBox04->TabIndex = 4;
			this->checkBox04->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox04->UseVisualStyleBackColor = true;
			this->checkBox04->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox03
			// 
			this->checkBox03->AutoSize = true;
			this->checkBox03->Location = System::Drawing::Point(197+14, 27);
			this->checkBox03->Name = L"checkBox03";
			this->checkBox03->Size = System::Drawing::Size(15, 14);
			this->checkBox03->TabIndex = 3;
			this->checkBox03->TextAlign = System::Drawing::ContentAlignment::TopLeft;
			this->checkBox03->UseVisualStyleBackColor = true;
			this->checkBox03->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox02
			// 
			this->checkBox02->AutoSize = true;
			this->checkBox02->Location = System::Drawing::Point(211+14, 27);
			this->checkBox02->Name = L"checkBox02";
			this->checkBox02->Size = System::Drawing::Size(15, 14);
			this->checkBox02->TabIndex = 2;
			this->checkBox02->UseVisualStyleBackColor = true;
			this->checkBox02->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox01
			// 
			this->checkBox01->AutoSize = true;
			this->checkBox01->Location = System::Drawing::Point(225+14, 27);
			this->checkBox01->Name = L"checkBox01";
			this->checkBox01->Size = System::Drawing::Size(15, 14);
			this->checkBox01->TabIndex = 1;
			this->checkBox01->UseVisualStyleBackColor = true;
			this->checkBox01->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// checkBox00
			// 
			this->checkBox00->AutoSize = true;
			this->checkBox00->Location = System::Drawing::Point(239+28, 27);
			this->checkBox00->Name = L"checkBox00";
			this->checkBox00->Size = System::Drawing::Size(15, 14);
			this->checkBox00->TabIndex = 0;
			this->checkBox00->UseVisualStyleBackColor = true;
			this->checkBox00->CheckedChanged += gcnew System::EventHandler(this, &Form1::outCheck_CheckedChanged2);
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->toolStripStatusLabel1});
			this->statusStrip1->Location = System::Drawing::Point(0, 197);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(319+14+28, 22);
			this->statusStrip1->TabIndex = 4;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
			this->toolStripStatusLabel1->Size = System::Drawing::Size(0, 17);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(319+14+28, 219);
			this->Controls->Add(this->statusStrip1);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox0);
			this->Name = L"Form1";
			this->Text = L"16FUSB Direct I/O HID Sample App";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox0->ResumeLayout(false);
			this->groupBox0->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 if(this->toolStripStatusLabel1->Text == "") {
				Application::Exit();
			 }			 
		 }
private: System::Void inputThread( Object^ sender, DoWorkEventArgs^ e ) {
			 
			 unsigned char *inputReport;

			 while(true) {

				 inputReport = usb->readReport3();

				 if((inputReport[3] & 0x80) == 0) {
					 this->setChecked(this->checkBox36, false);
				 } else {
					 this->setChecked(this->checkBox36, true);
				 }
				 if((inputReport[3] & 0x40) == 0) {
					 this->setChecked(this->checkBox35, false);
				 } else {
					 this->setChecked(this->checkBox35, true);
				 }
				 if((inputReport[3] & 0x20) == 0) {
					 this->setChecked(this->checkBox34, false);
				 } else {
					 this->setChecked(this->checkBox34, true);
				 }
				 if((inputReport[3] & 0x10) == 0) {
					 this->setChecked(this->checkBox33, false);
				 } else {
					 this->setChecked(this->checkBox33, true);
				 }
				 if((inputReport[3] & 0x08) == 0) {
					 this->setChecked(this->checkBox32, false);
				 } else {
					 this->setChecked(this->checkBox32, true);
				 }
				 if((inputReport[3] & 0x04) == 0) {
					 this->setChecked(this->checkBox31, false);
				 } else {
					 this->setChecked(this->checkBox31, true);
				 }
				 if((inputReport[3] & 0x02) == 0) {
					 this->setChecked(this->checkBox30, false);
				 } else {
					 this->setChecked(this->checkBox30, true);
				 }
				 if((inputReport[3] & 0x01) == 0) {
					 this->setChecked(this->checkBox29, false);
				 } else {
					 this->setChecked(this->checkBox29, true);
				 }

				 if((inputReport[2] & 0x80) == 0) {
					 this->setChecked(this->checkBox28, false);
				 } else {
					 this->setChecked(this->checkBox28, true);
				 }
				 if((inputReport[2] & 0x40) == 0) {
					 this->setChecked(this->checkBox27, false);
				 } else {
					 this->setChecked(this->checkBox27, true);
				 }
				 if((inputReport[2] & 0x20) == 0) {
					 this->setChecked(this->checkBox26, false);
				 } else {
					 this->setChecked(this->checkBox26, true);
				 }
				 if((inputReport[2] & 0x10) == 0) {
					 this->setChecked(this->checkBox25, false);
				 } else {
					 this->setChecked(this->checkBox25, true);
				 }
				 if((inputReport[2] & 0x08) == 0) {
					 this->setChecked(this->checkBox24, false);
				 } else {
					 this->setChecked(this->checkBox24, true);
				 }
				 if((inputReport[2] & 0x04) == 0) {
					 this->setChecked(this->checkBox23, false);
				 } else {
					 this->setChecked(this->checkBox23, true);
				 }
				 if((inputReport[2] & 0x02) == 0) {
					 this->setChecked(this->checkBox22, false);
				 } else {
					 this->setChecked(this->checkBox22, true);
				 }
				 if((inputReport[2] & 0x01) == 0) {
					 this->setChecked(this->checkBox21, false);
				 } else {
					 this->setChecked(this->checkBox21, true);
				 }

				 if((inputReport[1] & 0x01) == 0) {
					 this->setChecked(this->checkBox20, false);
				 } else {
					 this->setChecked(this->checkBox20, true);
				 }
			 }
		 }
private: System::Void setChecked(CheckBox^ chk, bool check) {
			if(chk->InvokeRequired) {
				SetCheckDelegate^ c = gcnew SetCheckDelegate(this, &Form1::setChecked);
				this->Invoke(c, chk, check);
			} else {
				chk->Checked = check;
			}
		 }

private: System::Void outCheck_CheckedChanged1(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[4];
			outputReport[0] = 0;

			int bitsToSend_A = 128;
			int bitsToSend_B = 0x0;
			int bitsToSend_C = 0x0;

			bitsToSend_A |= (this->checkBox40->Checked == true) ? 1 : 0;

			bitsToSend_B |= (this->checkBox41->Checked == true) ? 1 : 0;
			bitsToSend_B |= (this->checkBox42->Checked == true) ? 2 : 0;
			bitsToSend_B |= (this->checkBox43->Checked == true) ? 4 : 0;
			bitsToSend_B |= (this->checkBox44->Checked == true) ? 8 : 0;
			bitsToSend_B |= (this->checkBox45->Checked == true) ? 16 : 0;
			bitsToSend_B |= (this->checkBox46->Checked == true) ? 32 : 0;
			bitsToSend_B |= (this->checkBox47->Checked == true) ? 64 : 0;
			bitsToSend_B |= (this->checkBox48->Checked == true) ? 128 : 0;

			bitsToSend_C |= (this->checkBox49->Checked == true) ? 1 : 0;
			bitsToSend_C |= (this->checkBox50->Checked == true) ? 2 : 0;
			bitsToSend_C |= (this->checkBox51->Checked == true) ? 4 : 0;
			bitsToSend_C |= (this->checkBox52->Checked == true) ? 8 : 0;
			bitsToSend_C |= (this->checkBox53->Checked == true) ? 16 : 0;
			bitsToSend_C |= (this->checkBox54->Checked == true) ? 32 : 0;
			bitsToSend_C |= (this->checkBox55->Checked == true) ? 64 : 0;
			bitsToSend_C |= (this->checkBox56->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend_A;
			outputReport[2] = bitsToSend_B;
			outputReport[3] = bitsToSend_C;
			usb->writeReport3(outputReport);
		 }

private: System::Void outCheck_CheckedChanged2(System::Object^  sender, System::EventArgs^  e) {
			unsigned char outputReport[4];
			outputReport[0] = 0;

			int bitsToSend_A = 0x0;
			int bitsToSend_B = 0x0;
			int bitsToSend_C = 0x0;

			bitsToSend_A |= (this->checkBox00->Checked == true) ? 1 : 0;

			bitsToSend_B |= (this->checkBox01->Checked == true) ? 1 : 0;
			bitsToSend_B |= (this->checkBox02->Checked == true) ? 2 : 0;
			bitsToSend_B |= (this->checkBox03->Checked == true) ? 4 : 0;
			bitsToSend_B |= (this->checkBox04->Checked == true) ? 8 : 0;
			bitsToSend_B |= (this->checkBox05->Checked == true) ? 16 : 0;
			bitsToSend_B |= (this->checkBox06->Checked == true) ? 32 : 0;
			bitsToSend_B |= (this->checkBox07->Checked == true) ? 64 : 0;
			bitsToSend_B |= (this->checkBox08->Checked == true) ? 128 : 0;

			bitsToSend_C |= (this->checkBox09->Checked == true) ? 1 : 0;
			bitsToSend_C |= (this->checkBox10->Checked == true) ? 2 : 0;
			bitsToSend_C |= (this->checkBox11->Checked == true) ? 4 : 0;
			bitsToSend_C |= (this->checkBox12->Checked == true) ? 8 : 0;
			bitsToSend_C |= (this->checkBox13->Checked == true) ? 16 : 0;
			bitsToSend_C |= (this->checkBox14->Checked == true) ? 32 : 0;
			bitsToSend_C |= (this->checkBox15->Checked == true) ? 64 : 0;
			bitsToSend_C |= (this->checkBox16->Checked == true) ? 128 : 0;

			outputReport[1] = bitsToSend_A;
			outputReport[2] = bitsToSend_B;
			outputReport[3] = bitsToSend_C;
			usb->writeReport3(outputReport);
		 }

};

}

