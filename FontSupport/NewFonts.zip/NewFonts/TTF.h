Dim GLCDPrintLoc , CharCol,  CharRow,  CharColS,   CharRowS, CharOffSetBegin, CharOffSetEnd, CharDiscr, GLCDFontWidth as Word

Sub GLCDPrintTTF (In PrintLocX as Word, In PrintLocY as Word, In PrintData As String, Optional In GLCDFont as Byte =GLCDArial, Optional In  GLCDForeground as word = GLCDForeground, Optional In Size=10 )
          PrintLen = PrintData(0)
	If PrintLen = 0 Then Exit Sub
	GLCDPrintLoc = PrintLocX
          GLCDFontWidth=0
	For SysPrintTem = 1 To PrintLen
		GLCDDrawTTF GLCDPrintLoc, PrintLocY, PrintData(SysPrintTem), GLCDFont,  GLCDForeground , Size
		GLCDPrintLoc = [Word]GLCDPrintLoc + GLCDFontWidth
	Next
End Sub

Sub GLCDDrawTTF ( In CharLocX as Word, In CharLocY as Word, In CharCode, Optional In GLCDFont as Byte =GLCDArial,  Optional In  GLCDForeground as word = GLCDForeground,  Optional In Size = 10)
  '" !"0123456789:;<=>?@[\]^_`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,%$#&*{|}~()+-/'"
  Select Case CharCode
       Case  " " : CharNum=1
       Case  "!" : CharNum=2
       Case  "`" : CharNum=3
       Case  "#" : CharNum=4
       Case  "$" : CharNum=5
       Case  "%" : CharNum=6
       Case  "&" : CharNum=7
       Case  "`" : CharNum=8
       Case  "(" : CharNum=9
       Case  ")" : CharNum=10
       Case  "*" : CharNum=11
       Case  "+" : CharNum=12
       Case  "," : CharNum=13
       Case  "-" : CharNum=14
       Case  "." : CharNum=15
       Case  "/" : CharNum=16
       Case  "0" : CharNum=17
       Case  "1" : CharNum=18
       Case  "2" : CharNum=19
       Case  "3" : CharNum=20
       Case  "4" : CharNum=21
       Case  "5" : CharNum=22
       Case  "6" : CharNum=23
       Case  "7" : CharNum=24
       Case  "8" : CharNum=25
       Case  "9" : CharNum=26
       Case  ":" : CharNum=27
       Case  ";" : CharNum=28
       Case  "<" : CharNum=29
       Case  "=" : CharNum=30
       Case  ">" : CharNum=31
       Case  "?" : CharNum=32
       Case  "@" : CharNum=33
       Case  "A" : CharNum=34
       Case  "B" : CharNum=35
       Case  "C" : CharNum=36
       Case  "D" : CharNum=37
       Case  "E" : CharNum=38
       Case  "F" : CharNum=39
       Case  "G" : CharNum=40
       Case  "H" : CharNum=41
       Case  "I" : CharNum=42
       Case  "J" : CharNum=43
       Case  "K" : CharNum=44
       Case  "L" : CharNum=45
       Case  "M" : CharNum=46
       Case  "N" : CharNum=47
       Case  "O" : CharNum=48
       Case  "P" : CharNum=49
       Case  "Q" : CharNum=50
       Case  "R" : CharNum=51
       Case  "S" : CharNum=52
       Case  "T" : CharNum=53
       Case  "U" : CharNum=54
       Case  "V" : CharNum=55
       Case  "W" : CharNum=56
       Case  "X" : CharNum=57
       Case  "Y" : CharNum=58
       Case  "Z" : CharNum=59
       Case  "[" : CharNum=60
       Case  "\" : CharNum=61
       Case  "]" : CharNum=62
       Case  "^" : CharNum=63
       Case  "_" : CharNum=64
       Case  "'" : CharNum=65
       Case  "a" : CharNum=66
       Case  "b" : CharNum=67
       Case  "c" : CharNum=68
       Case  "d" : CharNum=69
       Case  "e" : CharNum=70
       Case  "f" : CharNum=71
       Case  "g" : CharNum=72
       Case  "h" : CharNum=73
       Case  "i" : CharNum=74
       Case  "j" : CharNum=75
       Case  "k" : CharNum=76
       Case  "l" : CharNum=77
       Case  "m" : CharNum=78
       Case  "n" : CharNum=79
       Case  "o" : CharNum=80
       Case  "p" : CharNum=81
       Case  "q" : CharNum=82
       Case  "r" : CharNum=83
       Case  "s" : CharNum=84
       Case  "t" : CharNum=85
       Case  "u" : CharNum=86
       Case  "v" : CharNum=87
       Case  "w" : CharNum=88
       Case  "x" : CharNum=89
       Case  "y" : CharNum=90
       Case  "z" : CharNum=91
       Case  "{" : CharNum=92
       Case  "|" : CharNum=93
       Case  "}" : CharNum=94
       Case  "~" : CharNum=95

  End Select
  CharDiscr = [Word](Size-8)*95+CharNum*2-1
  Select Case GLCDFont
       Case GLCDArial
            ReadTable Arial_Descriptors, CharDiscr ,  CharBytes
            ReadTable Arial_Descriptors, CharDiscr+1,  CharOffSetBegin
            ReadTable Arial_Descriptors, CharDiscr+3,  CharOffSetEnd
  End Select
  GLCDFontWidth=CharBytes*8-5'+2
  CharOffSetBegin++
  CharOldBytes=CharBytes
  CharCols=0
  CharRowS=0
  For CharRow=CharOffSetBegin to CharOffSetEnd
      Select Case GLCDFont
             Case GLCDArial
                  Select Case Size
                         Case 8 : ReadTable Arial8 , CharRow , CurrCharVal
                         Case 10 : ReadTable Arial10 , CharRow , CurrCharVal
                         Case 12 : ReadTable Arial12 , CharRow , CurrCharVal
                         Case 14 : ReadTable Arial14 , CharRow , CurrCharVal
                         Case 16 : ReadTable Arial16 , CharRow , CurrCharVal
                         Case 18 : ReadTable Arial18 , CharRow , CurrCharVal
                         'Case 20 : ReadTable Arial20 , CharRow , CurrCharVal
                         'Case 22 : ReadTable Arial22 , CharRow , CurrCharVal
                         'Case 24 : ReadTable Arial24 , CharRow , CurrCharVal
                  End Select
      End Select
      For CharCol=0 to 7
             if CurrCharVal.7=1 then
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDForeground
             Else
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDBackground
             End if
             Rotate CurrCharVal Left
      Next CharCol
      if CharBytes<>0 then CharBytes--
      if CharBytes<>0 Then
         CharColS =CharColS+8
      Else
         CharColS=0
         CharRowS++
         CharBytes=CharOldBytes
      end if
  Next




End Sub
