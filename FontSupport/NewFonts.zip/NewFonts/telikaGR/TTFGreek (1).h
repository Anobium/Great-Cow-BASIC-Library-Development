'    TTF routines for the GCBASIC compiler
'    Copyright (C) 2015 Katsaounis Dimitris

'    This library is free software; you can redistribute it and/or
'    modify it under the terms of the GNU Lesser General Public
'    License as published by the Free Software Foundation; either
'    version 2.1 of the License, or (at your option) any later version.

'    This library is distributed in the hope that it will be useful,
'    but WITHOUT ANY WARRANTY; without even the implied warranty of
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
'    Lesser General Public License for more details.

'    You should have received a copy of the GNU Lesser General Public
'    License along with this library; if not, write to the Free Software
'    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
'
' Characters in use:
' ,.���������������������������������������������������������������������
' All files built with TheDotFactory http://www.pavius.net/the-dot-factory-an-lcd-font-and-image-generator/
'
' Fonts:
' ArialGreek Size 8-28
' CourierNewGreek Size 8-28
' TimesNewRomanGreek Size 8-28


' �he user for system memory economy reasons, may use one font at a time with one group of sizes:
' small 8-16pts , medium 18-22pts and large  24-28pts.
' The philosophy is that every time a user uses a screen with specific resolution, so size
' 28pts is very large  for  a 128x64 display.
' For example Small Arial it consums about 10KB of system memory.
'
' User must Define constant GLCDDefaultFontGreek to be able to use a specific font otherwise the system
' uses as the  default font the ArialGreek font.
' For example:
' #define GLCDDefaultFontGreek  GLCDArialGreek   or
' #define GLCDDefaultFontGreek  GLCDCourierNewGreek
'
' also user must Define constant GLCDfntSize to be able to use a specific gpoup of sizes
' otherwise the system uses as the  default group of sizes the group Smallfont.
' For example:
' #define GLCDfntSizeGreek GLCDSmallSizeGreek    or
' #define GLCDfntSizeGreek GLCDMediumSizeGreek
'

#include "ArialGreek.h"
#include "CourierNewGreek.h"
#include "TimesNewRomanGreek.h"


#startup TTFGreekInit

Sub TTFGreekInit
  Dim GLCDPrintLoc , CharCol,  CharRow,  CharColS,   CharRowS, CharOffSetBegin, CharOffSetEnd, CharDiscr, GLCDFontWidth as Word
  'Define TTF Fonts. Add new fonts here
  #define GLCDArialGreek 1
  #define GLCDCourierNewGreek 2
  #define GLCDTimesNewRomanGreek 3
  'Define Font Size
  #define GLCDSmallSizeGreek 1   '8-16
  #define GLCDMediumSizeGreek 2  '18-22
  #define GLCDBigSizeGreek 3     '24-28

  GLCDDefaultSizeGreek=10
End Sub

Sub GLCDTTFPrintGreek (In PrintLocX as Word, In PrintLocY as Word, In GLCDPrintData As String, Optional In GLCDFont as Byte = GLCDDefaultFontGreek ,Optional In  GLCDForeground as word = GLCDForeground, Optional In Size=GLCDDefaultSizeGreek )
          PrintLen = GLCDPrintData(0)
	If PrintLen = 0 Then Exit Sub
	GLCDPrintLoc = PrintLocX
          GLCDFontWidth=0
	For SysPrintTem = 1 To PrintLen
	    GLCDTTFDrawGreek GLCDPrintLoc, PrintLocY, GLCDPrintData(SysPrintTem), GLCDFont,   GLCDForeground , Size
              GLCDPrintLoc = [Word]GLCDPrintLoc + GLCDFontWidth
	Next
End Sub

Sub GLCDTTFDrawGreek ( In CharLocX as Word, In CharLocY as Word, In CharCode as Byte, Optional In GLCDFont as Byte = GLCDDefaultFontGreek,  Optional In  GLCDForeground as word = GLCDForeground,  Optional In Size = GLCDDefaultSizeGreek)
  CharNum=0
  Select Case CharCode
       Case  " " : CharNum=1
       Case  "," : CharNum=2
       Case  "." : CharNum=3
       Case  "�" : CharNum=4
       Case  "�" : CharNum=5
       Case  "�" : CharNum=6
       Case  "�" : CharNum=7
       Case  "�" : CharNum=8
       Case  "�" : CharNum=9
       Case  "�" : CharNum=10
       Case  "�" : CharNum=11
       Case  "�" : CharNum=12
       Case  "�" : CharNum=13
       Case  "�" : CharNum=14
       Case  "�" : CharNum=15
       Case  "�" : CharNum=16
       Case  "�" : CharNum=17
       Case  "�" : CharNum=18
       Case  "�" : CharNum=19
       Case  "�" : CharNum=20
       Case  "�" : CharNum=21
       Case  "�" : CharNum=22
       Case  "�" : CharNum=23
       Case  "�" : CharNum=24
       Case  "�" : CharNum=25
       Case  "�" : CharNum=26
       Case  "�" : CharNum=27
       Case  "�" : CharNum=28
       Case  "�" : CharNum=29
       Case  "�" : CharNum=30
       Case  "�" : CharNum=31
       Case  "�" : CharNum=32
       Case  "�" : CharNum=33
       Case  "�" : CharNum=34
       Case  "�" : CharNum=35
       Case  "�" : CharNum=36
       Case  "�" : CharNum=37
       Case  "�" : CharNum=38
       Case  "�" : CharNum=39
       Case  "�" : CharNum=40
       Case  "�" : CharNum=41
       Case  "�" : CharNum=42
       Case  "�" : CharNum=43
       Case  "�" : CharNum=44
       Case  "�" : CharNum=45
       Case  "�" : CharNum=46
       Case  "�" : CharNum=47
       Case  "�" : CharNum=48
       Case  "�" : CharNum=49
       Case  "�" : CharNum=50
       Case  "�" : CharNum=51
       Case  "�" : CharNum=52
       Case  "�" : CharNum=53
       Case  "�" : CharNum=54
       Case  "�" : CharNum=55
       Case  "�" : CharNum=56
       Case  "�" : CharNum=57
       Case  "�" : CharNum=58
       Case  "�" : CharNum=59
       Case  "�" : CharNum=60
       Case  "�" : CharNum=61
       Case  "�" : CharNum=62
       Case  "�" : CharNum=63
       Case  "�" : CharNum=64
       Case  "�" : CharNum=65
       Case  "�" : CharNum=66
       Case  "�" : CharNum=67
       Case  "�" : CharNum=68
       Case  "�" : CharNum=69
       Case  "�" : CharNum=70
       Case  "�" : CharNum=71
       Case  "�" : CharNum=72
       Case  " " : CharNum=73
       Case Else  : Exit Sub
  End Select
  CharDiscr = [Word](Size-8)*73+CharNum*2-1
  #if GLCDDefaultFontGreek=GLCDArialGreek
      ReadTable ArialGreek_Descriptors, CharDiscr ,  CharBits
      ReadTable ArialGreek_Descriptors, CharDiscr+1,  CharOffSetBegin
      ReadTable ArialGreek_Descriptors, CharDiscr+3,  CharOffSetEnd
  #endif
  #ifndef GLCDDefaultFontGreek
      ReadTable ArialGreek_Descriptors, CharDiscr ,  CharBits
      ReadTable ArialGreek_Descriptors, CharDiscr+1,  CharOffSetBegin
      ReadTable ArialGreek_Descriptors, CharDiscr+3,  CharOffSetEnd
  #endif
  #if GLCDDefaultFontGreek=GLCDCourierNewGreek
      ReadTable CourierNewGreek_Descriptors, CharDiscr ,  CharBits
      ReadTable CourierNewGreek_Descriptors, CharDiscr+1,  CharOffSetBegin
      ReadTable CourierNewGreek_Descriptors, CharDiscr+3,  CharOffSetEnd
  #endif
  #if GLCDDefaultFontGreek=GLCDTimesNewRomanGreek
      ReadTable TimesNewRomanGreek_Descriptors, CharDiscr ,  CharBits
      ReadTable TimesNewRomanGreek_Descriptors, CharDiscr+1,  CharOffSetBegin
      ReadTable TimesNewRomanGreek_Descriptors, CharDiscr+3,  CharOffSetEnd
  #endif
  'Add new fonts descriptors here
  GLCDFontWidth=CharBits+2
  CharBytes=CharBits/8
  if SysCalcTempX<>0 then CharBytes++
  CharOffSetBegin++
  CharOldBytes=CharBytes
  CharCols=0
  CharRowS=0
  For CharRow=CharOffSetBegin to CharOffSetEnd
      #if GLCDDefaultFontGreek=GLCDArialGreek
         #if GLCDfntSizeGreek = GLCDSmallSizeGreek
             if Size=8  Then ReadTable ArialGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable ArialGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable ArialGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable ArialGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable ArialGreek16 , CharRow , CurrCharVal
         #endif
         #ifndef GLCDfntSizeGreek
             if Size=8  Then ReadTable ArialGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable ArialGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable ArialGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable ArialGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable ArialGreek16 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDMediumSizeGreek
             if Size=18 then ReadTable ArialGreek18 , CharRow , CurrCharVal
             if Size=20 then ReadTable ArialGreek20 , CharRow , CurrCharVal
             if Size=22 then ReadTable ArialGreek22 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDBigSizeGreek
             if Size=24 then ReadTable ArialGreek24 , CharRow , CurrCharVal
             if Size=26 then ReadTable ArialGreek26 , CharRow , CurrCharVal
             if Size=28 then ReadTable ArialGreek28 , CharRow , CurrCharVal
         #endif
      #endif
      #ifndef GLCDDefaultFontGreek
         #if GLCDfntSizeGreek = GLCDSmallSizeGreek
             if Size=8  Then ReadTable ArialGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable ArialGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable ArialGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable ArialGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable ArialGreek16 , CharRow , CurrCharVal
         #endif
         #ifndef GLCDfntSizeGreek
             if Size=8  Then ReadTable ArialGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable ArialGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable ArialGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable ArialGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable ArialGreek16 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDMediumSizeGreek
             if Size=18 then ReadTable ArialGreek18 , CharRow , CurrCharVal
             if Size=20 then ReadTable ArialGreek20 , CharRow , CurrCharVal
             if Size=22 then ReadTable ArialGreek22 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDBigSizeGreek
             if Size=24 then ReadTable ArialGreek24 , CharRow , CurrCharVal
             if Size=26 then ReadTable ArialGreek26 , CharRow , CurrCharVal
             if Size=28 then ReadTable ArialGreek28 , CharRow , CurrCharVal
         #endif
      #endif
      #if GLCDDefaultFontGreek=GLCDCourierNewGreek
         #if GLCDfntSizeGreek = GLCDSmallSizeGreek
             if Size=8  then ReadTable CourierNewGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable CourierNewGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable CourierNewGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable CourierNewGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable CourierNewGreek16 , CharRow , CurrCharVal
         #endif
         #ifndef GLCDfntSizeGreek
             if Size=8  then ReadTable CourierNewGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable CourierNewGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable CourierNewGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable CourierNewGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable CourierNewGreek16 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDMediumSizeGreek
             if Size=18 then ReadTable CourierNewGreek18 , CharRow , CurrCharVal
             if Size=20 then ReadTable CourierNewGreek20 , CharRow , CurrCharVal
             if Size=22 then ReadTable CourierNewGreek22 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDBigSizeGreek
             if Size=24 then ReadTable CourierNewGreek24 , CharRow , CurrCharVal
             if Size=26 then ReadTable CourierNewGreek26 , CharRow , CurrCharVal
             if Size=28 then ReadTable CourierNewGreek28 , CharRow , CurrCharVal
         #endif
      #endif
      #if GLCDDefaultFontGreek=GLCDTimesNewRomanGreek
         #if GLCDfntSizeGreek = GLCDSmallSizeGreek
             if Size=8  then ReadTable TimesNewRomanGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable TimesNewRomanGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable TimesNewRomanGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable TimesNewRomanGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable TimesNewRomanGreek16 , CharRow , CurrCharVal
         #endif
         #ifndef GLCDfntSizeGreek
             if Size=8  then ReadTable TimesNewRomanGreek8 , CharRow , CurrCharVal
             if Size=10 then ReadTable TimesNewRomanGreek10 , CharRow , CurrCharVal
             if Size=12 then ReadTable TimesNewRomanGreek12 , CharRow , CurrCharVal
             if Size=14 then ReadTable TimesNewRomanGreek14 , CharRow , CurrCharVal
             if Size=16 then ReadTable TimesNewRomanGreek16 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDMediumSizeGreek
             if Size=18 then ReadTable TimesNewRomanGreek18 , CharRow , CurrCharVal
             if Size=20 then ReadTable TimesNewRomanGreek20 , CharRow , CurrCharVal
             if Size=22 then ReadTable TimesNewRomanGreek22 , CharRow , CurrCharVal
         #endif
         #if GLCDfntSizeGreek = GLCDBigSizeGreek
             if Size=24 then ReadTable TimesNewRomanGreek24 , CharRow , CurrCharVal
             if Size=26 then ReadTable TimesNewRomanGreek26 , CharRow , CurrCharVal
             if Size=28 then ReadTable TimesNewRomanGreek28 , CharRow , CurrCharVal
         #endif
      #endif
      'Add new fonts tables here
      For CharCol=0 to 7
             if CurrCharVal.7=1 then
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDForeground
             Else
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDBackground
             End if
             Rotate CurrCharVal Left
      Next CharCol
      if CharBytes<>0 then CharBytes--
      if CharBytes<>0 Then
         CharColS =CharColS+8
      Else
         CharColS=0
         CharRowS++
         CharBytes=CharOldBytes
      end if
  Next

End Sub

