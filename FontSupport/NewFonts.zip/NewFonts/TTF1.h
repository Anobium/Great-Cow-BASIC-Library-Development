Dim GLCDPrintLoc , CharCol,  CharRow,  CharColS,   CharRowS, CharOffSetBegin, CharOffSetEnd, CharDiscr, GLCDFontWidth as Word

Sub GLCDPrintTTF (In PrintLocX as Word, In PrintLocY as Word, In GLCDPrintData As String, Optional In GLCDFont as Byte =GLCDArial, Optional In  GLCDForeground as word = GLCDForeground, Optional In Size=10 )
          PrintLen = GLCDPrintData(0)
	If PrintLen = 0 Then Exit Sub
	GLCDPrintLoc = PrintLocX
          GLCDFontWidth=0
	For SysPrintTem = 1 To PrintLen
		GLCDDrawTTF GLCDPrintLoc, PrintLocY, GLCDPrintData(SysPrintTem), GLCDFont,  GLCDForeground , Size
		GLCDPrintLoc = [Word]GLCDPrintLoc + GLCDFontWidth
	Next
End Sub

Sub GLCDDrawTTF ( In CharLocX as Word, In CharLocY as Word, In CharCode as Byte, Optional In GLCDFont as Byte =GLCDArial,  Optional In  GLCDForeground as word = GLCDForeground,  Optional In Size = 10)
  ' !0123456789:;<=>?@[\]^_`ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,%$#&*{|}~()+-/'
  CharNum=0
  Select Case CharCode
       Case  " " : CharNum=1
       Case  "!" : CharNum=2
       Case  "#" : CharNum=3
       Case  "$" : CharNum=4
       Case  "%" : CharNum=5
       Case  "&" : CharNum=6
       Case  "`" : CharNum=7
       Case  "(" : CharNum=8
       Case  ")" : CharNum=9
       Case  "*" : CharNum=10
       Case  "+" : CharNum=11
       Case  "," : CharNum=12
       Case  "-" : CharNum=13
       Case  "." : CharNum=14
       Case  "/" : CharNum=15
       Case  "0" : CharNum=16
       Case  "1" : CharNum=17
       Case  "2" : CharNum=18
       Case  "3" : CharNum=19
       Case  "4" : CharNum=20
       Case  "5" : CharNum=21
       Case  "6" : CharNum=22
       Case  "7" : CharNum=23
       Case  "8" : CharNum=24
       Case  "9" : CharNum=25
       Case  ":" : CharNum=26
       'Case  ";" : CharNum=27
       Case  "<" : CharNum=28
       Case  "=" : CharNum=29
       Case  ">" : CharNum=30
       Case  "?" : CharNum=31
       Case  "@" : CharNum=32
       Case  "A" : CharNum=33
       Case  "B" : CharNum=34
       Case  "C" : CharNum=35
       Case  "D" : CharNum=36
       Case  "E" : CharNum=37
       Case  "F" : CharNum=38
       Case  "G" : CharNum=39
       Case  "H" : CharNum=40
       Case  "I" : CharNum=41
       Case  "J" : CharNum=42
       Case  "K" : CharNum=43
       Case  "L" : CharNum=44
       Case  "M" : CharNum=45
       Case  "N" : CharNum=46
       Case  "O" : CharNum=47
       Case  "P" : CharNum=48
       Case  "Q" : CharNum=49
       Case  "R" : CharNum=50
       Case  "S" : CharNum=51
       Case  "T" : CharNum=52
       Case  "U" : CharNum=53
       Case  "V" : CharNum=54
       Case  "W" : CharNum=55
       Case  "X" : CharNum=56
       Case  "Y" : CharNum=57
       Case  "Z" : CharNum=58
       Case  "[" : CharNum=59
       Case  "\" : CharNum=60
       Case  "]" : CharNum=61
       Case  "^" : CharNum=62
       Case  "_" : CharNum=63
       Case  "'" : CharNum=64
       Case  "a" : CharNum=65
       Case  "b" : CharNum=66
       Case  "c" : CharNum=67
       Case  "d" : CharNum=68
       Case  "e" : CharNum=69
       Case  "f" : CharNum=70
       Case  "g" : CharNum=71
       Case  "h" : CharNum=72
       Case  "i" : CharNum=73
       Case  "j" : CharNum=74
       Case  "k" : CharNum=75
       Case  "l" : CharNum=76
       Case  "m" : CharNum=77
       Case  "n" : CharNum=78
       Case  "o" : CharNum=79
       Case  "p" : CharNum=80
       Case  "q" : CharNum=81
       Case  "r" : CharNum=82
       Case  "s" : CharNum=83
       Case  "t" : CharNum=84
       Case  "u" : CharNum=85
       Case  "v" : CharNum=86
       Case  "w" : CharNum=87
       Case  "x" : CharNum=88
       Case  "y" : CharNum=89
       Case  "z" : CharNum=90
       Case  "{" : CharNum=91
       Case  "|" : CharNum=92
       Case  "}" : CharNum=93
       Case  "~" : CharNum=94
       Case Else  : Exit Sub
  End Select
  CharDiscr = [Word](Size-8)*94+CharNum*2-1
  Select Case GLCDFont   '#if
       Case GLCDArial
            ReadTable Arial_Descriptors, CharDiscr ,  CharBits
            ReadTable Arial_Descriptors, CharDiscr+1,  CharOffSetBegin
            ReadTable Arial_Descriptors, CharDiscr+3,  CharOffSetEnd
       Case GLCDCourierNew
            ReadTable CourierNew_Descriptors, CharDiscr ,  CharBits
            ReadTable CourierNew_Descriptors, CharDiscr+1,  CharOffSetBegin
            ReadTable CourierNew_Descriptors, CharDiscr+3,  CharOffSetEnd
  End Select
  GLCDFontWidth=CharBits+2
  CharBytes=CharBits/8
  if SysCalcTempX<>0 then CharBytes++
  CharOffSetBegin++
  CharOldBytes=CharBytes
  CharCols=0
  CharRowS=0
  For CharRow=CharOffSetBegin to CharOffSetEnd
      Select Case GLCDFont
             Case GLCDArial
                  Select Case Size
                         Case 8 : ReadTable Arial8 , CharRow , CurrCharVal
                         Case 10 : ReadTable Arial10 , CharRow , CurrCharVal
                         Case 12 : ReadTable Arial12 , CharRow , CurrCharVal
                         Case 14 : ReadTable Arial14 , CharRow , CurrCharVal
                         Case 16 : ReadTable Arial16 , CharRow , CurrCharVal
                         Case 18 : ReadTable Arial18 , CharRow , CurrCharVal
                         Case 20 : ReadTable Arial20 , CharRow , CurrCharVal
                         Case 22 : ReadTable Arial22 , CharRow , CurrCharVal
                         Case 24 : ReadTable Arial24 , CharRow , CurrCharVal
                         Case 26 : ReadTable Arial26 , CharRow , CurrCharVal
                         Case 28 : ReadTable Arial28 , CharRow , CurrCharVal
                  End Select
             Case GLCDCourierNew
                  Select Case Size
                         Case 8 : ReadTable CourierNew8 , CharRow , CurrCharVal
                         Case 10 : ReadTable CourierNew10 , CharRow , CurrCharVal
                         Case 12 : ReadTable CourierNew12 , CharRow , CurrCharVal
                         Case 14 : ReadTable CourierNew14 , CharRow , CurrCharVal
                         Case 16 : ReadTable CourierNew16 , CharRow , CurrCharVal
                         Case 18 : ReadTable CourierNew18 , CharRow , CurrCharVal
                         Case 20 : ReadTable CourierNew20 , CharRow , CurrCharVal
                         Case 22 : ReadTable CourierNew22 , CharRow , CurrCharVal
                         Case 24 : ReadTable CourierNew24 , CharRow , CurrCharVal
                         Case 26 : ReadTable CourierNew26 , CharRow , CurrCharVal
                         Case 28 : ReadTable CourierNew28 , CharRow , CurrCharVal
                  End Select
      End Select
      For CharCol=0 to 7
             if CurrCharVal.7=1 then
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDForeground
             Else
                     PSet_SSD1289 CharLocX + CharCol + CharColS, CharLocY + CharRowS, GLCDBackground
             End if
             Rotate CurrCharVal Left
      Next CharCol
      if CharBytes<>0 then CharBytes--
      if CharBytes<>0 Then
         CharColS =CharColS+8
      Else
         CharColS=0
         CharRowS++
         CharBytes=CharOldBytes
      end if
  Next




End Sub
